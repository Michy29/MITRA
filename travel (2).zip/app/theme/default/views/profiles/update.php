 <form  method="post" >
 <?php $data=HMIS\profiles::get_profile($_POST["id"])?>
	<fieldset>
		<input type="hidden" class="form-control" name="uid" value="<?=$_POST["id"]?>">
	<div class="form-group col-md-4">
		<label class="control-label">First Name:</label>
		<input type="text" class="form-control" value="<?=$data['first_name']?>"  name="first_name">
	</div>
	<div class="form-group col-md-4">
		<label class="control-label">Middle Name:</label>
		<input type="text" class="form-control" value="<?=$data['middle_name']?>"  name="middle_name">
	</div>
	<div class="form-group col-md-4">
		<label class="control-label">Last Name:</label>
		<input type="text" class="form-control" value="<?=$data['last_name']?>"  name="last_name">
	</div>
	<div class="form-group col-md-4">
		<label class="control-label">Gender:</label>
		<select type="text" class="form-control" name="gender">
			<option><?=$data['gender']?></option>
			<option>Male</option>
			<option>Female</option>
		</select>
	</div>
	<div class="form-group col-md-4">
		<label class="control-label">Email:</label>
		<input type="text" class="form-control" value="<?=$data['email']?>"  name="email">
	</div>
	<div class="form-group col-md-4">
		<label class="control-label">Mobile No:</label>
		<input type="text" class="form-control" value="<?=$data['mobileno']?>"  name="mobileno">
	</div>
	<div class="form-group col-md-4">
		<label class="control-label">Country:</label>
		<select type="text" class="form-control" name="country">
			<option><?=$data['country']?></option>
			<?=HMIS\countries()?>
		</select>
	</div>
	<div class="form-group col-md-4">
		<label class="control-label">City:</label>
		<input type="text" class="form-control" value="<?=$data['city']?>"  name="city">
	</div>
	<div class="form-group col-md-4">
		<label class="control-label">Zip Code:</label>
		<input type="text" class="form-control" value="<?=$data['zipcode']?>"  name="zipcode">
	</div>
	<div class="form-group col-md-6">
		<label class="control-label">Street Address:</label>
		<input type="text" class="form-control" value="<?=$data['street_address']?>"  name="street_address">
	</div>
	<div class="form-group col-md-6">
		<label class="control-label">Address Line 2:</label>
		<input type="text" class="form-control" value="<?=$data['address_line2']?>"  name="address_line2">
	</div>
		
		<input type="hidden" class="form-control" name="regdate" value="<?=$data['regdate']?>">

</fieldset>
                   
 <div class="form-group form-actions">
                        <div class="col-xs-12 text-right">
                           <button type="submit" name="btn_prof" class="btn btn-sm btn-primary">Submit</button>
                            <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </form>
                    