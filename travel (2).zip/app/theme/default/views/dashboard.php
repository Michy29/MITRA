   <div id="page-content">
    <!-- Dashboard Header -->
    <!-- For an image header add the class 'content-header-media' and an image as in the following example -->
    <div class="content-header content-header-media">
        <div class="header-section">
            <div class="row">
                <!-- Main Title (hidden on small devices for the statistics to fit) -->
                <div class="col-md-4 col-lg-6 hidden-xs hidden-sm">
                    <h1>Welcome <strong><?//=EMIS\Staff::get_staff($_SESSION['UID'])['first_name']?></strong><br><small>You Look Awesome!</small></h1>
                </div>
                <!-- END Main Title -->
            </div>
        </div>
        <img src="header.jpg" alt="header image" class="animation-pulseSlow">
    </div>
    <!-- END Dashboard Header -->

    <!-- Mini Top Stats Row -->
    
    <!-- END Mini Top Stats Row -->

    
</div>