<?php
$data=HMIS\Setup::read_configurations();
?>
   <div id="page-content">
    <div class="content-header">
        <div class="header-section">
            <h1>
                <i class="gi gi-settings"></i> System Settings<br>
            </h1>
        </div>
    </div>
    <div class="block">
        <div class="row">
        
        <div class="col-sm-12">
            <div class="block">
                <div class="block-title">
                   	
                    <h2>Setup Form</h2>
                </div>
						<form  class="form-bordered" method="post">
                    <fieldset>
						<div class="form-group col-md-5">
							<label class="control-label">Company Name:</label>
							<input type="text"  class="form-control" name="company_name" value="<?=@$data['company_name']?>">
						</div>
						<div class="form-group col-md-3">
							<label class="control-label">Company Abbreviation:</label>
							<input type="text" class="form-control" name="company_abbr" value="<?=@$data['company_abbr']?>">
						</div>
						
						<div class="form-group col-md-4">
							<label class="control-label">Company Address:</label>
							<input type="text"  class="form-control" name="company_address" value="<?=@$data['company_address']?>">
						</div>
                  		<div class="form-group col-md-4">
							<label class="control-label">Company Tel. No.:</label>
							<input type="text"  class="form-control" name="company_telno" value="<?=@$data['company_telno']?>">
						</div>
                		<div class="form-group col-md-4">
							<label class="control-label">Company Email:</label>
							<input type="text"  class="form-control" name="company_email" value="<?=@$data['company_email']?>">
						</div>
                 		<div class="form-group col-md-4">
							<label class="control-label">Physical Address:</label>
							<input type="text"  class="form-control" name="company_physical_address" value="<?=@$data['company_physical_address']?>">
						</div>
                		<div class="form-group col-md-3">
							<label class="control-label">SMS API Username:</label>
							<input type="text" class="form-control" name="sms_api_username" value="<?=@$data['sms_api_username']?>">
						</div>
                  		<div class="form-group col-md-3">
							<label class="control-label">SMS API Key:</label>
							<input type="text" class="form-control" name="sms_api_key" value="<?=@$data['sms_api_key']?>">
						</div>
                  		<div class="form-group col-md-3">
							<label class="control-label">IPay Hash:</label>
							<input type="text" class="form-control" name="payment_hash_key" value="<?=@$data['payment_hash_key']?>">
						</div>
                  		<div class="form-group col-md-3">
							<label class="control-label">IPay Vendor ID:</label>
							<input type="text" class="form-control" name="payment_vendor_id" value="<?=@$data['payment_vendor_id']?>">
						</div>
                		<div class="form-group col-md-3">
							<label class="control-label">Monthly Listing Price:</label>
							<input type="text" class="form-control" name="monthly_listing_price" value="<?=@$data['monthly_listing_price']?>">
						</div>
                  		<div class="form-group col-md-3">
							<label class="control-label">Quarterly Listing Price:</label>
							<input type="text" class="form-control" name="quarterly_listing_price" value="<?=@$data['quarterly_listing_price']?>">
						</div>
                  		<div class="form-group col-md-3">
							<label class="control-label">Biannually Listing Price:</label>
							<input type="text" class="form-control" name="biannualy_listing_price" value="<?=@$data['biannualy_listing_price']?>">
						</div>
                  		<div class="form-group col-md-3">
							<label class="control-label">Annually Listing Price:</label>
							<input type="text" class="form-control" name="annualy_listing_price" value="<?=@$data['annualy_listing_price']?>">
						</div>
                 		<div class="form-group col-md-6">
							<label class="control-label">Application Name:</label>
							<input type="text"  class="form-control" name="applongname" value="<?=@$data['applongname']?>">
						</div>
						<div class="form-group col-md-3">
							<label class="control-label">Application Abbreviation:</label>
							<input type="text" class="form-control" name="appshortname" value="<?=@$data['appshortname']?>">
						</div>
						<div class="form-group col-md-3">
							<label class="control-label">Application Version:</label>
							<input type="text" class="form-control" name="appversion" value="<?=@$data['appversion']?>">
						</div>
                  		<div class="form-group col-md-6">
							<label class="control-label">Application Developer:</label>
							<input type="text" class="form-control" name="developer" value="<?=@$data['developer']?>">
						</div>
                  		<div class="form-group col-md-6">
							<label class="control-label">Developer URL:</label>
							<input type="text" class="form-control" name="developer_site" value="<?=@$data['developer_site']?>">
						</div>
                   </fieldset>
                    <div  class="form-group form-actions">
                       <fieldset>
                       		<button style="float: right" name="setup" type="submit" class="btn btn-sm btn-info">Submit</button>
                       </fieldset> 
                    </div>
                </form>
            </div>
        </div>
			</form>
    </div>
    </div>

</div>



