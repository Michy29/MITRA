   <?=HMIS\Gallery::image_c_u('GALLERY')?>
   <div id="page-content">
    <div class="content-header">
        <div class="header-section">
            <h1>
                <i class="fa fa-image"></i>Gallery Images<br>
            </h1>
        </div>
    </div>
    <div class="block">
        <div class="row">
        
        <div class="col-sm-12">
            <div class="block">
                <div class="block-title">
                   	<div class="block-options pull-right">
                        <?php// if($_SESSION['R']['add_room']=='YES'){?>
                        	<a href="#room" data-toggle="modal" onClick="page_loader('<?=G\path()['call_parts'][0]?>','upload','<?=G\DB::Encoder('gallery')?>')" class="btn btn-sm btn-primary">Upload Image</a>
                        <?php // }?>
                    </div>
                    
                    <h2>Pictures</h2>
                </div>
                	
						<fieldset id="imgr">
						<?php foreach(HMIS\Gallery::get_images('GALLERY') as $row){?>
						<div class="col-sm-3 block-section text-center">
							<div class="gallery-image">
								<img width="100%" height="200px" src="<?=ROOT_URL.'content/gallery/'.$row['image_name']?>">
								<div class="gallery-image-options">
									<a href="<?=ROOT_URL.'content/gallery/'.$row['image_name']?>" data-toggle="lightbox-image" title="<?=$row['image_caption']?>" class="gallery-link btn btn-sm btn-primary"><i class="fa fa-eye"></i></a>
									
									<span data-toggle="tooltip" title="" data-original-title="Edit Caption">
										<a href="#room" data-toggle="modal" onClick="page_loader('<?=G\path()['call_parts'][0]?>','eupload','<?=$row['image_id']?>')" class="btn btn-sm btn-alt btn-primary"><i class="fa fa-pencil"></i></a>
									</span>

									<span data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete"><button onclick="SwalDelete('pic','<?=$row['image_id']?>')" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></button></span>
									
									
								</div>
							</div>
						</div>
						
						<?php
	
}?>	
						</fieldset>
           		
            </div>
        </div>
			</form>
    </div>
    </div>
    
    <div id="room" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title"> Image Uploader</h4>
            </div>
            <!-- END Modal Header -->

            <!-- Modal Body -->
            <div class="modal-body"><div id="response"></div></div>
            <!-- END Modal Body -->
        </div>
    </div>
</div>
    
</div>





