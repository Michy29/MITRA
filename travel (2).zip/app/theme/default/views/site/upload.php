 <form  method="post" enctype="multipart/form-data" >
 <style>
.btn-file {
    position: relative;
    overflow: hidden;
}
.btn-file input[type=file] {
    position: absolute;
    top: 0;
    right: 0;
    min-width: 100%;
    min-height: 100%;
    font-size: 100px;
    text-align: right;
    filter: alpha(opacity=0);
    opacity: 0;
    outline: none;
    background: white;
    cursor: inherit;
    display: block;
} </style>
	<fieldset>
		<input type="hidden" class="form-control" name="image_id" value="<?=$_POST["id"]?>">
		
		<div class="form-group col-md-12">
			<label class="control-label">Caption:</label>
			<input type="text" class="form-control" required name="image_caption">
		</div>
		
		<div class="form-group col-md-12">
			<span class="btn btn-info btn-file btn-block">
				Browse Image to Upload<input type="file" required name="image_name" id="imgInp">
			</span>
			<span>
				<img width="100%" id="blah" src="<?=ROOT_URL?>content/blank.jpg"/>
			</span>
		</div>                        
	</fieldset>
  <div class="form-group form-actions">
                        <div class="col-xs-12 text-right">
                           <button type="submit" name="btn_gallery" class="btn btn-sm btn-primary">Upload</button>
                            <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </form>
                  
<script>
	function readURL(input) {

  if (input.files && input.files[0]) {
    var reader = new FileReader();

    reader.onload = function(e) {
      $('#blah').attr('src', e.target.result);
    }

    reader.readAsDataURL(input.files[0]);
  }
}

$("#imgInp").change(function() {
  readURL(this);
});
</script>
                   
                    