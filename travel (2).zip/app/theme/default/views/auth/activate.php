<?php
(HMIS\Auth::getToken()!=null)?$data=HMIS\Auth::getToken():$err='The token you submitted is expired or has been used';
(isset($_POST['btn_activate']))?HMIS\Auth::activateAcc():null;
?>
      <div class="main-bothside">
         <form  method="post">
          		<?php if(isset($err)){?>
           		<div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h4> <span class="alert-link">Error </span><i class="fa fa-exclamation"></i> <?=$err?>!</h4>
                </div>
                <?php }?>
            <div class="form-group">
              
                
               <div class="form-mid-w3ls">
                  <p>First Name</p>
                  <input type="text" name="first_name" readonly value="<?=$data['first_name']?>"  required>
               </div>
               <div class="form-mid-w3ls">
                  <p>Last Name</p>
                  <input type="text" name="last_name" readonly value="<?=$data['last_name']?>"  required>
               </div>
            </div>
            <div class="form-group">
               <div class="form-mid-w3ls">
                  <p>Email</p>
                  <input type="email" name="email" readonly value="<?=$data['email']?>"   required>
               </div>
               <div class="form-mid-w3ls">
                  <p>Account Type</p>
                  <select name="user_type" class="form-control">
						<option value="" disabled selected>Select Account Type...</option>
						<option value="User">Traveller</option>
						<option value="Agent">Property Owner</option>
				</select>
               </div>
            </div>
            
            
            <div class="form-group">
               <div class="form-mid-w3ls">
                  <p>Password</p>
                  <input type="password" name="password"   required>
               </div>
            </div>
            
            <div class="btnn">
               <input type="submit" name="btn_activate" value="Activate Account">
            </div>
			 <hr>
            <span ><strong style="color:aliceblue">Already have an account?</strong> <a style="color:yellow" href="<?=ROOT_URL?>login">Login Here</a></span>
            
         </form>
      </div>
      