<?php ($_SESSION['UID']==null)?header('Location:'.ROOT_URL.'login'):$data=HMIS\Profiles::get_profile($_SESSION['UID']);?>
<!DOCTYPE HTML>
<html xml:lang="en" lang="en">
<head>
<meta charset="utf-8">
<meta name="generator" content="G\ Library">
<title><?=G\docTitle()?></title>
<meta name="description" content="<?=G\get_app_setting('seo_description')?>">
<meta name="author" content="<?=G\get_app_setting('developer')?>">
<meta name="robots" content="<?=G\get_app_setting('robots')?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link rel="shortcut icon" href="<?=G\Render\get_theme_file_url('assets/img/favicon.png')?>">
<link rel="stylesheet" href="<?=G\Render\get_theme_file_url('assets/css/bootstrap.min.css')?>">
<link rel="stylesheet" href="<?=G\Render\get_theme_file_url('assets/css/plugins.css')?>">
<link rel="stylesheet" href="<?=G\Render\get_theme_file_url('assets/js/helpers/sweetalert/sweetalert2.css')?>">

<link rel="stylesheet" href="<?=G\Render\get_theme_file_url('assets/css/main.css')?>">
<?php 
if(G\path()['call_parts'][1]=='amenities'){ ?>
<link rel="stylesheet" href="<?=G\Render\get_theme_file_url('assets/css/fonts/fav470/css/font-awesome.min.css')?>">
<link rel="stylesheet" href="<?=G\Render\get_theme_file_url('assets/css/fontawesome-iconpicker.min.css')?>">
<?php }?>
<?php if (G\get_app_setting('sub_theme')) { ?>
        <link id="theme-link" rel="stylesheet" href="<?=G\Render\get_theme_file_url('assets/css/themes/'.G\get_app_setting('sub_theme'))?>.css"><?php } ?>
<link rel="stylesheet" href="<?=G\Render\get_theme_file_url('assets/css/themes.css')?>">
<script src="<?=G\Render\get_theme_file_url('assets/js/vendor/modernizr.min.js')?>"></script>
</head>
<body>
<div id="page-wrapper"<?php if (G\get_app_setting('preloader')==1) { echo ' class="page-loading"'; } ?>>
    <div class="preloader themed-background">
        <h1 class="push-top-bottom text-light text-center"><strong><?=G\get_app_setting('appshortname')?></strong></h1>
        <div class="inner">
            <h3 class="text-light visible-lt-ie10"><strong>Loading..</strong></h3>
            <div class="preloader-spinner hidden-lt-ie10"></div>
        </div>
    </div>
    <?php
        $page_classes = '';

        if (G\get_app_setting('header') == 'navbar-fixed-top') {
            $page_classes = 'header-fixed-top';
        } else if (G\get_app_setting('header') == 'navbar-fixed-bottom') {
            $page_classes = 'header-fixed-bottom';
        }

        if (G\get_app_setting('sidebar')) {
            $page_classes .= (($page_classes == '') ? '' : ' ') . G\get_app_setting('sidebar');
        }

        if (G\get_app_setting('main_style') == 'style-alt')  {
            $page_classes .= (($page_classes == '') ? '' : ' ') . 'style-alt';
        }

        if (G\get_app_setting('footer') == 'footer-fixed')  {
            $page_classes .= (($page_classes == '') ? '' : ' ') . 'footer-fixed';
        }

        if (!G\get_app_setting('menu_scroll'))  {
            $page_classes .= (($page_classes == '') ? '' : ' ') . 'disable-menu-autoscroll';
        }

        if (G\get_app_setting('cookies') === 'enable-cookies') {
            $page_classes .= (($page_classes == '') ? '' : ' ') . 'enable-cookies';
        }
    ?>
    <div id="page-container"<?php if ($page_classes) { echo ' class="' . $page_classes . '"'; } ?>>
        <!-- Main Sidebar -->
        <div id="sidebar">
            <!-- Wrapper for scrolling functionality -->
            <div id="sidebar-scroll">
                <!-- Sidebar Content -->
                <div class="sidebar-content">
                    <!-- Brand -->
                    <a href="index.php" class="sidebar-brand">
                        <i class="gi gi-flash"></i><span class="sidebar-nav-mini-hide"><strong><?=G\get_app_setting('appshortname')?></strong></span>
                    </a>
                    <!-- END Brand -->
                    <?php require('menu.php');if ($primary_nav) { ?>
                    <!-- Sidebar Navigation -->
                    <ul class="sidebar-nav">
                        <?php foreach( $primary_nav as $key => $link ) {
                            $link_class = '';
                            $li_active  = '';
                            $menu_link  = '';

                            // Get 1st level link's vital info
                            $url        = (isset($link['url']) && $link['url']) ? $link['url'] : '#';
                            $active     = (isset($link['url']) && (G\get_app_setting('active_page') == $link['url'])) ? ' active' : '';
                            $icon       = (isset($link['icon']) && $link['icon']) ? '<i class="' . $link['icon'] . ' sidebar-nav-icon"></i>' : '';
							$auth		= (isset($link['auth']) && $link['auth']) ? $link['auth'] : 'YES';

                            // Check if the link has a submenu
                            if (isset($link['sub']) && $link['sub']) {
                                // Since it has a submenu, we need to check if we have to add the class active
                                // to its parent li element (only if a 2nd or 3rd level link is active)
                                foreach ($link['sub'] as $sub_link) {
                                    if (in_array(G\get_app_setting('active_page'), $sub_link)) {
                                        $li_active = ' class="active"';
                                        break;
                                    }

                                    // 3rd level links
                                    if (isset($sub_link['sub']) && $sub_link['sub']) {
                                        foreach ($sub_link['sub'] as $sub2_link) {
                                            if (in_array(G\get_app_setting('active_pge'), $sub2_link)) {
                                                $li_active = ' class="active"';
                                                break;
                                            }
                                        }
                                    }
                                }

                                $menu_link = 'sidebar-nav-menu';
                            }

                            // Create the class attribute for our link
                            if ($menu_link || $active) {
                                $link_class = ' class="'. $menu_link . $active .'"';
                            }
                        ?>
                        <?php if ($url == 'header') { // if it is a header and not a link ?>
                        <li class="sidebar-header">
                            <?php if (isset($link['opt']) && $link['opt']) { // If the header has options set ?>
                            <span class="sidebar-header-options clearfix"><?php echo $link['opt']; ?></span>
                            <?php } ?>
                            <span class="sidebar-header-title"><?php echo $link['name']; ?></span>
                        </li>
                        <?php } else { /*/ If it is a link*/  if($auth=='YES'){?>
                        <li<?php echo $li_active; ?>>
                            <a href="<?php echo $url; ?>"<?php echo $link_class; ?>><?php if (isset($link['sub']) && $link['sub']) { // if the link has a submenu ?><i class="fa fa-angle-left sidebar-nav-indicator sidebar-nav-mini-hide"></i><?php } echo $icon; ?><span class="sidebar-nav-mini-hide"><?php echo $link['name']; ?></span></a>
                            <?php if (isset($link['sub']) && $link['sub']) { // if the link has a submenu ?>
                            <ul>
                                <?php foreach ($link['sub'] as $sub_link) {
                                    $link_class = '';
                                    $li_active = '';
                                    $submenu_link = '';

                                    // Get 2nd level link's vital info
                                    $url        = (isset($sub_link['url']) && $sub_link['url']) ? $sub_link['url'] : '#';
                                    $active     = (isset($sub_link['url']) && (G\get_app_setting('active_page')== $sub_link['url'])) ? ' active' : '';

                                    // Check if the link has a submenu
                                    if (isset($sub_link['sub']) && $sub_link['sub']) {
                                        // Since it has a submenu, we need to check if we have to add the class active
                                        // to its parent li element (only if a 3rd level link is active)
                                        foreach ($sub_link['sub'] as $sub2_link) {
                                            if (in_array(G\get_app_setting('active_page'), $sub2_link)) {
                                                $li_active = ' class="active"';
                                                break;
                                            }
                                        }

                                        $submenu_link = 'sidebar-nav-submenu';
                                    }

                                    if ($submenu_link || $active) {
                                        $link_class = ' class="'. $submenu_link . $active .'"';
                                    }
                                ?>
                                <li<?php echo $li_active; ?>>
                                    <a href="<?php echo $url; ?>"<?php echo $link_class; ?>><?php if (isset($sub_link['sub']) && $sub_link['sub']) { ?><i class="fa fa-angle-left sidebar-nav-indicator"></i><?php } echo $sub_link['name']; ?></a>
                                    <?php if (isset($sub_link['sub']) && $sub_link['sub']) { ?>
                                        <ul>
                                            <?php foreach ($sub_link['sub'] as $sub2_link) {
                                                // Get 3rd level link's vital info
                                                $url    = (isset($sub2_link['url']) && $sub2_link['url']) ? $sub2_link['url'] : '#';
                                                $active = (isset($sub2_link['url']) && (G\get_app_setting('active_page') == $sub2_link['url'])) ? ' class="active"' : '';
                                            ?>
                                            <li>
                                                <a href="<?php echo $url; ?>"<?php echo $active ?>><?php echo $sub2_link['name']; ?></a>
                                            </li>
                                            <?php } ?>
                                        </ul>
                                    <?php } ?>
                                </li>
                                <?php } ?>
                            </ul>
                            <?php } ?>
                        </li>
                        <?php } }?>
                        <?php } ?>
                    </ul>
                    <!-- END Sidebar Navigation -->
                    <?php } ?>
                </div>
                <!-- END Sidebar Content -->
            </div>
            <!-- END Wrapper for scrolling functionality -->
        </div>
        <!-- END Main Sidebar -->

        <!-- Main Container -->
        <div id="main-container">
            <header class="navbar<?php if (G\get_app_setting('header_navbar')) { echo ' ' . G\get_app_setting('header_navbar'); } ?><?php if (G\get_app_setting('header')) { echo ' '. G\get_app_setting('header'); } ?>">
                <?php if ( G\get_app_setting('header') == 'horizontal-menu' ) { null ;/*this app doesnt need horizontal menu*/ } else { // Default Header Content  ?>
                <!-- Left Header Navigation -->
                <ul class="nav navbar-nav-custom">
                    <!-- Main Sidebar Toggle Button -->
                    <li>
                        <a href="javascript:void(0)" onclick="App.sidebar('toggle-sidebar');this.blur();">
                            <i class="fa fa-bars fa-fw"></i>
                        </a>
                    </li>
                    <!-- END Main Sidebar Toggle Button -->

                    <!-- settings Options -->
                    <!-- Change Options functionality can be found in js/app.js - settingsOptions() -->
                    
                    <!-- END settings Options -->
                </ul>
                <!-- END Left Header Navigation -->

                

                <!-- Right Header Navigation -->
                <ul class="nav navbar-nav-custom pull-right">
                    <!-- User Dropdown -->
                    <li class="dropdown">
                        <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">
                            <i class="fa fa-user"></i> <span><?=G\get_app_setting('first_name').' '.G\get_app_setting('middle_name').' '.G\get_app_setting('last_name')?></span> <i class="fa fa-angle-down"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-custom dropdown-menu-right">
                            <li>
                                
                                <!-- Opens the user settings modal that can be found at the bottom of each page (page_footer.php in PHP version) -->
                                <a href="#modal-user-settings" data-toggle="modal">
                                    <i class="fa fa-lock fa-fw pull-right"></i>
                                    Change Password
                                </a>
                            </li>
                            <li class="divider"></li>
                            <li>
                                <a href="<?=ROOT_URL?>auth/logout"><i class="fa fa-ban fa-fw pull-right"></i> Logout</a>
                            </li>
                            
                        </ul>
                    </li>
                    <!-- END User Dropdown -->
                </ul>
                <!-- END Right Header Navigation -->
                <?php } ?>
            </header>
            <!-- END Header -->
	
