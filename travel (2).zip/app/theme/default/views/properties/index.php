   <?=HMIS\Properties::property_c_u()?>
   <div id="page-content">
    <div class="content-header">
        <div class="header-section">
            <h1>
                <i class="fa fa-bank"></i>Properties<br>
            </h1>
        </div>
    </div>
    <div class="block">
        <div class="row">
        
        <div class="col-sm-12">
            <div class="block">
                <div class="block-title">
                   	<div class="block-options pull-right">
                        	<a href="#pullup" data-toggle="modal" onClick="page_loader('<?=G\path()['call_parts'][0]?>','register','PRT<?=G\DB::Encoder('properties')?>')" class="btn btn-sm btn-primary">Add Property</a>
                    </div>
                    
                    <h2>List of Registered Properties</h2>
                </div>
                	
						<table id="hmis_table" class="table table-vcenter table-condensed table-bordered">
							<thead>
								<tr>
									<th>No.</th>
									<th>Property Name</th>
									<th>Contact Name</th>
									<th>Contact Number</th>
									<th>Contact Email</th>
									<th>Country</th>
									<th>Status</th>
									<th>Owner</th>
									<th class="text-center">Actions</th>
								</tr>
							</thead>
							<tbody>
								<?php $i= 1; 
								foreach(HMIS\Properties::get_properties() as $row){
									$data=HMIS\Profiles::get_profile($_SESSION['UID']);
									$data2=HMIS\Profiles::get_profile($row['owner']);
									if($data['user_type']=='Admin' || $data['uid']==$row['owner']){
									  ($row['status']=="INACTIVE")?$status = '<span class="btn btn-warning btn-xs">OFFLINE</span>':$status = '<span class="btn btn-success btn-xs">ONLINE</span>';
									echo 
										'<tr> 
											<td>'.$i++.'</td>
											<td>'.$row['property_name'].'</td>
											<td>'.$row['contact_name'].'</td>
											<td>'.$row['contact_number'].'</td>
											<td>'.$row['contact_email'].'</td>
											<td>'.$row['country'].'</td>
											<td>'.$status.'</td>
											<td> '.$data2['first_name'].' '.$data2['middle_name'].' '.$data2['last_name'].'</td>
											<td width="10%">
												'.HMIS\btn($row['pid'],'properties','E').'
												'.HMIS\btn($row['pid'],'properties','D').'
											</td>
										</tr>';
								}}?>
							</tbody>
						</table>
            </div>
        </div>
			</form>
    </div>
    </div>
    
    <div id="pullup" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title"> Property Management</h4>
            </div>
            <!-- END Modal Header -->

            <!-- Modal Body -->
            <div class="modal-body"><div id="response"></div></div>
            <!-- END Modal Body -->
        </div>
    </div>
</div>
    
</div>





