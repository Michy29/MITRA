<?php
namespace HMIS;
header('Content-type: application/json; charset=UTF-8');
require_once('system/loader.php');
use G, Exception;
	$response = array();
	$error		='The specified record could not be deleted!';
	$success	='Record deleted Successfully.';
	if ($_POST['coreSTR']) {
		$array = explode('.', $_POST['coreSTR']);
		if($array[1]=='profiles'){
			try{Profiles::delete_profile($array[0]); $response['status']  = 'success';$response['message'] = $success; }
			catch(Exception $e){$response['status']  = 'danger';$response['message'] = $error;}
		}
		if($array[1]=='properties'){
			try{Properties::delete_property($array[0]); $response['status']  = 'success';$response['message'] = $success; }
			catch(Exception $e){$response['status']  = 'danger';$response['message'] = $error;}
		}
		if($array[1]=='rooms'){
			try{Properties::delete_room($array[0]); $response['status']  = 'success';$response['message'] = $success; }
			catch(Exception $e){$response['status']  = 'danger';$response['message'] = $error;}
		}
		if($array[1]=='reservations'){
			try{Reservation::cancel($array[0]); $response['status']  = 'success';$response['message'] = $success; }
			catch(Exception $e){$response['status']  = 'danger';$response['message'] = $error;}
		}
		
		//json output
		echo json_encode($response);	
	}
?>