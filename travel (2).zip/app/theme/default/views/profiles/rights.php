   <?php

EMIS\Staff::staff_c_u();
$data=EMIS\Staff::get_staff(G\path()['call_parts'][2],'rights');
$data2=EMIS\Staff::get_staff(G\path()['call_parts'][2]);

?>
   <div id="page-content">
    <div class="content-header">
        <div class="header-section">
            <h1>
                <i class="gi gi-parents"></i>Staff<br>
            </h1>
        </div>
    </div>
    <div class="block">
        <div class="row">
        
        <div class="col-sm-12">
            <div class="block">
                <div class="block-title">
                    <h2>Access Rights for <?=$data2['first_name'].' '.$data2['middle_name'].' '.$data2['last_name']?></h2>
                </div>
                 <form  method="post" >
	<fieldset>
	
		<input type="hidden" class="form-control" name="uid" value="<?=G\path()['call_parts'][2]?>">
<div class="form-group col-md-3">
	<label class="control-label">Staff Menu:</label>
	<select class="form-control" name="staff_menu">
	    <option><?=$data['staff_menu']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Transporters Menu:</label>
	<select class="form-control" name="transporters_menu">
	    <option><?=$data['transporters_menu']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Farmers Menu:</label>
	<select class="form-control" name="farmers_menu">
	    <option><?=$data['farmers_menu']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Consignees Menu:</label>
	<select class="form-control" name="consignees_menu">
	    <option><?=$data['consignees_menu']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Consignments Menu:</label>
	<select class="form-control" name="consignments_menu">
	    <option><?=$data['consignments_menu']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Billing Menu:</label>
	<select class="form-control" name="billing_menu">
	    <option><?=$data['billing_menu']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Transactions Menu:</label>
	<select class="form-control" name="transactions_menu">
	    <option><?=$data['transactions_menu']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Reports Menu:</label>
	<select class="form-control" name="reports_menu">
	    <option><?=$data['reports_menu']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Settings Menu:</label>
	<select class="form-control" name="settings_menu">
	    <option><?=$data['settings_menu']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Add Staff:</label>
	<select class="form-control" name="add_staff">
	    <option><?=$data['add_staff']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Edit Staff:</label>
	<select class="form-control" name="edit_staff">
	    <option><?=$data['edit_staff']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">View Staff:</label>
	<select class="form-control" name="view_staff">
	    <option><?=$data['view_staff']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Delete Staff:</label>
	<select class="form-control" name="delete_staff">
	    <option><?=$data['delete_staff']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Add Transporter:</label>
	<select class="form-control" name="add_transporter">
	    <option><?=$data['add_transporter']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Edit  Transporter:</label>
	<select class="form-control" name="edit_transporter">
	    <option><?=$data['edit_transporter']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">View Transporter:</label>
	<select class="form-control" name="view_transporter">
	    <option><?=$data['view_transporter']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Delete Transporter:</label>
	<select class="form-control" name="delete_transporter">
	    <option><?=$data['delete_transporter']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Manage Vehicles:</label>
	<select class="form-control" name="manage_vehicles">
	    <option><?=$data['manage_vehicles']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Add Farmer:</label>
	<select class="form-control" name="add_farmer">
	    <option><?=$data['add_farmer']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Edit Farmer:</label>
	<select class="form-control" name="edit_farmer">
	    <option><?=$data['edit_farmer']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">View Farmer:</label>
	<select class="form-control" name="view_farmer">
	    <option><?=$data['view_farmer']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Delete Farmer:</label>
	<select class="form-control" name="delete_farmer">
	    <option><?=$data['delete_farmer']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Add Consignee:</label>
	<select class="form-control" name="add_consignee">
	    <option><?=$data['add_consignee']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Edit Consignee:</label>
	<select class="form-control" name="edit_consignee">
	    <option><?=$data['edit_consignee']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">View Consignee:</label>
	<select class="form-control" name="view_consignee">
	    <option><?=$data['view_consignee']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Delete Consignee:</label>
	<select class="form-control" name="delete_consignee">
	    <option><?=$data['delete_consignee']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Add Consignments:</label>
	<select class="form-control" name="add_consignments">
	    <option><?=$data['add_consignments']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Edit Consignments:</label>
	<select class="form-control" name="edit_consignments">
	    <option><?=$data['edit_consignments']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">View Consignments:</label>
	<select class="form-control" name="view_consignments">
	    <option><?=$data['view_consignments']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Delete Consignments:</label>
	<select class="form-control" name="delete_consignments">
	    <option><?=$data['delete_consignments']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Create Invoice:</label>
	<select class="form-control" name="create_invoice">
	    <option><?=$data['create_invoice']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Receive Payment:</label>
	<select class="form-control" name="receive_payment">
	    <option><?=$data['receive_payment']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Make Payment:</label>
	<select class="form-control" name="make_payment">
	    <option><?=$data['make_payment']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Add Expense:</label>
	<select class="form-control" name="add_expense">
	    <option><?=$data['add_expense']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Edit Transaction:</label>
	<select class="form-control" name="edit_transaction">
	    <option><?=$data['edit_transaction']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
<div class="form-group col-md-3">
	<label class="control-label">Delete Transaction:</label>
	<select class="form-control" name="delete_transaction">
	    <option><?=$data['delete_transaction']?></option>
	    <option>YES</option>
	    <option>NO</option>
	</select>
</div>
                    
                    
                    
                    
                    
                    

</fieldset>
                   
 <div class="form-group form-actions">
                        <div class="col-xs-12 text-right">
                           <button type="submit" name="btn_rights" class="btn btn-sm btn-primary">Submit</button>
                            <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </form>
                    
            </div>
        </div>
			</form>
    </div>
    </div>










</div>