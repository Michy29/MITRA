<!-- Revolution Slider -->
<section class="revolution-slider">
  <div class="bannercontainer">
    <div class="banner">
      <ul>
        <!-- Slide 1 -->
        <li data-transition="fade" data-slotamount="7" data-masterspeed="1500" > 
          <img src="content/other/slider0.jpg" style="opacity:0;" alt="slidebg1"  data-bgfit="cover" data-bgposition="left bottom" data-bgrepeat="no-repeat"> 
        </li>
		<!-- Slide 2 -->
        <li data-transition="boxfade" data-slotamount="7" data-masterspeed="1000" > 
          <img src="content/other/slider1.jpg"  alt="darkblurbg"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat"> 
        </li>
      </ul>
    </div>
  </div>
</section>

<!-- Reservation form -->


<!-- Rooms -->
<section class="rooms mt50">
  <div class="container">
    <div class="row">
      <div class="col-sm-12">
        <h2 class="lined-heading"><span>Guests Favorite Rooms</span></h2>
      </div>
      <!-- Room -->
      <?php  
		foreach(HMIS\Web::favorite(9) as $row){?>
			 <div class="col-sm-4">
				<div class="room-thumb"> <img src="content/rooms/<?=$row['room_pic_1']?>" class="img-responsive" />
			  <div class="top-left"><button class="btn btn-xs btn-info"><?=$row['property_name'].' <i class="fa fa-minus"></i> '.$row['city']?></button></div>
				  <div class="mask">
					<div class="main">
					  <h5><?=$row['room_name']?></h5>
					  <div class="price">KSH. <?=$row['price_per_night']?><span>a night</span></div>
					</div>
					<div class="content">
				  	<p><span><?=$row['room_type']?></span> <?=substr($row['description'],0,200)?></p>
					  <?=HMIS\Web::facilities($row['room_id'],'sub')?>
					  <a href="<?=ROOT_URL?>?route=roomview&id=<?=$row['room_id']?>" class="btn btn-primary btn-block">BOOK NOW</a>
					</div>
				  </div>
				</div>
			  </div>
		<?php }?>
    </div>
  </div>
</section>

<!-- USP's -->


<!-- Parallax Effect -->
<script type="text/javascript">$(document).ready(function(){$('#parallax-image').parallax("50%", -0.25);});</script>

<section class="parallax-effect mt100">
  <div id="parallax-image" style="background-image: url(<?=ROOT_URL?>content/other/bg1.jpg);">
    <div class="color-overlay fadeIn appear" data-start="600">
      <div class="container">
        <div class="content">
          <h3 class="text-center"> <?=G\get_app_setting('company_name')?></h3>
		  <p class="text-center"><br>
		  <a href="<?=ROOT_URL?>?route=rooms" class="btn btn-default btn-lg mt30">See rooms</a></p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Gallery -->



