<?php

namespace HMIS;
use G, Exception;

class Setup {

	private static $table = 'config';
	public static function read_configurations() {
		foreach(DB::ReadMulti(self::$table) as $data){
			$values[$data['config_name']]  = $data['config_value'];
		}
		return $values;
	}
	public static function update_configurations() {
		$DB=DB::vanillaDB();
		$DB->query('SELECT * FROM '.G\DB::getTable(self::$table).'');
		foreach($DB->resultset() as $data){
			if(isset($_POST[$data['config_name']])){
				$DB->query('UPDATE '.G\DB::getTable(self::$table).' SET config_value=:config_value WHERE id=:id');
				$DB->bind(':config_value', $_POST[$data['config_name']]);
				$DB->bind(':id', $data['id']);
				$DB->execute();	
			}
		}
	  $GLOBALS['success']='Configuration file updated successfully';
	}
	
}
