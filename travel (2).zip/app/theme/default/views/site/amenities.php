   <?=HMIS\Amenity::amenity_c_u()?>
   <div id="page-content">
    <div class="content-header">
        <div class="header-section">
            <h1>
                <i class="fa fa-shopping-basket"></i>Amenities<br>
            </h1>
        </div>
    </div>
    <div class="block">
        <div class="row">
        
        <div class="col-sm-8">
            <div class="block">
                <div class="block-title">
                   	<div class="block-options pull-right">
                        <?php// if($_SESSION['R']['add_farmer']=='YES'){?>
                        	<a href="#amenities" data-toggle="modal" onClick="page_loader('<?=G\path()['call_parts'][0]?>','reg_amenity','A<?=G\DB::Encoder('amenities')?>')" class="btn btn-sm btn-primary">Add Amenity</a>
                        <?php// }?>
                    </div>
                    
                    <h2>List of Amenities</h2>
                </div>
                
                
						<table id="emis_table" class="table table-vcenter table-condensed table-bordered">
							<thead>
								<tr>
									<th>Icon</th>
									<th>Amenity</th>
									<th>Description</th>
									<th class="text-center">Actions</th>
								</tr>
							</thead>
							<tbody></tbody>
						</table>
           		
            </div>
        </div>
			</form>
    </div>
    </div>
    
    <div id="amenities" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title"> Manage Amenity</h4>
            </div>
            <!-- END Modal Header -->

            <!-- Modal Body -->
            <div class="modal-body"><div id="response"></div></div>
            <!-- END Modal Body -->
        </div>
    </div>
</div>
    
</div>
 



