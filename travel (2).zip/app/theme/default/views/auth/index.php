<?php EMIS\Auth::SessionKing();?>
	
<!DOCTYPE html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <title><?=G\get_app_setting('applongname')?></title>
		<meta name="description" content="<?=G\get_app_setting('description')?>">
		<meta name="author" content="<?=G\get_app_setting('developer')?>">
		<meta name="robots" content="<?=G\get_app_setting('robots')?>">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <link rel="shortcut icon" href="<?=G\Render\get_theme_file_url('assets/img/favicon.png')?>">
		<link rel="stylesheet" href="<?=G\Render\get_theme_file_url('assets/css/bootstrap.min.css')?>">
		<link rel="stylesheet" href="<?=G\Render\get_theme_file_url('assets/css/plugins.css')?>">
        <link rel="stylesheet" href="<?=G\Render\get_theme_file_url('assets/css/main.css')?>">
		<?php if (G\get_app_setting('sub_theme')) { ?>
        <link id="theme-link" rel="stylesheet" href="<?=G\Render\get_theme_file_url('assets/css/themes/'.G\get_app_setting('sub_theme'))?>.css">
        <?php } ?>
        <link rel="stylesheet" href="<?=G\Render\get_theme_file_url('assets/css/themes.css')?>">
        <script src="<?=G\Render\get_theme_file_url('assets/js/vendor/modernizr.min.js')?>"></script>
    </head>
    <body>
<img src="<?=G\Render\get_theme_file_url('assets/img/placeholders/backgrounds/login_full_bg.jpg')?>" alt="Login Full Background" class="full-bg animation-pulseSlow">
<div id="login-container" class="animation-fadeIn">
    <!-- Login Title -->
    <div class="login-title text-center">
        <h1> <strong><?=G\get_app_setting('appshortname')?></strong><br></h1>
    </div>
    <!-- END Login Title -->

    <!-- Login Block -->
    <div class="block push-bit">
        <!-- Login Form -->
        <form  method="post" id="form-login" class="form-horizontal form-bordered form-control-borderless">
            <div class="form-group">
                <div class="col-xs-12">
                    <div class="input-group">
                        <input type="text" id="login-email" name="email" class="form-control input-lg" placeholder="Email Address">
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="col-xs-12">
                    <div class="input-group">
                        <input type="password" id="login-password" name="password" class="form-control input-lg" placeholder="Password">
                    </div>
                </div>
            </div>
            <div class="form-group form-actions">
                <div class="col-xs-12 text-right">
                    <button type="submit" name="login" class="btn btn-sm btn-primary"> Login to Dashboard</button>
                </div>
            </div>
            <div class="form-group">
                <div class="col-xs-12 text-center">
                    <a href="javascript:void(0)" id="link-reminder-login"><small>Forgot password?</small></a> -
                    <a href="javascript:void(0)" id="link-register-login"><small>Activate account</small></a>
                </div>
            </div>
        </form>
        <!-- END Login Form -->

        <!-- Reminder Form -->
        <form action="#reminder" method="post" id="form-reminder" class="form-horizontal form-bordered form-control-borderless display-none">
            <div class="form-group">
                <div class="col-xs-12">
                    <div class="input-group">
                        <input type="text" name="email" class="form-control input-lg" placeholder="Email">
                    </div>
                </div>
            </div>
            <div class="form-group form-actions">
                <div class="col-xs-12 text-right">
                    <button type="submit" name="reset" class="btn btn-sm btn-primary"> Reset Password</button>
                </div>
            </div>
            <div class="form-group">
                <div class="col-xs-12 text-center">
                    <small>Did you remember your password?</small> <a href="javascript:void(0)" id="link-reminder"><small>Login</small></a>
                </div>
            </div>
        </form>
        <!-- END Reminder Form -->

        <!-- Register Form -->
        <form action="#register" method="post" id="form-register"  class="form-horizontal form-control-borderless display-none">
            <div class="form-group">
                <div class="col-xs-12">
                    <div class="input-group">
                        <input type="text"  name="email" class="form-control input-lg" placeholder="Email Address">
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="col-xs-12">
                    <div class="input-group">
                        <input type="text"  name="mobile_no" class="form-control input-lg" placeholder="Mobile Number">
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="col-xs-12">
                    <div class="input-group">
                        <input type="password" name="password" class="form-control input-lg" placeholder="Password">
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="col-xs-12">
                    <div class="input-group">
                        <input type="password"  name="confirm_password" class="form-control input-lg" placeholder="Verify Password">
                    </div>
                </div>
            </div>
            <div class="form-group form-actions">
                
                <div class="col-xs-12 text-right">
                    <button type="submit" name="register" class="btn btn-sm btn-primary">  Activate Account</button>
                </div>
            </div>
            <div class="form-group">
                <div class="col-xs-12 text-center">
                    <small>Account active?</small> <a href="javascript:void(0)" id="link-register"><small> Login</small></a>
                </div>
            </div>
        </form>
        <!-- END Register Form -->
    </div>
    <!-- END Login Block -->
</div>
<!-- END Login Container -->


<script src="<?=G\Render\get_theme_file_url('assets/js/vendor/jquery.min.js')?>"></script>
<script src="<?=G\Render\get_theme_file_url('assets/js/vendor/bootstrap.min.js')?>"></script>
<script src="<?=G\Render\get_theme_file_url('assets/js/plugins.js')?>"></script>
<script src="<?=G\Render\get_theme_file_url('assets/js/app.js')?>"></script>
<script src="<?=G\Render\get_theme_file_url('assets/js/pages/login.js')?>"></script>
<script>$(function(){ Login.init(); });</script>
   <script>
<?php if(isset($GLOBALS['success'])){?>	
$.bootstrapGrowl("<?=$GLOBALS['success']?>", {
    ele: 'body', type: 'success', offset: {from: 'top', amount: 50}, align: 'right', width: 350, delay: 9000, allow_dismiss: true,stackup_spacing: 10 
});
	<?php }elseif(isset($GLOBALS['error'])){?>
$.bootstrapGrowl("<?=$GLOBALS['error']?>", {
    ele: 'body', type: 'danger', offset: {from: 'top', amount: 50}, align: 'right', width: 350,delay: 9000, allow_dismiss: true, stackup_spacing: 10 
});
	<?php }?>
</script>
    </body>
</html>