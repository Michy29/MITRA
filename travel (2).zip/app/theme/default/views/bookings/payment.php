 <form  method="post" >
 <?php $data=HMIS\Reservation::get_reservation($_POST["id"]);
	 
	 ?>
	<fieldset>
	<div class="row">
          
            <div class="col-md-6">
              <div class="form-group">
                <label for="name" accesskey="U"> Client</label>
                <input name="name" type="text" readonly class="form-control" value="<?=$data['first_name']?> <?=$data['middle_name']?> <?=$data['last_name']?>"/>
                <input name="book_id" type="hidden"  value="<?=$data['book_id']?>" class="form-control"/>
                <input name="payid" type="hidden"  value="<?=G\DB::Encoder('payments')?>" class="form-control"/>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label for="email" accesskey="E"> E-mail</label>
                <input name="email" type="text" readonly  value="<?=$data['email']?>" class="form-control"/>
              </div>
            </div>
          </div>
			<div class="row">
            <div class="col-md-4">
              <div class="form-group">
                <label for="name" accesskey="U"> Hotel</label>
                <input type="text" readonly class="form-control" value="<?=$data['property_name']?>"/>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label for="email" accesskey="E"> Room</label>
                <input readonly type="text"  value="<?=$data['room_name']?>" class="form-control"/>
                <input name="room_id" type="hidden"  value="<?=$data['room_id']?>" class="form-control"/>
                <input name="uid" type="hidden"  value="<?=$data['uid']?>" class="form-control"/>
                <input name="paydate" type="hidden"  value="<?=date('Y-m-d')?>" class="form-control"/>
                
              </div>
            </div>
			<div class="col-md-2">
              <div class="form-group">
                <label > No. of Rooms</label>
                <input name="no_of_rooms" type="text" readonly  value="<?=$data['no_of_rooms']?>" class="form-control"/>
              </div>
            </div>
            <div class="col-md-2">
              <div class="form-group">
                <label > Guests</label>
                <input name="no_of_guests" type="text" readonly  value="<?=$data['children']+$data['adults']?>" class="form-control"/>
              </div>
            </div>
          </div>
          
		<div class="row">
            <div class="col-md-3">
              <div class="form-group">
                <label > Payment Mode</label>
                <select class="form-control" name="payment_mode">
                	<option></option>
                	<option>CASH</option>
                	<option>MOBILE MONEY TRANSFER</option>
                	<option>CREDIT/DEBIT CARD</option>
                </select>
              </div>
            </div>
            
			<div class="col-md-3">
              <div class="form-group">
                <label for="name" accesskey="U"> Checkin Date</label>
                <input name="checkin" type="text" readonly class="form-control" value="<?=$data['checkin']?>"/>
              </div>
            </div>
            <div class="col-md-3">
              <div class="form-group">
                <label for="email" accesskey="E"> Checkout Date</label>
                <input name="checkout" type="text" readonly  value="<?=$data['checkout']?>" class="form-control"/>
              </div>
            </div>
			<div class="col-md-3">
              <div class="form-group">
                <label>Total Amount Payable</label>
                <input name="due" type="text" readonly  value="<?=($data['total_amount'])?>" class="form-control"/>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label>Amount Being Paid</label>
                <input name="paid" type="text"   value="<?=$data['paid']?>" class="form-control"/>
              </div>
            </div>
             <div class="col-md-6">
              <div class="form-group">
                <label>Transaction Number</label>
                <input name="transaction_no" type="text"   value="<?=$data['transaction_no']?>" class="form-control"/>
              </div>
            </div>
            	
          </div>
 </fieldset>
 					<div class="form-group form-actions">
                        <div class="col-xs-12 text-right">
                           <button type="submit" name="btn_pay" class="btn btn-sm btn-primary">Complete Payment</button>
                            <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </form>
                    