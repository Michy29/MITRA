<option>Budget Single Room</option> 
<option>Deluxe Single Room</option> 
<option>Large Single Room</option>
<option>Deluxe Single Room with Balcony</option>
<option>Deluxe Single Room with Sea View</option>
<option>Economy Single Room</option>
<option>Small Single Room</option>
<option>Budget Double Room</option>
<option>Business Double Room</option>
<option>Deluxe Double Room</option>
<option>Deluxe King Room</option>
<option>Deluxe Queen Room</option>
<option>Double Room - Disability Access</option>
<option>Economy Double Room</option>
<option>King Room</option>
<option>King Room - Disability Access</option>
<option>Large Double Room</option>
<option>Queen Room</option>
<option>Queen Room - Disability Access</option>
<option>Small Double Room</option>
<option>Standard Double Room</option>
<option>Standard King Room</option>
<option>Standard Queen Room</option>
<option>Superior Double Room</option>
<option>Superior King Room</option>
<option>Superior Queen Room</option>
<option>Budget Twin Room</option>
<option>Deluxe Twin Room</option>
<option>Economy Twin Room</option>
<option>King Room with Two King Beds</option>
<option>Large Twin Room</option>
<option>Queen Room with Two Queen Beds</option>
<option>Queen Room with Two Queen Beds - Disability Access</option>
<option>Small Twin Room</option>
<option>Standard Twin Room</option>
<option>Superior Queen Room with Two Queen Beds</option>
<option>Superior Twin Room</option>
<option>Twin Room - Disability Access</option>
<option>Basic Triple Room</option>
<option >Budget Triple Room</option>
<option>Classic Triple Room</option>
<option>Comfort Triple Room</option>
<option>Deluxe Triple Room</option>
<option>Economy Triple Room</option>
<option>Executive Triple Room</option>
<option>Luxury Triple Room</option>
<option>Standard Triple Room</option>
<option>Superior Triple Room</option>
<option >Triple Room</option>
<option>Triple Room - Disability Access</option>
<option>Classic Quadruple Room</option>
<option>Comfort Quadruple Room</option>
<option>Deluxe Quadruple Room</option>
<option>Deluxe Queen Room with Two Queen Beds</option>
<option>Duplex Quadruple Room</option>
<option>Economy Quadruple Room</option>
<option>Executive Queen Room with Two Queen Beds</option>
<option>Japanese-Style Quadruple Room</option>
<option>King Room with Two King Beds</option>
<option>Luxury Quadruple Room</option>
<option>Premium Quadruple Room</option>
<option>Quadruple Room</option>
<option>Quadruple Room - Disability Access</option>
<option>Queen Room with Two Queen Beds</option>
<option>Queen Room with Two Queen Beds - Disability Access</option>
<option>Standard Quadruple Room</option>
<option>Superior Quadruple Room</option>
<option>Deluxe Family Room</option>
<option>Deluxe Family Suite</option>
<option>Family Bungalow</option>
<option>Family Cabin on Boat</option>
<option>Family Double Room</option>
<option>Family Junior Suite</option>
<option>Family Room</option>
<option>Family Room - Disability Access</option>
<option>Family Studio</option>
<option>Family Suite</option>
<option>Family Suite with Balcony</option>
<option>Standard Family Room</option>
<option>Superior Family Room</option>
<option>Deluxe Double Studio</option>
<option>Deluxe Junior Suite</option>
<option>Deluxe King Studio</option>
<option>Deluxe King Suite</option>
<option>Deluxe Queen Studio </option>
<option>Deluxe Queen Suite</option>
<option>Deluxe Studio</option>
<option>Deluxe Suite</option>
<option>Duplex Suite</option>
<option>Executive Suite</option>
<option>Family Studio</option>
<option>Family Suite</option>
<option>Junior Suite</option>
<option>King Studio</option>
<option>King Suite</option>
<option>One-Bedroom Suite</option>
<option>Presidential Suite</option>
<option>Queen Suite</option>
<option>Standard Double Suite</option>
<option>Standard Studio</option>
<option>Standard Suite</option>
<option>Standard Triple Studio</option>
<option>Studio</option>
<option>Studio - Disability Access</option>
<option>Superior King Suite</option>
<option>Superior Studio</option>
<option>Superior Suite</option>
<option>Three-Bedroom Suite</option>
<option>Two-Bedroom Suite</option>
<option>Deluxe Double Studio</option>
<option>Deluxe King Studio</option>
<option>Deluxe Queen Studio </option>
<option>Deluxe Studio</option>
<option>Duplex Studio</option>
<option>Family Studio</option>
<option>King Studio</option>
<option>Queen Studio</option>
<option>Queen Studio - Disability Access</option>
<option>Apartment</option>
<option>Apartment - Ground Floor</option>
<option>Apartment - Split Level</option>
<option>Deluxe Apartment</option>
<option>Duplex Apartment</option>
<option>Loft</option>
<option>Maisonette</option>
<option>One-Bedroom Apartment</option>
<option>Penthouse Apartment</option>
<option>Standard Apartment</option>
<option>Studio Apartment</option>
<option>Superior Apartment</option>
<option>Three-Bedroom Apartment</option>
<option>Two-Bedroom Apartment</option>
<option>10-Bed Female Dormitory Room</option>
<option>10-Bed Male Dormitory Room</option>
<option>10-Bed Mixed Dormitory Room</option>
<option>4-Bed Female Dormitory Room</option>
<option>4-Bed Male Dormitory Room </option>
<option>4-Bed Mixed Dormitory Room</option>
<option>6-Bed Female Dormitory Room</option>
<option>6-Bed Male Dormitory Room</option>
<option>6-Bed Mixed Dormitory Room</option>
<option>8-Bed Female Dormitory Room</option>
<option>8-Bed Male Dormitory Room</option>
<option>8-Bed Mixed Dormitory Room</option>
<option>Female Dormitory Room</option>
<option>Male Dormitory Room</option>
<option>Mixed Dormitory Room</option>