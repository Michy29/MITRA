
<!-- Parallax Effect -->
<script type="text/javascript">$(document).ready(function(){$('#parallax-pagetitle').parallax("50%", -0.55);});</script>

<section class="parallax-effect">
  <div id="parallax-pagetitle" style="background-image: url(./images/parallax/1900x911.gif);">
    <div class="color-overlay"> 
      <!-- Page title -->
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <h1>Rooms </h1>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Filter -->
<div class="container">
  <div class="row">
    <div class="col-sm-12">
      <ul class="nav nav-pills" id="filters">
        <li class="active"><a href="#" data-filter="*">All</a></li>
        <li><a href="#" data-filter=".single">Single Room</a></li>
        <li><a href="#" data-filter=".double">Double Room</a></li>
        <li><a href="#" data-filter=".twin">Twin</a></li>
        <li><a href="#" data-filter=".triple">Triple</a></li>
        <li><a href="#" data-filter=".quadruple">Quadruple</a></li>
        <li><a href="#" data-filter=".family">Family</a></li>
        <li><a href="#" data-filter=".suite">Suite</a></li>
        <li><a href="#" data-filter=".studio">Studio</a></li>
        <li><a href="#" data-filter=".dormitory">Dormitory</a></li>
        <li><a href="#" data-filter=".apartment">Apartment</a></li>
      </ul>
    </div>
  </div>
</div>

<!-- Rooms -->
<section class="rooms mt100">
  <div class="container">
    <div class="row room-list fadeIn appear"> 
      <!-- Room -->
      <?php foreach(HMIS\Web::rooms('Single Room') as $row){?>
      <div class="col-sm-4 single">
        <div class="room-thumb"> <img width="356" height="228" src="content/rooms/<?=$row['room_pic_1']?>"  class="img-responsive" />
         <div class="top-left"><button class="btn btn-xs btn-info"><?=$row['property_name'].' <i class="fa fa-minus"></i> '.$row['city']?></button></div>
          <div class="mask">
            <div class="main">
              <h5><?=$row['room_name']?></h5>
              <div class="price">KSH. <?=$row['price_per_night']?><span>a night</span></div>
            </div>
            <div class="content">
              <p><?=substr($row['description'],0,200)?></p>
              <?=HMIS\Web::facilities($row['room_id'],'sub')?>
              <a href="<?=ROOT_URL?>?route=roomview&id=<?=$row['room_id']?>" class="btn btn-primary btn-block">Book Now</a> </div>
          </div>
        </div>
      </div>
      <?php }?>
      <!-- Room -->
      <?php foreach(HMIS\Web::rooms('Double Room') as $row){?>
      <div class="col-sm-4 double">
        <div class="room-thumb"> <img width="356" height="228" src="content/rooms/<?=$row['room_pic_1']?>"  class="img-responsive" />
         <div class="top-left"><button class="btn btn-xs btn-info"><?=$row['property_name'].' <i class="fa fa-minus"></i> '.$row['city']?></button></div>
            <div class="mask">
            <div class="main">
              <h5><?=$row['room_name']?></h5>
              <div class="price">KSH. <?=$row['price_per_night']?><span>a night</span></div>
            </div>
            <div class="content">
              <p><?=substr($row['description'],0,200)?></p>
              <?=HMIS\Web::facilities($row['room_id'],'sub')?>
              <a href="<?=ROOT_URL?>?route=roomview&id=<?=$row['room_id']?>" class="btn btn-primary btn-block">Book Now</a> </div>
          </div>
        </div>
      </div>
      <?php }?>
      <!-- Room -->
      <?php foreach(HMIS\Web::rooms('Twin') as $row){?>
      <div class="col-sm-4 twin">
        <div class="room-thumb"> <img width="356" height="228" src="content/rooms/<?=$row['room_pic_1']?>"  class="img-responsive" />
         <div class="top-left"><button class="btn btn-xs btn-info"><?=$row['property_name'].' <i class="fa fa-minus"></i> '.$row['city']?></button></div> <div class="mask">
            <div class="main">
              <h5><?=$row['room_name']?></h5>
              <div class="price">KSH. <?=$row['price_per_night']?><span>a night</span></div>
            </div>
            <div class="content">
              <p><?=substr($row['description'],0,200)?></p>
              <?=HMIS\Web::facilities($row['room_id'],'sub')?>
              <a href="<?=ROOT_URL?>?route=roomview&id=<?=$row['room_id']?>" class="btn btn-primary btn-block">Book Now</a> </div>
          </div>
        </div>
      </div>
      <?php }?>
      <!-- Room -->
      <?php foreach(HMIS\Web::rooms('Triple') as $row){?>
      <div class="col-sm-4 triple">
        <div class="room-thumb"> <img width="356" height="228" src="content/rooms/<?=$row['room_pic_1']?>"  class="img-responsive" />
         <div class="top-left"><button class="btn btn-xs btn-info"><?=$row['property_name'].' <i class="fa fa-minus"></i> '.$row['city']?></button></div> <div class="mask">
            <div class="main">
              <h5><?=$row['room_name']?></h5>
              <div class="price">KSH. <?=$row['price_per_night']?><span>a night</span></div>
            </div>
            <div class="content">
              <p><?=substr($row['description'],0,200)?></p>
             <?=HMIS\Web::facilities($row['room_id'],'sub')?>
              <a href="<?=ROOT_URL?>?route=roomview&id=<?=$row['room_id']?>" class="btn btn-primary btn-block">Book Now</a> </div>
          </div>
        </div>
      </div>
      <?php }?>
      <!-- Room -->
      <?php foreach(HMIS\Web::rooms('Quadruple') as $row){?>
      <div class="col-sm-4 quadruple">
        <div class="room-thumb"> <img width="356" height="228" src="content/rooms/<?=$row['room_pic_1']?>"  class="img-responsive" />
         <div class="top-left"><button class="btn btn-xs btn-info"><?=$row['property_name'].' <i class="fa fa-minus"></i> '.$row['city']?></button></div> <div class="mask">
            <div class="main">
              <h5><?=$row['room_name']?></h5>
              <div class="price">KSH. <?=$row['price_per_night']?><span>a night</span></div>
            </div>
            <div class="content">
              <p><?=substr($row['description'],0,200)?></p>
              <?=HMIS\Web::facilities($row['room_id'],'sub')?>
              <a href="<?=ROOT_URL?>?route=roomview&id=<?=$row['room_id']?>" class="btn btn-primary btn-block">Book Now</a> </div>
          </div>
        </div>
      </div>
      <?php }?>
      <!-- Room -->
      <?php foreach(HMIS\Web::rooms('Family') as $row){?>
      <div class="col-sm-4 family">
        <div class="room-thumb"> <img width="356" height="228" src="content/rooms/<?=$row['room_pic_1']?>"  class="img-responsive" />
         <div class="top-left"><button class="btn btn-xs btn-info"><?=$row['property_name'].' <i class="fa fa-minus"></i> '.$row['city']?></button></div> <div class="mask">
            <div class="main">
              <h5><?=$row['room_name']?></h5>
              <div class="price">KSH. <?=$row['price_per_night']?><span>a night</span></div>
            </div>
            <div class="content">
              <p><?=substr($row['description'],0,200)?></p>
              <?=HMIS\Web::facilities($row['room_id'],'sub')?>
              <a href="<?=ROOT_URL?>?route=roomview&id=<?=$row['room_id']?>" class="btn btn-primary btn-block">Book Now</a> </div>
          </div>
        </div>
      </div>
      <?php }?>
      <!-- Room -->
      <?php foreach(HMIS\Web::rooms('Suite') as $row){?>
      <div class="col-sm-4 suite">
        <div class="room-thumb"> <img width="356" height="228" src="content/rooms/<?=$row['room_pic_1']?>"  class="img-responsive" />
         <div class="top-left"><button class="btn btn-xs btn-info"><?=$row['property_name'].' <i class="fa fa-minus"></i> '.$row['city']?></button></div> <div class="mask">
            <div class="main">
              <h5><?=$row['room_name']?></h5>
              <div class="price">KSH. <?=$row['price_per_night']?><span>a night</span></div>
            </div>
            <div class="content">
              <p><?=substr($row['description'],0,200)?></p>
              <?=HMIS\Web::facilities($row['room_id'],'sub')?>
              <a href="<?=ROOT_URL?>?route=roomview&id=<?=$row['room_id']?>" class="btn btn-primary btn-block">Book Now</a> </div>
          </div>
        </div>
      </div>
      <?php }?>
      <!-- Room -->
      <?php foreach(HMIS\Web::rooms('Studio') as $row){?>
      <div class="col-sm-4 studio">
        <div class="room-thumb"> <img width="356" height="228" src="content/rooms/<?=$row['room_pic_1']?>"  class="img-responsive" />
         <div class="top-left"><button class="btn btn-xs btn-info"><?=$row['property_name'].' <i class="fa fa-minus"></i> '.$row['city']?></button></div> <div class="mask">
            <div class="main">
              <h5><?=$row['room_name']?></h5>
              <div class="price">KSH. <?=$row['price_per_night']?><span>a night</span></div>
            </div>
            <div class="content">
              <p><?=substr($row['description'],0,200)?></p>
              <?=HMIS\Web::facilities($row['room_id'],'sub')?>
              <a href="<?=ROOT_URL?>?route=roomview&id=<?=$row['room_id']?>" class="btn btn-primary btn-block">Book Now</a> </div>
          </div>
        </div>
      </div>
      <?php }?>
      <!-- Room -->
      <?php foreach(HMIS\Web::rooms('Apartment') as $row){?>
      <div class="col-sm-4 apartment">
        <div class="room-thumb"> <img width="356" height="228" src="content/rooms/<?=$row['room_pic_1']?>"  class="img-responsive" />
         <div class="top-left"><button class="btn btn-xs btn-info"><?=$row['property_name'].' <i class="fa fa-minus"></i> '.$row['city']?></button></div> <div class="mask">
            <div class="main">
              <h5><?=$row['room_name']?></h5>
              <div class="price">KSH. <?=$row['price_per_night']?><span>a night</span></div>
            </div>
            <div class="content">
              <p><?=substr($row['description'],0,200)?></p>
              <?=HMIS\Web::facilities($row['room_id'],'sub')?>
              <a href="<?=ROOT_URL?>?route=roomview&id=<?=$row['room_id']?>" class="btn btn-primary btn-block">Book Now</a> </div>
          </div>
        </div>
      </div>
      <?php }?>
      <!-- Room -->
      <?php foreach(HMIS\Web::rooms('Dormitory') as $row){?>
      <div class="col-sm-4 dormitory">
        <div class="room-thumb"> <img width="356" height="228" src="content/rooms/<?=$row['room_pic_1']?>"  class="img-responsive" />
         <div class="top-left"><button class="btn btn-xs btn-info"><?=$row['property_name'].' <i class="fa fa-minus"></i> '.$row['city']?></button></div> <div class="mask">
            <div class="main">
              <h5><?=$row['room_name']?></h5>
              <div class="price">KSH. <?=$row['price_per_night']?><span>a night</span></div>
            </div>
            <div class="content">
              <p><?=substr($row['description'],0,200)?></p>
              <?=HMIS\Web::facilities($row['room_id'],'sub')?>
              <a href="<?=ROOT_URL?>?route=roomview&id=<?=$row['room_id']?>" class="btn btn-primary btn-block">Book Now</a> </div>
          </div>
        </div>
      </div>
      <?php }?>
      
      
      
    </div>
  </div>
</section>
