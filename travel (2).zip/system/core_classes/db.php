<?php
namespace G;
use PDO, PDOException, Exception;

class DB{
private static $instance;
private $host 		= APP_DB_HOST;
private $port 		= APP_DB_PORT;
private $name 		= APP_DB_NAME;
private $user 		= APP_DB_USER;
private $pass 		= APP_DB_PASS;
private $driver 	= APP_DB_DRIVER;
private $pdo_attrs 	= APP_DB_PDO_ATTRS;
static 	$dbh;
public 	$query;
private $error;
private $stmt;

	public function __construct($conn=[]) {
		try {
			// PDO already connected
			if(empty($conn) and isset(self::$dbh) and get_class(self::$dbh) == 'PDO') {
				return TRUE;
			}

			if(!empty($conn)) {
				// Inject connection info
				foreach(['host', 'user', 'name', 'pass', 'port', 'driver', 'pdo_attrs'] as $k) {
					$this->{$k} = $conn[$k];
				}
			}

			$pdo_connect = $this->driver . ':host=' . $this->host . ';dbname=' . $this->name;
			if($this->port) {
				$pdo_connect .= ';port=' . $this->port;
			}
			
			$this->pdo_attrs = @unserialize($this->pdo_attrs) ?: $this->pdo_attrs;
			
			// PDO defaults
			$this->pdo_default_attrs = [
				PDO::ATTR_TIMEOUT		=> 30,
				//PDO::ATTR_PERSISTENT	=> FALSE
			];

			// Override PDO defaults ?
			$this->pdo_attrs = (is_array($this->pdo_attrs) ? $this->pdo_attrs : []) + $this->pdo_default_attrs;
			
			// PDO hard overrides
			$this->pdo_attrs[PDO::ATTR_ERRMODE] = PDO::ERRMODE_EXCEPTION;
			$this->pdo_attrs[PDO::MYSQL_ATTR_INIT_COMMAND] = "SET NAMES 'UTF8'";

			// Turn off PHP error reporting just for the connection here (invalid host names will trigger a PHP warning)
			$error_reporting = error_reporting();
			error_reporting(0);
			
			// Note that PDO::ERRMODE_SILENT has no effect on connection. Connections always throw an exception if it fails
			self::$dbh = new PDO($pdo_connect, $this->user, $this->pass, $this->pdo_attrs);
			
			// Re-enable the error_reporting level
			error_reporting($error_reporting);
			
			// PDO emulate prepares if needed
			if(version_compare(self::$dbh->getAttribute(PDO::ATTR_SERVER_VERSION), '5.1.17', '<')) {
				self::$dbh->setAttribute(PDO::ATTR_EMULATE_PREPARES, true);
			}
			
			self::$instance = $this;
			
		} catch(Exception $e) {
			self::$dbh = NULL;
			throw new DBException($e->getMessage(), 400);
		}
		
	}
	public static function getInstance() {
		if(is_null(self::$instance)) {
			self::$instance = new self;
		}
		return self::$instance;
	}
	public function setPDOAttrs($attributes) {
		$this->pdo_attrs = $attributes;
	}
	public function setPDOAttr($key, $value) {
		$this->pdo_attrs[$key] = $value;
	}
	public function getAttr($attr) {
		return self::$dbh->getAttribute($attr);
	}
	public function query($query) {
		$this->stmt = self::$dbh->prepare($query);
	}
	
	public function errorInfo() {
		return self::$dbh->errorInfo();
	}
	public function bind($param, $value, $type = null) {
		if(is_null($type)) {
			switch(true) {
				case is_int($value):
					$type = PDO::PARAM_INT;
				break;
				case is_bool($value):
					$type = PDO::PARAM_BOOL;
				break;
				case is_null($value):
					$type = PDO::PARAM_NULL;
				break;
				default:
					$type = PDO::PARAM_STR;
				break;
			}
		}
		$this->stmt->bindValue($param, $value, $type);
	}
	public function execute() {
		return $this->stmt->execute();
	}
	public function fetchColumn() {
		return $this->stmt->fetchColumn();
	}
	
	public function closeCursor() {
		return $this->stmt->closeCursor();
	}
	public function resultset($mode=PDO::FETCH_ASSOC) {
		$this->execute();
		return $this->stmt->fetchAll(is_int($mode) ? $mode : PDO::FETCH_ASSOC);
	}
	public function single($mode=PDO::FETCH_ASSOC) {
		$this->execute();
		return $this->stmt->fetch(is_int($mode) ? $mode : PDO::FETCH_ASSOC);
	}
	public static function queryExecute($query) {
		try {
			$db = self::getInstance();
			$db->stmt($query);
			return $db->execute() ? $db->rowCount() : FALSE;
		} catch(Exception $e) {
			throw new DBException($e->getMessage(), 400);
		}
	}
	public static function queryFetch($query, $limit=1, $fetch_style=NULL) {
		try {
			$db = self::getInstance();
			$db->stmt($query);
			return $limit == 1 ? $db->single($fetch_style) : $db->resulset($fetch_style);
		} catch(Exception $e) {
			throw new DBException($e->getMessage(), 400);
		}
	}
	public static function getSingle($query, $fetch_style=NULL) {
		try {
			return self::queryFetch($query, 1, $fetch_style);
		} catch(Exception $e) {
			throw new DBException($e->getMessage(), 400);
		}
	}
	public static function getAll($query, $fetch_style=NULL) {
		try {
			return self::queryFetch($query, NULL, $fetch_style);
		} catch(Exception $e) {
			throw new DBException($e->getMessage(), 400);
		}
	}
	public function rowCount() {
		return $this->stmt->rowCount();
	}
	public function lastInsertId() {
		return self::$dbh->lastInsertId();
	}
	public function beginTransaction(){
		return self::$dbh->beginTransaction();
	}
	public function endTransaction(){
		return self::$dbh->commit();
	}
	public function cancelTransaction(){
		return self::$dbh->rollBack();
	}
	public function debugDumpParams(){
		return $this->stmt->debugDumpParams();
	}
	//DEE CRUD Manipulation
	public static function getTable($table) {
		return get_app_setting('db_table_prefix') . $table;
	}
	public static function Create($table, $values) {
		if(!is_array($values)) {
			throw new DBException('Expecting array values, '.gettype($values).' given in '. __METHOD__, 100);
		}
		$table = DB::getTable($table);
		$table_fields = [];
		foreach($values as $k => $v) {
			$table_fields[] = $k;
		}
		$query = 'INSERT INTO 
					`'.$table.'` (`' . ltrim(implode('`,`', $table_fields), '`,`') . '`)
					VALUES (' . ':' . str_replace(':', ',:', implode(':', $table_fields)) . ')';
		try {
			$db = self::getInstance();
			$db->query($query);
			foreach($values as $k => $v) {
				$db->bind(':'.$k, $v);
			}
			return $db->execute() ? $db->lastInsertId() : FALSE;
		} catch(Exception $e) {
			throw new DBException($e->getMessage(), 400);
		}
	}
	public static function Encoder($table,$field='id')
	  {
		  $table = DB::getTable($table);
		  $query = 'SELECT MAX(cast('.$field.' as decimal)) '.$field.' FROM '.$table;
		  try {
			$db = self::getInstance();
			$db->query($query);
			$maxid = $db->single(null);
		} catch(Exception $e) {
			throw new DBException($e->getMessage(), 400);
		}
			$count = $maxid['id']; $count = $count+1;
			$code_no = str_pad($count,3, "0", STR_PAD_LEFT);
			return date('m').$code_no.date('y');
	  }
	public static function Read($table, $values='all', $limit=NULL,$start=null, $fetch_style=NULL,$order='id DESC') {
	//select * from $table ORDER BY '.$order[0].' '.strtoupper($order[1]).' = all(table,all,order=DESC)
		if(!is_array($values) and $values !== 'all') {
			throw new DBException('Expecting array values, '.gettype($values).' given in ' . __METHOD__, 100);
		}
		
		$table = DB::getTable($table);
		$query = 'SELECT * FROM '.$table;
		
		if(is_array($values) and !empty($values)) {
			$query .= ' WHERE ';
			foreach($values as $k => $v) {
				if(is_null($v)) {
					$query .= '`'.$k.'` IS :'.$k.' '.$clause.' ';
				} else {
					$query .= '`'.$k.'`=:'.$k.' '.$clause.' ';
				}
			}
		}
		//$query = rtrim($query, $clause . ' ');
		//if(is_array($sort) and !empty($sort)) {
			$query .= ' ORDER BY '.$order;
		//}
		if($limit and is_int($limit)) {
			$query .= ' LIMIT ';
		}
		if($start and is_int($start)) {
			$query .= $start.' , ';
		}
		if($limit and is_int($limit)) {
			$query .= $limit;
		}
		
		try {
			$db = self::getInstance();
			$db->query($query);
			if(is_array($values)) {
				foreach($values as $k => $v) {
					$db->bind(':'.$k, $v);
				}
			}
			return $limit == 1 ? $db->single($fetch_style) : $db->resultset($fetch_style);
		} catch(Exception $e) {
			throw new DBException($e->getMessage(), 400);
		}
	}
	public static function Update($table, $values, $wheres, $clause='AND') {
		if(!is_array($values)) {
			throw new DBException('Expecting array values, '.gettype($values).' given in '. __METHOD__, 100);
		}
		if(!is_array($wheres)) {
			throw new DBException('Expecting array values, '.gettype($wheres).' given in '. __METHOD__, 100);
		}
		self::validateClause($clause, __METHOD__);
		$table = DB::getTable($table);
		$query = 'UPDATE `'.$table.'` SET ';
		foreach($values as $k => $v) {
			$query .= '`' . $k . '`=:value_' . $k . ','; 
		}
		$query = rtrim($query, ',') . ' WHERE ';
		foreach($wheres as $k => $v) {
			$query .= '`'.$k.'`=:where_'.$k.' '.$clause.' '; 
		}			
		$query = rtrim($query, $clause.' ');
		try {
			$db = self::getInstance();
			$db->query($query);
			foreach($values as $k => $v) {
				$db->bind(':value_'.$k, $v);
			}
			foreach($wheres as $k => $v) {
				$db->bind(':where_'.$k, $v);
			}
			return $db->execute() ? $db->rowCount() : FALSE;
		} catch(Exception $e) {
			throw new DBException($e->getMessage(), 400);
		}

	}
	public static function Delete($table, $values, $clause='AND') {
		if(!is_array($values)) {
			throw new DBException('Expecting array values, '.gettype($values).' given in '. __METHOD__, 100);
		}
		self::validateClause($clause, __METHOD__);
		$table = DB::getTable($table);
		$query = 'DELETE FROM `'.$table.'` WHERE ';
		$table_fields = array();
		foreach($values as $k => $v) {
			$query .= '`'.$k.'`=:'.$k.' '.$clause.' ';
		}
		$query = rtrim($query, $clause.' ');
		try {
			$db = self::getInstance();
			$db->query($query);
			foreach($values as $k => $v) {
				$db->bind(':'.$k, $v);
			}
			return $db->execute() ? $db->rowCount() : FALSE;
		} catch(Exception $e) {
			throw new DBException($e->getMessage(), 400);
		}
	}
	/**
	 * Validate clause
	 */
	private static function validateClause($clause, $method=NULL) {
		if(!is_null($clause)) {
			$clause = strtoupper($clause);
			if(!in_array($clause, ['AND', 'OR'])) {
				throw new DBException('Expecting clause string \'AND\' or \'OR\' in ' . (!is_null($method) ? $method : __CLASS__), 100);
			}
		}
	}
	
	
}
// DB class own Exception
class DBException extends Exception {}
