 <form  method="post" >
 <?php $data=HMIS\Amenity::get_amenity($_POST["id"])?>
	<fieldset>
			<input type="hidden" class="form-control" name="amenity_id" value="<?=$_POST["id"]?>">
		<div class="form-group col-md-12">
			<label>Icon</label>
              <input data-placement="bottomRight" class="form-control icp icp-auto" name="icon" value="<?=$data['icon']?>" type="text"/>
		</div>
		<div class="form-group col-md-12">
			<label class="control-label">Amenity:</label>
			<input type="text" class="form-control" name="amenity" value="<?=$data['amenity']?>">
		</div>
		<div class="form-group col-md-12">
			<label class="control-label">Description:</label>
			<textarea rows="4" class="form-control" name="description"><?=$data['description']?></textarea>
		</div>                        
	</fieldset>
  					<div class="form-group form-actions">
                        <div class="col-xs-12 text-right">
                           <button type="submit" name="btn_amenity" class="btn btn-sm btn-primary">Submit</button>
                            <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </form>
             
<script>
    $(function () {
            $('.icp-auto').iconpicker();
   
    });
</script>                    