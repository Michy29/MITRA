
<!-- Parallax Effect -->
<script type="text/javascript">$(document).ready(function(){$('#parallax-pagetitle').parallax("50%", -0.55);});</script>

<section class="parallax-effect">
  <div id="parallax-pagetitle" style="background-image: url(./images/parallax/1900x911.gif);">
    <div class="color-overlay"> 
      <!-- Page title -->
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <h1>Search <span  data-toggle="modal" data-target="#myModal">
<div class="popover-icon" data-container="body" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Advanced Search"> <i class="fa fa-binoculars fa-sm"> </i> </div> </span></h1>
            <form method="post">
            	<div class="form-group">
					<input name="search" type="text" class="form-control" placeholder="Search for accommodation"/>
				 </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- Rooms -->
<section class="rooms mt100">
  <div class="container">
    <div class="row room-list fadeIn appear"> 
      <!-- Room -->
      <?php foreach(HMIS\Web::search() as $row){?>
      <div class="col-sm-4 ">
        <div class="room-thumb"> <img width="356" height="228" src="content/rooms/<?=$row['room_pic_1']?>"  class="img-responsive" />
         <div class="top-left"><button class="btn btn-xs btn-info"><?=$row['property_name'].' <i class="fa fa-minus"></i> '.$row['city']?></button></div>
          <div class="mask">
            <div class="main">
              <h5><?=$row['room_name']?></h5>
              <div class="price">KSH. <?=$row['price_per_night']?><span>a night</span></div>
            </div>
            <div class="content">
              <p><?=substr($row['description'],0,200)?></p>
              <?=HMIS\Web::facilities($row['room_id'],'sub')?>
              <a href="<?=ROOT_URL?>?route=roomview&id=<?=$row['room_id']?>" class="btn btn-primary btn-block">Book Now</a> </div>
          </div>
        </div>
      </div>
      <?php }?>
    </div>
  </div>
</section>
<style>
.modal {
  text-align: center;
  padding: 0!important;
}

.modal:before {
  content: '';
  display: inline-block;
  height: 100%;
  vertical-align: middle;
  margin-right: -4px;
}

.modal-dialog {
  display: inline-block;
  text-align: left;
  vertical-align: middle;
}
</style>
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-sm">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Advance Search</h4>
      </div>
      <div class="modal-body">
        <div class="row">
        	<form method="post">
        		<div class="form-group">
					<select class="form-control" name="country">
						<option value="Kenya">What is your destination country?</option> 
						<?=HMIS\countries()?>
					</select>
				 </div>
        		<div class="form-group">
					<input name="City" type="text" class="form-control" placeholder="Which city do you want to travel to?"/>
				 </div>
				 <div class="form-group">
					<input name="property_name" type="text" class="form-control" placeholder="Which hotel are you looking for?"/>
				 </div>
       			 <div class="form-group">
					<input name="budget" type="text" class="form-control" placeholder="What's your budget per night?"/>
				 </div>
       			 <div class="form-group">
					<select class="form-control" name="room_type">
						<option >What type of room do you prefer?</option> 
						<option>Single Room</option>
						<option>Double Room</option>
						<option>Twin </option>
						<option>Triple </option>
						<option>Quadruple </option>
						<option>Family </option>
						<option>Suite </option>
						<option>Studio </option>
						<option>Apartment </option>
						<option>Dormitory </option>
					</select>
				 </div>
        	
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" name="advance_search" class="btn btn-primary" >Submit request</button>
      </div>
    </div>
</form>
  </div>
</div>