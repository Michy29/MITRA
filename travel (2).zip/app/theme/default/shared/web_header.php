<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title><?=G\get_app_setting('company_name')?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<!-- Stylesheets -->


<link rel="stylesheet" href="frontend/css/animate.css">
<link rel="stylesheet" href="frontend/css/bootstrap.css">
<link rel="stylesheet" href="frontend/css/font-awesome.min.css">
<link rel="stylesheet" href="frontend/css/owl.carousel.css">
<link rel="stylesheet" href="frontend/css/owl.theme.css">
<link rel="stylesheet" href="frontend/css/prettyPhoto.css">
<link rel="stylesheet" href="frontend/css/smoothness/jquery-ui-1.10.4.custom.min.css">
<link rel="stylesheet" href="frontend/rs-plugin/css/settings.css">
<link rel="stylesheet" href="frontend/css/theme.css">
<link rel="stylesheet" href="frontend/css/colors/turquoise.css">
<link rel="stylesheet" href="frontend/css/responsive.css">
<link rel="stylesheet" href="<?=ROOT_URL?>app/theme/default/assets/css/plugins.css">
<style>
.top-left {
    position: absolute;
    top: 8px;
    left: 16px;
}

.top-right {
    position: absolute;
    top: 8px;
    right: 16px;
}
</style>
</head>
<body>
<!-- Top header -->
<div id="top-header">
  <div class="container">
    <div class="row">
      <div class="col-xs-6">
        <div class="th-text pull-left">
          <div class="th-item"> <a href="#"><i class="fa fa-phone"></i> <?=G\get_app_setting('company_telno')?></a> </div>
          <div class="th-item"> <a href="#"><i class="fa fa-envelope"></i> <?=G\get_app_setting('company_email')?> </a></div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Header -->
<header>
  <!-- Navigation -->
  <div class="navbar yamm navbar-default" id="sticky">
    <div class="container">
      <div class="navbar-header">
        <button type="button" data-toggle="collapse" data-target="#navbar-collapse-grid" class="navbar-toggle"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        <a href="index.html" class="navbar-brand">         
        <!-- Logo -->
        <div id="logo"> <h3 style="color: aqua; font-size:30px; margin-top: 5px"><?=G\get_app_setting('company_abbr')?></h3> </div>
        </a> </div>
      <div id="navbar-collapse-grid" class="navbar-collapse collapse">
        <ul class="nav navbar-nav">
          <li class="dropdown active"> <a href="<?=ROOT_URL?>">Home</a></li>
          <li class="dropdown active"> <a href="<?=ROOT_URL?>?route=rooms">Rooms</a></li>
          <li class="dropdown active"> <a href="<?=ROOT_URL?>?route=search">Search</a></li>
		  <?php if(isset($_SESSION['UID'])){?>
			<li class="dropdown active"> <a href="<?=ROOT_URL?>dashboard">My Account</a></li>
			<?php }else{ ?>
			<li class="dropdown active"> <a href="<?=ROOT_URL?>login">Login</a></li>
			<?php }?>
        </ul>
      </div>
    </div>
  </div>
</header>