<?=HMIS\Profiles::profile_c_u()?>
      <div class="main-bothside">
         <form  method="post">
            <div class="form-group">
               <div class="form-mid-w3ls">
                  <p>First Name</p>
                  <input type="hidden" name="uid" value="P<?=G\DB::Encoder('profiles')?>">
                  <input type="hidden" name="regdate" value="<?=date('Y-m-d')?>">
                  <input type="text" name="first_name"  required>
               </div>
               <div class="form-mid-w3ls">
                  <p>Last Name</p>
                  <input type="text" name="last_name"  required>
               </div>
            </div>
            <div class="form-group">
               <div class="form-mid-w3ls">
                  <p>Email</p>
                  <input type="email" name="email"   required>
               </div>
               <div class="form-mid-w3ls">
                  <p>Mobile Number</p>
                  <input type="text" name="mobileno"  required>
               </div>
            </div>
            <div class="form-group">
               <div class="form-mid-w3ls">
                  <p>Street Address</p>
                  <input type="text" name="street_address"   required>
               </div>
               <div class="form-mid-w3ls">
                  <p>Address Line 2</p>
                  <input type="text" name="address_line2" >
               </div>
            </div>
            <div class="form-group">
               <div class="form-mid-w3ls">
                  <p>Country</p>
                  <select name="country" class="form-control">
						<option value="" disabled selected>Select Country...</option>
						<?=HMIS\countries()?>
				   </select>
               </div>
               <div class="form-mid-w3ls">
                  <p>City Address</p>
                  <input id="datepicker1" name="city" type="text" placeholder="City"  required>
                  <input type="text" id="timepicker1" name="zipcode"  placeholder="Zip Code"  required>
                  <div class="clear"></div>
               </div>
            </div>
            <div class="form-group">
               <div class="form-mid-w3ls">
                  <p>Password</p>
                  <input type="password" name="password"   required>
               </div>
               <div class="form-mid-w3ls">
                  <p>Confirm Password</p>
                  <input type="password" name="cpassword" required >
               </div>
            </div>
            
            <div class="btnn">
               <input type="submit" name="btn_prof" value="Submit">
            </div>
			 <hr>
            <span ><strong style="color:aliceblue">Already have an account?</strong> <a style="color:yellow" href="<?=ROOT_URL?>login">Login Here</a></span>
            
         </form>
      </div>
      