            <footer class="clearfix">
                <div class="pull-right">
                    Developed By <a href="<?=G\get_app_setting('developer_site')?>" target="_blank"><?=G\get_app_setting('developer')?></a>
                </div>
                <div class="pull-left">
                    &copy; <span><?=date('Y')?></span> <a href="<?=G\absolute_to_url(null)?>" target="_blank"><?php echo G\get_app_setting('appshortname')?></a>
                </div>
            </footer>
        </div>
    </div>
</div>
<a href="#" id="to-top"><i class="fa fa-angle-double-up"></i></a>
<?=include_once('change_password.php')?>
<!-- END User Settings -->
<script src="<?=G\Render\get_theme_file_url('assets/js/vendor/jquery.min.js')?>"></script>
<script src="<?=G\Render\get_theme_file_url('assets/js/vendor/bootstrap.min.js')?>"></script>
<script src="<?=G\Render\get_theme_file_url('assets/js/plugins.js')?>"></script>
<script src="<?=G\Render\get_theme_file_url('assets/js/helpers/sweetalert/sweetalert2.js')?>"></script>
<script src="<?=G\Render\get_theme_file_url('assets/js/app.js')?>"></script>
<!-- Load and execute javascript code used only in this page -->
<?php if(G\path()['call_parts'][1]=='about'){ ?>
<script src="<?=G\Render\get_theme_file_url('assets/js/helpers/ckeditor/ckeditor.js')?>"></script>
<?php }
if(G\path()['call_parts'][1]=='amenities'){ ?>
<script src="<?=G\Render\get_theme_file_url('assets/js/fontawesome-iconpicker.min.js')?>"></script>

<?php }?>
<script>
	var EMISDatatables = function() {
            App.datatables();
            $('#hmis_table').dataTable({
                columnDefs: [ { orderable: false, targets: [ 1, 2 ] } ],
                pageLength: 25,
                lengthMenu: [[25, 50, 100, -1], [25, 50, 100, 'All']],
            });
            $('.dataTables_filter input').attr('placeholder', 'Search');
}();
	function page_loader(view,vtype,id){
		$.ajax({type: "POST",
				url: "<?=ROOT_URL?>pager.php",
				data: { 
					view : view,
					vtype : vtype,
					id : id }
			   }).done(function(data){
			$("#response").html(rtrim(data, '1'));
		});
	}
	function rtrim(str, chr) {
	  var rgxtrim = (!chr) ? new RegExp('\\s+$') : new RegExp(chr+'+$');
	  return str.replace(rgxtrim, '');
	}

<?php if(isset($GLOBALS['success'])){ ?>	
$.bootstrapGrowl("<?=$GLOBALS['success']?>", {
    ele: 'body', type: 'success', offset: {from: 'top', amount: 50}, align: 'right', width: 350, delay: 9000, allow_dismiss: true,stackup_spacing: 10 
});
	<?php }elseif(isset($GLOBALS['error'])){?>
$.bootstrapGrowl("<?=$GLOBALS['error']?>", {
    ele: 'body', type: 'danger', offset: {from: 'top', amount: 50}, align: 'right', width: 350,delay: 9000, allow_dismiss: true, stackup_spacing: 10 
});
	<?php }?>
// verify this code before production
function SwalDelete(tbl,recid){
		var coreSTR = recid+'.'+tbl;
		if(tbl=='reservations'){
			var msg = "This reservation shall be cancelled!";
			var btntxt = "Yes, Cancel";
		}else{
			var msg = "Information related to this record shall be lost permanently!";
			var btntxt = "Yes, Delete!";
		}
		swal({
			title: 'Are you sure?',text: msg,type: 'warning',showCancelButton: true,confirmButtonColor: '#3085d6',cancelButtonColor: '#d33',confirmButtonText: btntxt,showLoaderOnConfirm: true,
			preConfirm: function() {
			  return new Promise(function(resolve) {
			     $.ajax({ url: '<?=ROOT_URL?>trash.php',type: 'POST',data: 'coreSTR='+coreSTR,dataType: 'json'})
			     .done(function(response){
					swal.close();
					$.bootstrapGrowl(response.message, {
						ele: 'body', type: response.status, offset: {from: 'top', amount: 50}, align: 'right', width: 350, delay: 9000, allow_dismiss: true,stackup_spacing: 10 
					}); 
					 reloadtbl();

				 })
			     .fail(function(){
					 swal.close();
					$.bootstrapGrowl("An internal server error occured.", {
						ele: 'body', type: 'danger', offset: {from: 'top', amount: 50}, align: 'right', width: 350,delay: 9000, allow_dismiss: true, stackup_spacing: 10 
					});
			     });
			  });
		    },
						  
		});	
	}
	function reloadtbl(){
		$('#hmis_table').load(document.URL +  ' #hmis_table');
		var EMISDatatables = function() {
            App.datatables();
            $('#hmis_table').dataTable({destroy: true,columnDefs: [ { orderable: false, targets: [ 1, 2 ] } ],pageLength: 25,lengthMenu: [[25, 50, 100, -1], [25, 50, 100, 'All']], });
            $('.dataTables_filter input').attr('placeholder', 'Search');
			}();
			$('#hmis_table').load(document.URL +  ' #hmis_table');
	}	
</script>

 </body>
</html>
