 <section style="margin-top: 30px" class="room-tabs" id="sc-rooms">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <!--Room Tabs Nav start -->
                    
                    <ul class="nav nav-tabs" role="tablist">
                       <?php $i=null; foreach(HMIS\DB::ReadMulti('room_types') as $row){ $i++;?>
                        <li role="presentation" class="<?php if($i==1){echo 'active';}else{echo null;}?>">
                        	<a href="#<?=$row['type_id']?>" aria-controls="<?=$row['type_id']?>" role="tab" data-toggle="tab"><?=ucwords($row['type_name'])?></a>
                        </li>
                        <?php }?>
                    </ul>
                    <!--Room Tabs Nav end -->

                    <!-- Tabs start -->
                    <div class="tab-content">
                        <!--Room Tab 1 start-->
                        <?php $i=null; foreach(HMIS\DB::ReadMulti('room_types') as $row){ $i++;?>
                        <div role="tabpanel" class="tab-pane fade in <?php if($i==1){echo 'active';}else{echo null;}?>" id="<?=$row['type_id']?>">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="room-tabs-gallery">
                                        <div class="room-tabs-gallery-thumbnails">
                                            <a class="room-tabs-gallery-thumb" href="#<?=$row['type_id']?>">
                                                <img class="img-responsive" src="<?=ROOT_URL.'content/rooms/'.$row['room_pic_1']?>"  title="<?=ucwords($row['type_name'])?>"/>
                                            </a>
                                            <a class="room-tabs-gallery-thumb" href="#<?=$row['type_id']?>">
                                                <img class="img-responsive" src="<?=ROOT_URL.'content/rooms/'.$row['room_pic_2']?>"  title="<?=ucwords($row['type_name'])?>"/>
                                            </a>
                                            <a class="room-tabs-gallery-thumb" href="#<?=$row['type_id']?>">
                                                <img class="img-responsive" src="<?=ROOT_URL.'content/rooms/'.$row['room_pic_3']?>"  title="<?=ucwords($row['type_name'])?>"/>
                                            </a>
                                            <a class="room-tabs-gallery-thumb" href="#<?=$row['type_id']?>">
                                                <img class="img-responsive" src="<?=ROOT_URL.'content/rooms/'.$row['room_pic_4']?>"  title="<?=ucwords($row['type_name'])?>"/>
                                            </a>
                                            <a class="room-tabs-gallery-thumb" href="#<?=$row['type_id']?>">
                                                <img class="img-responsive" src="<?=ROOT_URL.'content/rooms/'.$row['room_pic_5']?>"  title="<?=ucwords($row['type_name'])?>"/>
                                            </a>
                                            <a class="room-tabs-gallery-thumb" href="#<?=$row['type_id']?>">
                                                <img class="img-responsive" src="<?=ROOT_URL.'content/rooms/'.$row['room_pic_6']?>"  title="<?=ucwords($row['type_name'])?>"/>
                                            </a>
                                        </div>
                                        <div class="room-tabs-gallery-image">
                                            <a class="room-tabs-gallery-preview-container" href="#">
                                                <img class="img-responsive room-tabs-gallery-preview" src="<?=ROOT_URL.'content/rooms/'.$row['room_pic_1']?>"/>
                                            </a>

                                            <div class="room-tabs-gallery-caption">
                                                Starts from: <strong>KSH. <?=number_format($row['price_per_night'],2)?> / Night</strong>
                                                <button class="btn btn-room-check show-inquiry-modal" data-object="<?=ucwords($row['type_name'])?>">
                                                    <i class="icon-calendar icons"></i> Check Availability
                                                </button>
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                                <div class="col-md-6 room-tabs-description">
                                    <h3>About this room</h3>

                                    <p><?=$row['description']?></p>

                                    <div class="row">
                                        <?php 
												$facilities=explode(', ',$row['room_facilities']); 
											 ?>
                                        <div class="col-md-6 col-sm-6">
                                            <ul class="list-group room-tabs-checklist left">
                                               <?php for($i=0;$i<5;$i++){ if(count($facilities)>$i){ ?>
                                                <li class="list-group-item"><i class="fa fa-check-square-o"></i> <?=ucwords($facilities[$i])?></li>
                                               <?php }}?>
                                            </ul>
                                        </div>
                                        <div class="col-md-6 col-sm-6">
                                            <ul class="list-group room-tabs-checklist right">
                                               <?php for($i=5;$i<10;$i++){ if(count($facilities)>$i){ ?>
                                                <li class="list-group-item"><i class="fa fa-check-square-o"></i> <?=ucwords($facilities[$i])?></li>
                                               <?php }}?>
                                            </ul>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--Room Tab 1 end-->
                        <?php }?>
                    </div>
                    <!-- Tabs end -->
                    <?php ?>
                </div>
            </div>
        </div>
    </section>