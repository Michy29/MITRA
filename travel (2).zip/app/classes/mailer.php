<?php
namespace HMIS;
use G, Exception;
class Mailer {
	public static function sendActivation($formData,$extraData){
    $validated = \GUMP::is_valid($formData,array());
    if ($validated === true) {
        $transport = self::getMailType();
		$formData['mail_logo'] = ROOT_URL.'content/other/mail_logo.png';
		$formData['url'] = ROOT_URL.'activate/'.$formData['token'];
		$formData['title'] = 'Activate Account';
		$formData['physical'] = G\get_app_setting('company_physical_address');
		$formData['company'] = G\get_app_setting('company_name');
		$formData['address'] = G\get_app_setting('company_address');
        $body = self::createMailBody(APP_PATH_THEME.'views/mail_temp/activation.html', $formData);
        $mailer = \Swift_Mailer::newInstance($transport);
        // Create a message
        $message = \Swift_Message::newInstance(G\get_app_setting('activation'))
            ->setFrom(array($formData['email'] => $extraData['name']))
            ->setTo(array(G\get_app_setting('company_email') => G\get_app_setting('company_name')))
            ->setBody($body, 'text/html');
       // Send the message
        if ($mailer->send($message)) {
            //$result = array('result' => 'success', 'msg' => array('Thank you for contacting us we shall contact you soon.'));
            //return json_encode($result);
			
        } else {
            ///$result = array('result' => 'error', 'msg' => 'Mail can not send! Check mail configs.');
           // return json_encode($result);
        }
    } else {
        //$result = array('result' => 'error', 'msg' => $validated);
       // return json_encode($result);
    }
}
	public static function ResetPassword($formData,$extraData){
    $validated = \GUMP::is_valid($formData,array());
    if ($validated === true) {
        $transport = self::getMailType();
		$formData['mail_logo'] = ROOT_URL.'content/other/mail_logo.png';
		$formData['title'] = 'Reset Password';
		$formData['physical'] = G\get_app_setting('company_physical_address');
		$formData['company'] = G\get_app_setting('company_name');
		$formData['address'] = G\get_app_setting('company_address');
        $body = self::createMailBody(APP_PATH_THEME.'views/mail_temp/reset.html', $formData);
        $mailer = \Swift_Mailer::newInstance($transport);
        // Create a message
        $message = \Swift_Message::newInstance(G\get_app_setting('reset'))
            ->setFrom(array($formData['email'] => $extraData['name']))
            ->setTo(array(G\get_app_setting('company_email') => G\get_app_setting('company_name')))
            ->setBody($body, 'text/html');
       // Send the message
        if ($mailer->send($message)) {
            //$result = array('result' => 'success', 'msg' => array('Thank you for contacting us we shall contact you soon.'));
            //return json_encode($result);
			
        } else {
            ///$result = array('result' => 'error', 'msg' => 'Mail can not send! Check mail configs.');
           // return json_encode($result);
        }
    } else {
        //$result = array('result' => 'error', 'msg' => $validated);
       // return json_encode($result);
    }
}
	
	
	public static function getMailType(){
    switch (G\get_app_setting('mail_type')) {
        case 'smtp' :
            $transport = \Swift_SmtpTransport::newInstance(G\get_app_setting('smtp_server'),G\get_app_setting('smtp_port'))
                ->setUsername(G\get_app_setting('smtp_user'))
                ->setPassword(G\get_app_setting('smtp_password'));
            break;
        case 'mail' :
            $transport = \Swift_MailTransport::newInstance();
            break;
        default:
            $transport = \Swift_MailTransport::newInstance();
    }
    return $transport;
}
	public static function createMailBody($file, $data) {
    if (!file_exists($file)) {
        $GLOBALS['error']="Error loading template file ($file).";
    }
    $output = file_get_contents($file);

    foreach ($data as $key => $value) {
        $tagToReplace = "[@$key]";
        $output = str_replace($tagToReplace, $value, $output);
    }

    // Clean empty placeholder
    $pattern = "/\[+@+[a-zA-Z0-9_-]+\]/";
    $output = preg_replace($pattern, '', $output);

    return $output;
}
	
}