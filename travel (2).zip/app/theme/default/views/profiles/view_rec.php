 <form  method="post" >
 <?php $data=EMIS\Staff::get_staff($_POST["id"])?>
	<fieldset>
		<input type="hidden" class="form-control" name="uid" value="<?=$_POST["id"]?>">
	<div class="form-group col-md-12">
		<label class="control-label">First Name:</label>
		<input type="text" class="form-control" value="<?=$data['first_name']?>"  name="first_name">
	</div>
	<div class="form-group col-md-12">
		<label class="control-label">Middle Name:</label>
		<input type="text" class="form-control" value="<?=$data['middle_name']?>"  name="middle_name">
	</div>
	<div class="form-group col-md-12">
		<label class="control-label">Last Name:</label>
		<input type="text" class="form-control" value="<?=$data['last_name']?>"  name="last_name">
	</div>
	<div class="form-group col-md-6">
		<label class="control-label">Email:</label>
		<input type="text" class="form-control" value="<?=$data['email']?>"  name="email">
	</div>
	<div class="form-group col-md-6">
		<label class="control-label">Mobile No:</label>
		<input type="text" class="form-control" value="<?=$data['mobile_no']?>"  name="mobile_no">
	</div>
	
	<div class="form-group col-md-12">
		<label class="control-label">Notes:</label>
		<textarea rows="4" class="form-control" name="user_notes"><?=$data['user_notes']?></textarea>
	</div> 
		<input type="hidden" class="form-control" name="reg_date" value="<?=date('Y-m-d')?>">

</fieldset>
                   
 <div class="form-group form-actions">
                        <div class="col-xs-12 text-right">
                            <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </form>
                    