<?php
namespace G;
// Ensure we have session
session_start();
// Error reporting setup
@ini_set('loerrors', TRUE);
error_reporting(E_ALL ^ E_NOTICE);

// Set the encoding to UTF-8
@ini_set('default_charset', 'utf-8');

// Can work with sessions?
if(!@session_start()) die("This server can't work with sessions.");

// Are sessions working properly?
$_SESSION['G'] = TRUE;
if(!$_SESSION['G']) die("Sessions are not working properly. Check for any conflicting server setting.");

// Include G\ core functions
(file_exists(__DIR__ . '/functions.php')) ? require_once(__DIR__ . '/functions.php') : die("Can't find <strong>" . __DIR__ . '/functions.php' . '</strong>. Make sure that this file exists.');
if(file_exists(__DIR__ . '/render.php')) {
	require_once(__DIR__ . '/render.php');
}

// Set G\ paths and files
define('ROOT_PATH', rtrim(forward_slash(dirname(__DIR__)), '/') . '/'); 
define('ROOT_PATH_RELATIVE', rtrim(dirname($_SERVER['SCRIPT_NAME']), '\/') . '/');
define('ROOT_LIB_PATH', ROOT_PATH . 'system/');
define('PATH_CLASSES', ROOT_LIB_PATH . 'core_classes/');
define('ROOT_ASS_PATH', ROOT_PATH . 'assets/');
define('ROOT_CON_PATH', ROOT_PATH . 'content/');
define('FILE_FUNCTIONS', ROOT_LIB_PATH . 'functions.php');
//define('FILE_FUNCTIONS_RENDER', PATH . 'functions.render.php');
// Set app paths
define('APP_PATH', rtrim(forward_slash(dirname(__DIR__)), '/') . '/app/');
define('APP_PATH_CONFIG', APP_PATH . 'config/');
define('APP_PATH_LANG', APP_PATH . 'lang/');
define('APP_PATH_VIEWS', APP_PATH . 'view/');
define('APP_PATH_CLASSES', APP_PATH . 'classes/');
define('APP_FUNCTIONS', APP_PATH . 'functions.php');
define('APP_SETTINGS_FILE_ERROR', '<br />There are errors in the <strong>%%FILE%%</strong> file. Change the encodig to "UTF-8 without BOM" using Notepad++ or any similar code editor and remove any character before <span style="color: red;">&lt;?php</span>');

// Include the static app config file
(file_exists(APP_PATH_CONFIG . 'main.php')) ? require_once(APP_PATH_CONFIG . 'main.php') : die("Can't find main/settings.php");
if(headers_sent()) die(str_replace('%%FILE%%', 'config/main.php', APP_SETTINGS_FILE_ERROR)); // Stop on premature headers

(file_exists(APP_PATH_CONFIG . 'custom.php')) ? require_once(APP_PATH_CONFIG . 'custom.php') : die();
$settings=array_merge($settings,$custom_settings);

if(isset($settings) and $settings['error_reporting'] === false) {
	error_reporting(0);
}
// Set the default timezone
if(isset($settings['default_timezone']) and is_valid_timezone($settings['default_timezone'])) {
	date_default_timezone_set($settings['default_timezone']);
}
// Set the system environment
if(isset($settings['environment'])) {
	define('APP_ENV', $settings['environment']);
}
// Set the HTTP definitions
define('HTTP_HOST', $_SERVER['HTTP_HOST']);
define('HTTP_PROTOCOL', ((!empty($_SERVER['HTTPS']) and strtolower($_SERVER['HTTPS']) == 'on' ) or $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') ? 'https' : 'http');

// Fix some $_SERVER vars
$_SERVER['SCRIPT_FILENAME'] = forward_slash($_SERVER['SCRIPT_FILENAME']);
$_SERVER['SCRIPT_NAME'] = forward_slash($_SERVER['SCRIPT_NAME']); 
// Fix CloudFlare REMOTE_ADDR
if(isset($_SERVER['HTTP_CF_CONNECTINIP'])) {
	$_SERVER['REMOTE_ADDR'] = $_SERVER['HTTP_CF_CONNECTINIP'];
}
// Inherit application definitions
if(file_exists(ROOT_LIB_PATH . 'system.php')) {
	require_once(ROOT_LIB_PATH . 'system.php');
}
// Inherit external code
if(file_exists(ROOT_LIB_PATH . 'externals/autoload.php')) {
	require_once(ROOT_LIB_PATH . 'externals/autoload.php');
}
// Set the DB constants
foreach(['host', 'port', 'name', 'user', 'pass', 'driver', 'pdo_attrs'] as $k) {
	define('APP_DB_' . strtoupper($k), isset($settings['db_' . $k]) ? (is_array($settings['db_' . $k]) ? serialize($settings['db_' . $k]) : $settings['db_' . $k]) : NULL);
}
// Include app functions
(file_exists(APP_FUNCTIONS)) ? require_once(APP_FUNCTIONS) : die("Can't find <strong>" . APP_FUNCTIONS . '</strong>. Make sure that this file exists.');


// Set the URLs
define("ROOT_URL", HTTP_PROTOCOL . "://".HTTP_HOST . ROOT_PATH_RELATIVE); // http(s)://www.mysite.com/chevereto/
define("ROOT_LIB_URL", absolute_to_url(ROOT_LIB_PATH));
// Define the app theme
define('APP_PATH_THEMES', APP_PATH . 'theme/');
if(!file_exists(APP_PATH_THEMES)) {
	die("Theme path doesn't exists!");
}
if(isset($settings['theme']) and file_exists(APP_PATH_THEMES . $settings['theme'])) {
	define('APP_PATH_THEME', APP_PATH_THEMES . $settings['theme'].'/');
	define('BASE_URL_THEME', absolute_to_url(APP_PATH_THEME));
}