<?php
namespace HMIS;
use G, Exception;
class Reservation {
	private static $string = 'uid, book_id, room_id, reserve_date, checkin, checkout, adults, children, no_of_guests, no_of_rooms, total_amount, number_of_days, special_arrangements';
	private static $table = 'reservations';
	public static function reserve_c_u() {
		if(isset($_POST['btn_book'])){
		$request=array('book_id'=>$_POST['book_id']);
		if(DB::ReadSingle(self::$table,$request,1)==null){
			self::reserve();
		}else{
			self::update_booking();
		}
		}
	}
	public static function reserve() {
		$booked=Properties::get_room($_POST['room_id'])['booked'];
		$newboked = $booked + $_POST['no_of_rooms'];
		$inserts = self::$string;
		try{
		$fields=explode(', ', $inserts);
		foreach($fields as $data){
			$values[$data]  = $_POST[$data];
		}
		DB::Create(self::$table, $values);
		$value_['booked']=$newboked;
		DB::Update('rooms', $value_,array('room_id'=>$_POST['room_id']));
		$GLOBALS['success']='Reservation submitted successfully';
			
		} catch(Exception $e) {
			$GLOBALS['error']='Database error occured'.$e->getMessage();
			
		}
	}
	public static function get_reservations($uid=null,$owner=null) {
		$DB=DB::vanillaDB();
		$DB->query('
		SELECT * FROM '.G\get_app_setting('db_table_prefix').self::$table.' 
		INNER JOIN '.G\get_app_setting('db_table_prefix').'rooms 
		ON '.G\get_app_setting('db_table_prefix').self::$table.'.room_id='.G\get_app_setting('db_table_prefix').'rooms.room_id 
		INNER JOIN '.G\get_app_setting('db_table_prefix').'properties 
		ON '.G\get_app_setting('db_table_prefix').'rooms.pid='.G\get_app_setting('db_table_prefix').'properties.pid 
		WHERE '.G\get_app_setting('db_table_prefix').self::$table.'.uid LIKE :uid AND '.G\get_app_setting('db_table_prefix').'properties.owner LIKE :owner');
		$DB->bind(':uid', "%".$uid."%");
		$DB->bind(':owner', "%".$owner."%");
		return $DB->resultset();
	}
	public static function get_reservation($request) {
		$data0  = DB::ReadSingle(self::$table,array('book_id'=>$request),1);
		$data1 = Profiles::get_profile($data0['uid']);
		$data2 = Properties::get_room($data0['room_id']);
		return(array_merge($data0,$data1,$data2));
	}
	public static function update_booking() {
		$updates =self::$string;
		try{
		$fields=explode(', ', $updates);
		foreach($fields as $data){
				$values[$data]  = $_POST[$data];
		}
		$checks=array('book_id'=>$_POST['book_id']);
		DB::Update(self::$table, $values,$checks);
		$GLOBALS['success']='Record updated successfully';
			
		} catch(Exception $e) {
			$GLOBALS['error']='An error occured while updating';
		}
	}
	public static function CinCo($id,$status) {
		$values['r_status']  = $status;
		DB::Update(self::$table, $values,array('book_id'=>$id));
	}
	public static function cancel($request) {
			$values['r_status']  = 'CANCELED';
			DB::Update(self::$table, $values,array('book_id'=>$request));
			$GLOBALS['success']='Reservation canceled successfully';
	}
	public static function delete_reservation($request){
		G\DB::Delete(self::$table, array('book_id'=>$request));
	}
}
