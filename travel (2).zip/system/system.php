<?php
# Do NOT Change any information associated to this file

define('APP_NAME', 'S.M.I.S');
define('APP_VERSION', '1.0.0');