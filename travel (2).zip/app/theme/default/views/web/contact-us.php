 <!--Contact start-->
    <section style="margin-top: 30px" class="contact" id="sc-contact">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="contact-header">
                        <div class="row">
                            <div class="col-md-12">
                                <h2>Get in touch with Us</h2>
                                <h3>Have any question? Fill the form below and get instant response!</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <form action="#" id="contact-form">
                <input type="hidden" name="action" value="send_contact_form"/>

                <div class="alert hidden" id="contact-form-msg"></div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-user fa-fw"></i></span>
                            <input type="text" name="name" class="form-control" placeholder="Name">
                        </div>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-envelope fa-fw"></i></span>
                            <input type="text" name="email" class="form-control" placeholder="Email Address">
                        </div>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-phone fa-fw"></i></span>
                            <input type="text" name="phone" class="form-control" placeholder="Phone Number">
                        </div>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-home fa-fw"></i></span>
                            <input type="text" name="address" class="form-control" placeholder="Post Address">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="input-group textbox">
                            <span class="input-group-addon"><i class="fa fa-pencil fa-fw"></i></span>
                            <textarea class="form-control" name="message" cols="30" rows="10" placeholder="Message"></textarea>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-md-offset-6">
                        <button class="btn btn-color1 btn-contact-form">Submit<i class="fa fa-angle-right"></i></button>
                    </div>
                </div>
            </form>
        </div>
    </section>
    <!--Contact end-->

    <!--Address start-->
    <section class="address" id="sc-address">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <p class="address-info">If you have questions or need additional information, please connect with us:</p>
                    <ul class="phones">
                        <li><i class="fa fa-phone"></i> <?=G\get_app_setting('company_telno')?></li>
                        <li><i class="fa fa-envelope"></i> <?=G\get_app_setting('company_email')?></li>
                        <li><i class="fa fa-facebook"></i> <?=G\get_app_setting('facebook_page')?></li>
                        <li><i class="fa fa-twitter"></i> <?=G\get_app_setting('twitter_handle')?></li>
                        <li><i class="fa fa-instagram"></i> <?=G\get_app_setting('instagram_page')?></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!--Address end-->
