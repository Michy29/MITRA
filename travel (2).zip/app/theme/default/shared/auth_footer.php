<div class="copy">
         <p>&copy; <?=date('Y')?> <?=G\get_app_setting('company_name')?>. All rights reserved | Design by
			<a href="<?=G\get_app_setting('developer_site')?>"><?=G\get_app_setting('developer')?></a>
		</p
      </div>
      <script src="<?=ROOT_URL?>frontend/js/jquery-2.2.3.min.js"></script>
      <script src="<?=G\Render\get_theme_file_url('assets/js/vendor/bootstrap.min.js')?>"></script>
<script src="<?=G\Render\get_theme_file_url('assets/js/plugins.js')?>"></script>
      <script>
			 <?php if(isset($GLOBALS['success'])){ ?>	
				$.bootstrapGrowl("<?=$GLOBALS['success']?>", {
					ele: 'body', type: 'success', offset: {from: 'top', amount: 10}, align: 'right', width: 350, delay: 9000, allow_dismiss: true,stackup_spacing: 10 
				});
					<?php }elseif(isset($GLOBALS['error'])){?>
				$.bootstrapGrowl("<?=$GLOBALS['error']?>", {
					ele: 'body', type: 'danger', offset: {from: 'top', amount: 10}, align: 'right', width: 350,delay: 9000, allow_dismiss: true, stackup_spacing: 10 
				});
					<?php }?>
	  </script>
   </body>
</html>