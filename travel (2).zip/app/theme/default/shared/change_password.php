<div id="modal-user-settings" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title"> Change Password</h4>
            </div>
            <!-- END Modal Header -->

            <!-- Modal Body -->
            <div class="modal-body">
                <form  method="post"  class="form-horizontal form-bordered">
                    <fieldset>
                       <div class="form-group">
                            <label class="col-md-4 control-label">Current Password</label>
                            <div class="col-md-8">
                                <input type="password"  name="cpass" class="form-control">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-4 control-label">New Password</label>
                            <div class="col-md-8">
                                <input type="password"  name="npass" class="form-control">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-4 control-label" >Confirm  Password</label>
                            <div class="col-md-8">
                                <input type="password"  name="rpass" class="form-control">
                            </div>
                        </div>
                    </fieldset>
                    <div class="form-group form-actions">
                        <div class="col-xs-12 text-right">
                            <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">Close</button>
                            <button type="submit" name="btn_password" class="btn btn-sm btn-primary">Save Changes</button>
                        </div>
                    </div>
                </form>
                <?php if(isset($_POST['btn_password'])){HMIS\Auth::change_pass();}?>
            </div>
            <!-- END Modal Body -->
        </div>
    </div>
</div>