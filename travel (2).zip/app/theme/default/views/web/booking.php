<?php 
$data=HMIS\Web::room($_POST['room_id']);
$date1=date_create($_POST['checkin']);
$date2=date_create($_POST['checkout']);
$diff=date_diff($date1,$date2);
$days = $diff->format("%R%a");
HMIS\Reservation::reserve_c_u();				
?>
<div class="container">
  <div class="row"> 
    <!-- Contact form -->
    <section id="contact-form" class="mt50">
      <div class="col-md-8">
        <h2 class="lined-heading"><span>Room Reservation</span></h2>
        <div id="message"></div>
        <!-- Error message display -->
        <form class="clearfix mt50" role="form" method="post" >
          <div class="row">
           <?php if(isset($GLOBALS['success'])){?>
           <div class="alert alert-success alert-dismissable">
          	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          	<?=$GLOBALS['success']?>
          </div>
          <script>
			window.setTimeout(function(){
				// Move to a new location or you can do something else
					window.location.href = "<?=ROOT_URL?>bookings/reservations";
				}, 3000);
			</script>
           <?php }?>
           <?php if(isset($GLOBALS['error'])){?>
           <div class="alert alert-danger alert-dismissable">
          	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          	<?=$GLOBALS['error']?>
          </div>
           <?php }?>
           
            <div class="col-md-6">
              <div class="form-group">
                <label for="name" accesskey="U"> Your Name</label>
                <input name="name" type="text" readonly class="form-control" value="<?=G\get_app_setting('first_name')?> <?=G\get_app_setting('middle_name')?> <?=G\get_app_setting('last_name')?>"/>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label for="email" accesskey="E"> E-mail</label>
                <input name="email" type="text" readonly  value="<?=G\get_app_setting('email')?>" class="form-control"/>
              </div>
            </div>
          </div>
			<div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label for="name" accesskey="U"> Hotel</label>
                <input type="text" readonly class="form-control" value="<?=$data['property_name']?>"/>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label for="email" accesskey="E"> Room</label>
                <input readonly type="text"  value="<?=$data['room_name']?>" class="form-control"/>
                <input name="room_id" type="hidden"  value="<?=$data['room_id']?>" class="form-control"/>
                <input name="uid" type="hidden"  value="<?=$_SESSION['UID']?>" class="form-control"/>
                <input name="book_id" type="hidden"  value="<?=G\DB::Encoder('reservations')?>" class="form-control"/>
              </div>
            </div>
			<div class="col-md-2">
              <div class="form-group">
                <label > No. of Rooms</label>
                <input name="no_of_rooms" type="text" readonly  value="<?=$_POST['rooms']?>" class="form-control"/>
              </div>
            </div>
          </div>
          
			<div class="row">
            <div class="col-md-3">
              <div class="form-group">
                <label for> Adults</label>
                <input name="adults" type="text" readonly class="form-control" value="<?=$_POST['adults']?>"/>
              </div>
            </div>
            <div class="col-md-3">
              <div class="form-group">
                <label > Children</label>
                <input name="children" type="text" readonly  value="<?=$_POST['children']?>" class="form-control"/>
                <input name="no_of_guests" type="hidden" readonly  value="<?=$_POST['children']+$_POST['adults']?>" class="form-control"/>
              </div>
            </div>
			<div class="col-md-3">
              <div class="form-group">
                <label for="name" accesskey="U"> Checkin Date</label>
                <input name="checkin" type="text" readonly class="form-control" value="<?=$_POST['checkin']?>"/>
                <input name="reserve_date" type="hidden"  class="form-control" value="<?=date('Y-m-d')?>"/>
              </div>
            </div>
            <div class="col-md-3">
              <div class="form-group">
                <label for="email" accesskey="E"> Checkout Date</label>
                <input name="checkout" type="text" readonly  value="<?=$_POST['checkout']?>" class="form-control"/>
              </div>
            </div>
				
          </div>
          <div class="row">
            <div class="col-md-3">
              <div class="form-group">
                <label > Number of Days</label>
                <input name="number_of_days" type="text" readonly class="form-control" value="<?=$days*1?>"/>
              </div>
            </div>
            <div class="col-md-3">
              <div class="form-group">
                <label>Total Amount Payable</label>
                <input name="total_amount" type="text" readonly  value="<?=(($days*$data['price_per_night']))?>" class="form-control"/>
              </div>
            </div>
          </div>
         
           <div class="form-group">
            <label for="comments" accesskey="C">Special Arrangements/Enquiries</label>
            <textarea name="special_arrangements" rows="9"  class="form-control"></textarea>
          </div>
          <button type="submit" name="btn_book" class="btn  btn-lg btn-primary">Submit Reservation</button>
        </form>
      </div>
    </section>
    
    <!-- Contact details -->
    <section class="contact-details mt50">
      <div class="col-md-4">
        <h2 class="lined-heading"><span>Trending Rooms</span></h2>
        <?php  
		foreach(HMIS\Web::favorite(2) as $row){?>
			 <div class="col-sm-12">
				<div class="room-thumb"> <img src="content/rooms/<?=$row['room_pic_1']?>" class="img-responsive" />
			  <div class="top-left"><button class="btn btn-xs btn-info"><?=$row['property_name'].' <i class="fa fa-minus"></i> '.$row['city']?></button></div>
				  <div class="mask">
					<div class="main">
					  <h5><?=$row['room_name']?></h5>
					  <div class="price">KSH. <?=$row['price_per_night']?><span>a night</span></div>
					</div>
					<div class="content">
				  	<p><span><?=$row['room_type']?></span> <?=substr($row['description'],0,200)?></p>
					  <?=HMIS\Web::facilities($row['room_id'],'sub')?>
					  <a href="<?=ROOT_URL?>?route=roomview&id=<?=$row['room_id']?>" class="btn btn-primary btn-block">BOOK NOW</a>
					</div>
				  </div>
				</div>
			  </div>
		<?php }?>
      </div>
    </section>
  </div>
</div>
