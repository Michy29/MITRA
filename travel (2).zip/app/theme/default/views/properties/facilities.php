<?php $data=HMIS\Properties::get_facilities($_POST["id"])?>
 <form  method="post" >
	<fieldset>
			
		<div class="form-group col-md-3">
			<label class="control-label">Room ID:</label>
			<input type="text" class="form-control" readonly name="room_id" value="<?=$_POST["id"]?>">
		</div>
		<div class="form-group col-md-3">
			<label class="control-label">Internet:</label>
			<select class="form-control" name="internet">
				<option><?=$data['internet']?></option>
				<option>YES - Free</option>
				<option>YES - Paid</option>
				<option>NO</option>
			</select>
		</div>
		<div class="form-group col-md-3">
			<label class="control-label">Parking:</label>
			<select class="form-control" name="parking">
				<option><?=$data['parking']?></option>
				<option>YES</option>
				<option>NO</option>
			</select>
		</div>
		<div class="form-group col-md-3">
			<label class="control-label">Restraunt :</label>
			<select class="form-control" name="restraunt">
				<option><?=$data['restraunt']?></option>
				<option>YES</option>
				<option>NO</option>
			</select>
		</div>
		<div class="form-group col-md-3">
			<label class="control-label">Room Service:</label>
			<select class="form-control" name="room_service">
				<option><?=$data['room_service']?></option>
				<option>YES</option>
				<option>NO</option>
			</select>
		</div>
		<div class="form-group col-md-3">
			<label class="control-label">Bar :</label>
			<select class="form-control" name="bar">
				<option><?=$data['bar']?></option>
				<option>YES</option>
				<option>NO</option>
			</select>
		</div>
		<div class="form-group col-md-3">
			<label class="control-label">24-Hour Front Desk:</label>
			<select class="form-control" name="24_hour_front_desk">
				<option><?=$data['24_hour_front_desk']?></option>
				<option>YES</option>
				<option>NO</option>
			</select>
		</div>
		<div class="form-group col-md-3">
			<label class="control-label">Sauna :</label>
			<select class="form-control" name="sauna">
				<option><?=$data['sauna']?></option>
				<option>YES - Free</option>
				<option>YES - Paid</option>
				<option>NO</option>
			</select>
		</div>
		<div class="form-group col-md-3">
			<label class="control-label">Garden :</label>
			<select class="form-control" name="garden">
				<option><?=$data['garden']?></option>
				<option>YES</option>
				<option>NO</option>
			</select>
		</div>
		<div class="form-group col-md-3">
			<label class="control-label">Fitness Center:</label>
			<select class="form-control" name="fitness_center">
				<option><?=$data['fitness_center']?></option>
				<option>YES - Free</option>
				<option>YES - Paid</option>
				<option>NO</option>
			</select>
		</div>
		<div class="form-group col-md-3">
			<label class="control-label">Terrace :</label>
			<select class="form-control" name="terrace">
				<option><?=$data['terrace']?></option>
				<option>YES</option>
				<option>NO</option>
			</select>
		</div>
		<div class="form-group col-md-3">
			<label class="control-label">Non Smoking:</label>
			<select class="form-control" name="non_smoking_rooms">
				<option><?=$data['non_smoking_rooms']?></option>
				<option>YES</option>
				<option>NO</option>
			</select>
		</div>
		<div class="form-group col-md-3">
			<label class="control-label">Airport Shuttle:</label>
			<select class="form-control" name="airport_shuttle">
				<option><?=$data['airport_shuttle']?></option>
				<option>YES</option>
				<option>NO</option>
			</select>
		</div>
		<div class="form-group col-md-3">
			<label class="control-label">Family Rooms:</label>
			<select class="form-control" name="family_rooms">
				<option><?=$data['family_rooms']?></option>
				<option>YES</option>
				<option>NO</option>
			</select>
		</div>
		<div class="form-group col-md-3">
			<label class="control-label">Spa :</label>
			<select class="form-control" name="spa">
				<option><?=$data['spa']?></option>
				<option>YES</option>
				<option>NO</option>
			</select>
		</div>
		<div class="form-group col-md-3">
			<label class="control-label">Beach :</label>
			<select class="form-control" name="beach">
				<option><?=$data['beach']?></option>
				<option>YES</option>
				<option>NO</option>
			</select>
		</div>
		<div class="form-group col-md-3">
			<label class="control-label">Swimming Pool:</label>
			<select class="form-control" name="swimming_pool">
				<option><?=$data['swimming_pool']?></option>
				<option>YES</option>
				<option>NO</option>
			</select>
		</div>
		<div class="form-group col-md-3">
			<label class="control-label">Hot Tub:</label>
			<select class="form-control" name="hot_tub_jacuzzi">
				<option><?=$data['hot_tub_jacuzzi']?></option>
				<option>YES</option>
				<option>NO</option>
			</select>
		</div>
		<div class="form-group col-md-3">
			<label class="control-label">Water Park:</label>
			<select class="form-control" name="water_park">
				<option><?=$data['water_park']?></option>
				<option>YES</option>
				<option>NO</option>
			</select>
		</div>
		<div class="form-group col-md-3">
			<label class="control-label">Air Conditioning:</label>
			<select class="form-control" name="air_conditioning">
				<option><?=$data['air_conditioning']?></option>
				<option>YES</option>
				<option>NO</option>
			</select>
		</div>


		                   

		
	</fieldset>
  <div class="form-group form-actions">
                        <div class="col-xs-12 text-right">
                           <button type="submit" name="btn_facilities" class="btn btn-sm btn-primary">Submit</button>
                            <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </form>
                   
                    