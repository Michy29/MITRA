 <div id="page-content">
    <div class="content-header">
        <div class="header-section">
            <h1>
                <i class="gi gi-parents"></i>Bookings<br>
            </h1>
        </div>
    </div>
    <div class="block">
        <div class="row">
        
        <div class="col-sm-12">
            <div class="block">
                <div class="block-title">
                    <h2>List of Bookings</h2>
                </div>
						<table id="hmis_table" class="table table-vcenter table-condensed table-bordered">
							<thead>
								<tr>
									<th>No.</th>
									<th>Full Name</th>
									<th>Email</th>
									<th>Mobile No</th>
									<th>Country</th>
									<th>Hotel</th>
									<th>Room</th>
									<th>Guests</th>
									<th>Checkin</th>
									<th>Checkout</th>
									<th>Status</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
								<?php 
								if($_REQUEST['ci']){
									HMIS\Reservation::CinCo($_REQUEST['ci'],'CHECKED IN') ;
									$GLOBALS['success']='Chexked IN successfully';
								}
								if($_REQUEST['co']){
									HMIS\Reservation::CinCo($_REQUEST['co'],'CHECKED OUT'); 
									$GLOBALS['success']='Checked OUT successfully';
								}
								$i= 1;HMIS\Payment::payment_c_u(); 
								HMIS\Reservation::reserve_c_u();
								if(G\get_app_setting('user_type')=='User'){ $data0=$_SESSION['UID']; $data1=null;}
								if(G\get_app_setting('user_type')=='Agent'){ $data0=null; $data1=G\get_app_setting('uid');}
								if(G\get_app_setting('user_type')=='Admin'){ $data0=null; $data1=null;}
								foreach(HMIS\Reservation::get_reservations($data0,$data1) as $row){
									$data=HMIS\Profiles::get_profile($row['uid']);
									if($row['r_status']=="BOOKED"){
										$btn1 = '<a href="'.ROOT_URL.'bookings/bookings?ci='.$row['book_id'].'" class="btn btn-xs btn-primary">Check In</a>';
									}elseif($row['r_status']=="CHECKED IN"){
										$btn1 = '<a href="'.ROOT_URL.'bookings/bookings?co='.$row['book_id'].'" class="btn btn-xs btn-primary">Check Out</a>';
									}else{
										$btn1 = '<a href="#" class="btn btn-xs btn-primary">BOOKING CLOSED</a>';
									}
									if($row['r_status']=='BOOKED' || $row['r_status']=='CHECKED IN' || $row['r_status']=='CHECKED OUT'){
									echo 
										'<tr> 
											<td>'.$i++.'</td>
											<td>'.$data['first_name'].' '.$data['middle_name'].' '.$data['last_name'].'</td>
											<td>'.$data['email'].'</td>
											<td>'.$data['mobileno'].'</td>
											<td>'.$row['country'].'</td>
											<td>'.$row['property_name'].'</td>
											<td>'.$row['room_name'].'</td>
											<td>'.HMIS\n2w($row['no_of_guests']).' Guest(s)</td>
											<td>'.$row['checkin'].'</td>
											<td>'.$row['checkout'].'</td>
											<td>'.$row['r_status'].'</td>
											<td width="10%">
												'.$btn1.'
											</td>
										</tr>';}
								}?>
							</tbody>
						</table>
            </div>
        </div>
			</form>
    </div>
    </div>

   <div id="pullup" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title"> Booking Management</h4>
            </div>
            <!-- END Modal Header -->

            <!-- Modal Body -->
            <div class="modal-body">
                    <div id="response">
                    </div>
            </div>
            <!-- END Modal Body -->
        </div>
    </div>
   </div>




</div>