<?php
namespace HMIS;
use G, Exception;
class Web {
	public static function favorite($limit) {
		$DB=DB::vanillaDB();
		$DB->query('SELECT * FROM '.G\get_app_setting('db_table_prefix').'rooms 
		INNER JOIN '.G\get_app_setting('db_table_prefix').'properties 
		ON '.G\get_app_setting('db_table_prefix').'rooms.pid='.G\get_app_setting('db_table_prefix').'properties.pid
		ORDER BY '.G\get_app_setting('db_table_prefix').'rooms.booked DESC LIMIT '.$limit.'');
		return $DB->resultset();
	}
	public static function rooms($type) {
		$DB=DB::vanillaDB();
		$DB->query('
		SELECT * FROM '.G\get_app_setting('db_table_prefix').'rooms 
		INNER JOIN '.G\get_app_setting('db_table_prefix').'properties 
		ON '.G\get_app_setting('db_table_prefix').'rooms.pid='.G\get_app_setting('db_table_prefix').'properties.pid
		WHERE '.G\get_app_setting('db_table_prefix').'rooms.room_type LIKE :room_type');
		$DB->bind('room_type',"%".$type."%");
		return $DB->resultset();
	}
	public static function search() {
		$data =	self::favorite(15);
		if(isset($_POST['search'])){
		$DB=DB::vanillaDB();
		$DB->query('
		SELECT * FROM '.G\get_app_setting('db_table_prefix').'rooms 
		JOIN '.G\get_app_setting('db_table_prefix').'properties 
		ON '.G\get_app_setting('db_table_prefix').'rooms.pid='.G\get_app_setting('db_table_prefix').'properties.pid
		WHERE 
		'.G\get_app_setting('db_table_prefix').'rooms.room_type LIKE :search ||
		'.G\get_app_setting('db_table_prefix').'rooms.room_name LIKE :search ||
		'.G\get_app_setting('db_table_prefix').'rooms.price_per_night LIKE :search ||
		'.G\get_app_setting('db_table_prefix').'rooms.description LIKE :search ||
		'.G\get_app_setting('db_table_prefix').'properties.city LIKE :search ||
		'.G\get_app_setting('db_table_prefix').'properties.street_address LIKE :search ||
		'.G\get_app_setting('db_table_prefix').'properties.country LIKE :search 
		');
		$DB->bind(':search',"%".$_POST['search']."%");
		$data = $DB->resultset();
		}
		if(isset($_POST['advance_search'])){
		$DB=DB::vanillaDB();
		$DB->query('
		SELECT * FROM '.G\get_app_setting('db_table_prefix').'rooms 
		JOIN '.G\get_app_setting('db_table_prefix').'properties 
		ON '.G\get_app_setting('db_table_prefix').'rooms.pid='.G\get_app_setting('db_table_prefix').'properties.pid
		WHERE '.
		G\get_app_setting('db_table_prefix').'rooms.room_type LIKE :room_type && '.
		G\get_app_setting('db_table_prefix').'rooms.price_per_night <= :budget && '.
		G\get_app_setting('db_table_prefix').'properties.property_name LIKE :property_name && '.
		G\get_app_setting('db_table_prefix').'properties.city LIKE :city && '.
		G\get_app_setting('db_table_prefix').'properties.country=:country 
		');
		$DB->bind(':room_type',$_POST['room_type']);
		$DB->bind(':country',$_POST['country']);
		$DB->bind(':city',"%".$_POST['city']."%");
		$DB->bind(':budget',"%".$_POST['budget']."%");
		$DB->bind(':property_name',"%".$_POST['property_name']."%");
		$data = $DB->resultset();
		}
		
		return($data);
	}
	
	
	public static function other_rooms($id,$type,$limit=3) {
		$DB=DB::vanillaDB();
		$DB->query('
		SELECT * FROM '.G\get_app_setting('db_table_prefix').'rooms 
		INNER JOIN '.G\get_app_setting('db_table_prefix').'properties 
		ON '.G\get_app_setting('db_table_prefix').'rooms.pid='.G\get_app_setting('db_table_prefix').'properties.pid
		WHERE '.G\get_app_setting('db_table_prefix').'rooms.room_id != :room_id && '.G\get_app_setting('db_table_prefix').'rooms.room_type = :room_type
		ORDER BY RAND()
		LIMIT '.$limit.'');
		$DB->bind('room_type',$type);
		$DB->bind('room_id',$id);
		return $DB->resultset();
	}
    public static function room($request) {
		return Properties::get_room($request);
	}
	public static function facilities($request,$type='main', $values=null) {
		$data = Properties::get_facilities($request);
		if($type=='main'){
		$values .=
		'<table class="table table-striped mt30">
              <tbody>
                <tr>
                  <td><i class="fa ';if($data['internet']=='YES'){$values .='fa-check-circle';}else{$values .='fa-times-circle';} $values .='"></i> Internet</td>
                  <td><i class="fa ';if($data['parking']=='YES'){$values .='fa-check-circle';}else{$values .='fa-times-circle';} $values .='"></i> Parking</td>
                  <td><i class="fa ';if($data['restraunt']=='YES'){$values .='fa-check-circle';}else{$values .='fa-times-circle';} $values .='"></i> Restaurant</td>
                </tr>
                <tr>
                  <td><i class="fa ';if($data['room_service']=='YES'){$values .='fa-check-circle';}else{$values .='fa-times-circle';} $values .='"></i> Room Service</td>
                  <td><i class="fa ';if($data['bar']=='YES'){$values .='fa-check-circle';}else{$values .='fa-times-circle';} $values .='"></i> Bar</td>
                  <td><i class="fa ';if($data['air_conditioning']=='YES'){$values .='fa-check-circle';}else{$values .='fa-times-circle';} $values .='"></i> Air Condition</td>
                </tr>
                <tr>
                  <td><i class="fa ';if($data['sauna']=='YES'){$values .='fa-check-circle';}else{$values .='fa-times-circle';} $values .='"></i> Sauna</td>
                  <td><i class="fa ';if($data['garden']=='YES'){$values .='fa-check-circle';}else{$values .='fa-times-circle';} $values .='"></i> Garden</td>
                  <td><i class="fa ';if($data['fitness_center']=='YES'){$values .='fa-check-circle';}else{$values .='fa-times-circle';} $values .='"></i> Fitness Center</td>
                </tr>
                <tr>
                  <td><i class="fa ';if($data['terrace']=='YES'){$values .='fa-check-circle';}else{$values .='fa-times-circle';} $values .='"></i> Terrace</td>
                  <td><i class="fa ';if($data['non_smoking_rooms']=='YES'){$values .='fa-check-circle';}else{$values .='fa-times-circle';} $values .='"></i> Non-Smoking Rooms</td>
                  <td><i class="fa ';if($data['airport_shuttle']=='YES'){$values .='fa-check-circle';}else{$values .='fa-times-circle';} $values .='"></i> Airport Shuttle</td>
                </tr>
				<tr>
                  <td><i class="fa ';if($data['family_rooms']=='YES'){$values .='fa-check-circle';}else{$values .='fa-times-circle';} $values .='"></i> Family Rooms</td>
                  <td><i class="fa ';if($data['spa']=='YES'){$values .='fa-check-circle';}else{$values .='fa-times-circle';} $values .='"></i> Spa</td>
                  <td><i class="fa ';if($data['beach']=='YES'){$values .='fa-check-circle';}else{$values .='fa-times-circle';} $values .='"></i> Beach</td>
                </tr>
				<tr>
                  <td><i class="fa ';if($data['swimming_pool']=='YES'){$values .='fa-check-circle';}else{$values .='fa-times-circle';} $values .='"></i> Swimming Pool</td>
                  <td><i class="fa ';if($data['hot_tub_jacuzzi']=='YES'){$values .='fa-check-circle';}else{$values .='fa-times-circle';} $values .='"></i> Jacuzzi</td>
                  <td><i class="fa ';if($data['water_park']=='YES'){$values .='fa-check-circle';}else{$values .='fa-times-circle';} $values .='"></i> Water Park</td>
                </tr>
              </tbody>
            </table>';}elseif($type=='sub'){
			
			
			$values .='
			<div class="row">
                <div class="col-xs-6">
                  <ul class="list-unstyled">
                    <li><i class="fa ';if($data['internet']=='YES'){$values .='fa-check-circle';}else{$values .='fa-times-circle';} $values .='"></i> Internet</li>
                    <li><i class="fa ';if($data['restraunt']=='YES'){$values .='fa-check-circle';}else{$values .='fa-times-circle';} $values .='"></i> Restaurant</li>
                    <li><i class="fa ';if($data['room_service']=='YES'){$values .='fa-check-circle';}else{$values .='fa-times-circle';} $values .='"></i> Room Service</li>
                  </ul>
                </div>
                <div class="col-xs-6">
                  <ul class="list-unstyled">
                    <li><i class="fa ';if($data['24_hour_front_desk']=='YES'){$values .='fa-check-circle';}else{$values .='fa-times-circle';} $values .='"></i> 24 Hour Front Desk</li>
                    <li><i class="fa ';if($data['airport_shuttle']=='YES'){$values .='fa-check-circle';}else{$values .='fa-times-circle';} $values .='"></i> Airport Shuttle</li>
                    <li><i class="fa ';if($data['swimming_pool']=='YES'){$values .='fa-check-circle';}else{$values .='fa-times-circle';} $values .='"></i> Swimming Pool</li>
                  </ul>
                </div>
              </div>';
		}
		return($values);
	}
	
	
}
