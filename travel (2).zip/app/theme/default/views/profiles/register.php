 <form  method="post" >
	<fieldset>
		<input type="hidden" class="form-control" name="uid" value="<?=$_POST["id"]?>">
	<div class="form-group col-md-12">
		<label class="control-label">First Name:</label>
		<input type="text" class="form-control" name="first_name">
	</div>
	<div class="form-group col-md-12">
		<label class="control-label">Middle Name:</label>
		<input type="text" class="form-control" name="middle_name">
	</div>
	<div class="form-group col-md-12">
		<label class="control-label">Last Name:</label>
		<input type="text" class="form-control" name="last_name">
	</div>
	<div class="form-group col-md-6">
		<label class="control-label">Email:</label>
		<input type="text" class="form-control" name="email">
	</div>
	<div class="form-group col-md-6">
		<label class="control-label">Mobile No:</label>
		<input type="text" class="form-control" name="mobile_no">
	</div>
	
	<div class="form-group col-md-12">
		<label class="control-label">Notes:</label>
		<textarea rows="4" class="form-control" name="user_notes"></textarea>
	</div> 
		<input type="hidden" class="form-control" name="reg_date" value="<?=date('Y-m-d')?>">

</fieldset>
 <div class="form-group form-actions">
                        <div class="col-xs-12 text-right">
                           <button type="submit" name="btn_staff" class="btn btn-sm btn-primary">Submit</button>
                            <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </form>