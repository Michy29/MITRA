<?php 
namespace HMIS; use G; ob_start(); global $settings;
include'system/loader.php';
(isset($_POST['setup']))?Setup::update_configurations():null;
$settings=array_merge($settings,Setup::read_configurations(),($_SESSION['UID']!=null)?$data=Profiles::get_profile($_SESSION['UID']):array());
G\Run();
?>