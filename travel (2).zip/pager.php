<?php
namespace EMIS;
require_once('system/loader.php');
use G, Exception;
$views = APP_PATH_THEME.'views/';
if($_POST["view"]=='amenities'){
	$_POST["view"]='site';
}
if(isset($_POST["view"])){echo include $views.$_POST["view"].'/'.$_POST["vtype"].'.php';}
?>