<!DOCTYPE html>
<html lang="en">
   <head>
      <title><?=G\get_app_setting('appshortname')?> : : <?=ucwords(G\path()['call_parts'][0])?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8" />
      <script>
         addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); }
      </script>
      <link rel="stylesheet" href="<?=G\Render\get_theme_file_url('assets/css/bootstrap.min.css')?>">
	  <link rel="stylesheet" href="<?=G\Render\get_theme_file_url('assets/css/plugins.css')?>">
      <link rel="stylesheet" href="<?=ROOT_URL?>frontend/css/auth.css" type="text/css" media="all" />
   </head>
   <body>
      <h1 class="header-w3ls">
         <?=G\get_app_setting('company_abbr')?>
      </h1>