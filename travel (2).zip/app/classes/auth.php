<?php
namespace HMIS;
use G, Exception;
class Auth {
	public static function SignUp() {
		$DB=DB::vanillaDB();
			if($_POST['password']<>$_POST['cpassword']){
				$GLOBALS['error']='Your passwords do not match!.';
				die();
			}else{
					$token=RandStr(16);
					$values['password']  = md5($_POST['password']);
					$values['email']  = $_POST['email'];
					$values['token']  = $token;
					$values_['name']  = $_POST['first_name'].' '.$_POST['last_name'];
					Mailer::sendActivation($values,$values_);
					DB::Create('users', $values);
					
			}
	}
	public static function getToken(){
		$data  = DB::ReadSingle('users',array('token'=>G\path()['call_parts'][1]),1);
		$data1 = DB::ReadSingle('profiles',array('email'=>$data['email']),1);
		($data!=null)?$data=(array_merge($data,$data1)):$data= null;
		return($data);
	}
	public static function activateAcc(){
		if($_POST['user_type']==null){
			$GLOBALS['error']='Please select your account type';
		}else{
			$DB=DB::vanillaDB();
			$DB->query('SELECT * FROM '.G\get_app_setting('db_table_prefix').'users WHERE email=:email AND password=:password AND token=:token');
			$DB->bind(':email', $_POST['email']);
			$DB->bind(':password', md5($_POST['password']));
			$DB->bind(':token', G\path()['call_parts'][1]);
			if($DB->single()==null){
				$GLOBALS['error']='Invalid password, try again';
			}else{
				$values['token']  = null;
				$values['status']  = 'ACTIVE';
				$values['user_type']  = $_POST['user_type'];
				DB::Update('users', $values,array('email'=>$_POST['email']));
				$data=DB::ReadSingle('profiles',array('email'=>$_POST['email']),1);
				$msg='Hello '.$data['first_name'].', Thank you for registering with '.G\get_app_setting('company_name').'. Login to the dashboard with your email and password.';
				SMS::sendSMS($data['mobileno'], $msg);
				$GLOBALS['success']='Account activated successfully';
				
			}
		}
		$data  = DB::ReadSingle('users',array('token'=>G\path()['call_parts'][1]),1);
		$data1 = DB::ReadSingle('profiles',array('email'=>$data['email']),1);
		($data!=null)?$data=(array_merge($data,$data1)):$data= null;
		return($data);
	}
	public static function Reset() {
		if(self::CHK()==null){
			$GLOBALS['error']='No matching record was found!';
		}else{
				$npass=RandStr();
				$values['password']=md5($npass);
				DB::Update('users', $values,array('email'=>$_POST['email']));
				$msg='Use '.$npass.' as your new password to login to the dashboard';
				SMS::sendSMS($_POST['mobileno'], $msg);
				$values=array();
				$values['password']=$npass;
				$values['email']=$_POST['email'];
				$values_['name']  = self::CHK()['first_name'].' '.self::CHK()['last_name'];
				Mailer::ResetPassword($values,$values_);
				$GLOBALS['success']='A new password has been sent to you.';
		}
	}
	public static function change_pass() {
		$data=DB::ReadSingle('users',array('email'=>Profiles::get_profile($_SESSION['UID'])['email']),1);
		
		if(md5($_POST['cpass'])<>$data['password']){
			$GLOBALS['error']='The current password you entered is incorrect';
		}else{
			if($_POST['npass']<>$_POST['rpass']){
				$GLOBALS['error']='New passwords do not match!';
			}else{
				try{
					$values['password']  = md5($_POST['npass']);
					$checks=array('email'=>$data['email']);
					DB::Update('users', $values,$checks);
					$GLOBALS['success']='Password changed successfully';
					} catch(Exception $e) {
						$GLOBALS['error']='An error occured while resetting';
					}
			}
		}
	}
	public static function Login() {
		$DB=DB::vanillaDB();
		$DB->query('SELECT * FROM '.G\get_app_setting('db_table_prefix').'users WHERE email=:email AND password=:password');
		$DB->bind(':email', $_POST['email']);
		$DB->bind(':password', md5($_POST['password']));
		$data=$DB->single();
		if($data==null){
			$GLOBALS['error']='Invalid login credentials';
		}else{
			if($data['status']=='INACTIVE'){
				$GLOBALS['error']='Your account is not activated, check your email for the activation link';
			}else{
				$_SESSION['UID']=DB::ReadSingle('profiles',array('email'=>$data['email']),1)['uid'];
				header('location:'.ROOT_URL.'dashboard');
			}
				
		}
	}
	public static function CHK(){
		$DB=DB::vanillaDB();
		$DB->query('SELECT * FROM '.G\get_app_setting('db_table_prefix').'profiles WHERE email=:email AND first_name=:first_name AND mobileno LIKE :mobileno');
		$DB->bind(':email', $_POST['email']);
		$DB->bind(':first_name', $_POST['first_name']);
		$DB->bind(':mobileno', "%".substr($_POST['mobileno'] , -9)."%");
		return $DB->single();
	}
}