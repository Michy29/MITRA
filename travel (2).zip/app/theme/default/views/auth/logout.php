<?php
	unset($_SESSION['UID']);
	header('Location:'.ROOT_URL);
	die();
	
