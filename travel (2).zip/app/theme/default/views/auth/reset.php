<?php
(isset($_POST['btn_reset']))?HMIS\Auth::Reset():null;
?>
      <div class="main-bothside">
         <form  method="post">
            <div class="form-group">
               <div class="form-m-w3ls">
                  <p>First Name</p>
                  <input type="text" name="first_name"     required>
               </div>
            </div>
            <div class="form-group">
               <div class="form-m-w3ls">
                  <p>Email</p>
                  <input type="email" name="email"    required>
               </div>
            </div>
            <div class="form-group">
               <div class="form-m-w3ls">
                  <p>Mobile No.</p>
                  <input type="text" name="mobileno"   required>
               </div>
            </div>
            <div class="btnn">
               <input type="submit" name="btn_reset" value="Reset Password">
            </div>
			 <hr>
            <span ><strong style="color:aliceblue">Don't have an account?</strong> <a style="color:yellow" href="<?=ROOT_URL?>register">Register Here</a></span><br/><br/>
            <span ><strong style="color:aliceblue">Remember password?</strong> <a style="color:yellow" href="<?=ROOT_URL?>login">Login Here</a></span>
            
         </form>
      </div>
      