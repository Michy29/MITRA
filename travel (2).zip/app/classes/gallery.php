<?php
namespace HMIS;
use G, Exception;

class Gallery {
	private static $string = 'image_id, image_name, image_caption';
	private static $table = 'gallery';
	public static function image_c_u($image_type='SLIDER') {
		if(isset($_POST['btn_gallery'])){
		$request=array('image_id'=>$_POST['image_id']);
		if(DB::ReadSingle(self::$table,$request,1)==null){
			self::register_image($image_type);
		}else{
			self::update_image();
		}
		}
	}
	public static function register_image($image_type) {
		$inserts = self::$string;
		try{
		$target_dir = ROOT_PATH."content/gallery/";
		$file = getimagesize($_FILES["image_name"]["tmp_name"]);
		$fileTmp = $_FILES["image_name"]["tmp_name"];
		$fileName = $_FILES["image_name"]["name"];
		$splitName = explode(".", $fileName);
		$fileExt = end($splitName);
		$finalfilename  = strtolower('portsview_hotel_'.$_POST['image_id'].'.'.$fileExt);
		if($file !== false) {
			if ($_FILES["image_name"]["size"] > 2048000) {
				$GLOBALS['error']='Maximum file size exceeded'.$_FILES["image_name"]["size"];
			}else{
				if($fileExt != "jpg" && $fileExt != "png" && $fileExt != "jpeg") {
						$GLOBALS['error']='Sorry, only JPG, JPEG & PNG  files are allowed.';
					}else{
					if(move_uploaded_file($fileTmp, $target_dir.$finalfilename)){
						$values['image_id']=$_POST['image_id'];
						$values['image_name']=$finalfilename;
						$values['image_caption']=$_POST['image_caption'];
						$values['image_type']=$image_type;
						DB::Create(self::$table, $values);
						$GLOBALS['success']='Upload successful';
					}else{
						$GLOBALS['error']='An error occured while uploading file';
					}
				}
			}
				
		} else {
			$GLOBALS['error']='The file you uploaded is not an image!';
		}	
		} catch(Exception $e) {
			$GLOBALS['error']='Upload not successful';
		}
	}
	public static function get_image($request) {
		$request=array('image_id'=>$request);
		return DB::ReadSingle(self::$table,$request,1);
	}
	public static function get_images($request,$limit=null) {
		$request=array('image_type'=>$request);
		return DB::ReadMulti(self::$table,$request,$limit);
	}
	
	public static function update_image() {
		$updates =self::$string;
		try{
		$values['image_id']=$_POST['image_id'];
		$values['image_caption']=$_POST['image_caption'];
		$checks=array('image_id'=>$_POST['image_id']);
		DB::Update(self::$table, $values,$checks);
		$GLOBALS['success']='Caption updated successfully';
			
		} catch(Exception $e) {
			$GLOBALS['error']='An error occured while updating';
		}
	}
	public static function delete_image($request){
		unlink(ROOT_PATH.'content/gallery/'.self::get_image($request)['image_name']);
		G\DB::Delete(self::$table, array('image_id'=>$request));
	}
}
