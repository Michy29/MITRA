<?php
namespace HMIS;
use G, Exception;

class Properties {
	private static $string = 'pid, property_name, contact_name, contact_number, contact_email, street_address, address_line2, country, city, zipcode, owner';
	private static $string0 = 'room_id, pid, room_type, room_name, smoking_policy, number_of_rooms, bed_types, number_of_beds, maximum_guests, price_per_night, description';
	private static $string1 = 'room_id, internet, parking, restraunt, room_service, bar, 24_hour_front_desk, sauna, garden, fitness_center, terrace, non_smoking_rooms, airport_shuttle, family_rooms, spa, beach, swimming_pool, hot_tub_jacuzzi, water_park, air_conditioning';
	
	private static $table = 'properties';
	private static $table0 = 'rooms';
	private static $table1 = 'facilities';
	
	public static function property_c_u() {
	(isset($_POST['btn_property']))?(DB::ReadSingle(self::$table,array('pid'=>$_POST['pid']),1)==null)?self::register_property():self::update_property():'';	
	(isset($_POST['btn_room']))?(DB::ReadSingle(self::$table0,array('room_id'=>$_POST['room_id']),1)==null)?self::register_room():self::update_room():'';
	(isset($_POST['btn_facilities']))?(DB::ReadSingle(self::$table1,array('room_id'=>$_POST['room_id']),1)==null)?self::add_facilities():self::update_facilities():'';
	(isset($_POST['btn_pics']))?self::uploader():null;
	}
	public static function register_property() {
		$inserts = self::$string;
		try{
		$fields=explode(', ', $inserts);
		foreach($fields as $data){
			$values[$data]  = $_POST[$data];
		}
		DB::Create(self::$table, $values);
		$GLOBALS['success']='Property registered successfully';
			
		} catch(Exception $e) {
			$GLOBALS['error']='Database error occured while registering.';
		}
	}
	public static function add_facilities() {
		$inserts = self::$string1;
		try{
		$fields=explode(', ', $inserts);
		foreach($fields as $data){
			$values[$data]  = $_POST[$data];
		}
		DB::Create(self::$table1, $values);
		$GLOBALS['success']='Facilities added successfully';
			
		} catch(Exception $e) {
			$GLOBALS['error']='Database error occured while registering.';
		}
	}
	public static function register_room() {
		$inserts = self::$string0;
		try{
		$fields=explode(', ', $inserts);
		foreach($fields as $data){
			$values[$data]  = $_POST[$data];
		}
		DB::Create(self::$table0, $values);
		$GLOBALS['success']='Room registered successfully';
			
		} catch(Exception $e) {
			$GLOBALS['error']='Database error occured while registering.'.$e->getMessage();
		}
	}
	public static function get_property($request) {
		$data 	= DB::ReadSingle(self::$table,array('pid'=>$request),1);
		$data0 	= DB::ReadSingle('profiles',array('uid'=>$data['owner']),1);
		return(array_merge($data,$data0));
	}
	public static function get_properties($request=null) {
		if($request==null){
			return DB::ReadMulti(self::$table);
		}else{
			return DB::ReadMulti(self::$table,array('owner'=>$request));
		}
	}
	public static function get_room($request) {
		$data 	= DB::ReadSingle(self::$table0,array('room_id'=>$request),1);
		$data0 	= DB::ReadSingle(self::$table,array('pid'=>$data['pid']),1);
		return(array_merge($data,$data0));
	}
	public static function get_facilities($request) {
		return DB::ReadSingle(self::$table1,array('room_id'=>$request),1);
	}
	public static function get_rooms($request=null) {
		$DB=DB::vanillaDB();
		$DB->query('
		SELECT * FROM '.G\get_app_setting('db_table_prefix').self::$table0.' 
		INNER JOIN '.G\get_app_setting('db_table_prefix').self::$table.' 
		ON '.G\get_app_setting('db_table_prefix').self::$table0.'.pid='.G\get_app_setting('db_table_prefix').self::$table.'.pid');
		return $DB->resultset();
	}
	public static function update_property() {
		$updates =self::$string;
		try{
		$fields=explode(', ', $updates);
		foreach($fields as $data){
				$values[$data]  = $_POST[$data];
		}
		$checks=array('pid'=>$_POST['pid']);
		DB::Update(self::$table, $values,$checks);
		$GLOBALS['success']='Property updated successfully';
			
		} catch(Exception $e) {
			$GLOBALS['error']='An error occured while updating';
		}
	}
	public static function update_facilities() {
		$updates =self::$string1;
		try{
		$fields=explode(', ', $updates);
		foreach($fields as $data){
				$values[$data]  = $_POST[$data];
		}
		$checks=array('room_id'=>$_POST['room_id']);
		DB::Update(self::$table1, $values,$checks);
		$GLOBALS['success']='Facilities updated successfully';
			
		} catch(Exception $e) {
			$GLOBALS['error']='An error occured while updating';
		}
	}
	public static function update_room() {
		$updates =self::$string0;
		try{
		$fields=explode(', ', $updates);
		foreach($fields as $data){
				$values[$data]  = $_POST[$data];
		}
		$checks=array('room_id'=>$_POST['room_id']);
		DB::Update(self::$table0, $values,$checks);
		$GLOBALS['success']='Room updated successfully';
			
		} catch(Exception $e) {
			$GLOBALS['error']='An error occured while updating';
		}
	}
	public static function uploader(){
		$updates = 'room_pic_1, room_pic_2, room_pic_3, room_pic_4, room_pic_5, room_pic_6';
		$target_dir = ROOT_PATH."content/rooms/";
		$checks=array('room_id'=>$_POST['room_id']);
		if(@getimagesize($_FILES['room_pic_1']["tmp_name"])==true){
			$name='_r001';
			$fileTmp = $_FILES['room_pic_1']["tmp_name"];
			$fileName = $_FILES['room_pic_1']["name"];
			$splitName = explode(".", $fileName);
			$fileExt = end($splitName);
			$finalfilename  = strtolower(G\get_app_setting('company_abbr').'_'.$_POST['room_id'].$name.'.'.$fileExt);
				if(move_uploaded_file($fileTmp, $target_dir.$finalfilename)){
					$values['room_pic_1']=$finalfilename;
					DB::Update('rooms', $values,$checks);
				}else{
					$GLOBALS['error']='An error occured while uploading file';
					die();
				}
		}
		if(@getimagesize($_FILES['room_pic_2']["tmp_name"])==true){
			$name='_r002';
			$fileTmp = $_FILES['room_pic_2']["tmp_name"];
			$fileName = $_FILES['room_pic_2']["name"];
			$splitName = explode(".", $fileName);
			$fileExt = end($splitName);
			$finalfilename  = strtolower(G\get_app_setting('company_abbr').'_'.$_POST['room_id'].$name.'.'.$fileExt);
				if(move_uploaded_file($fileTmp, $target_dir.$finalfilename)){
					$values['room_pic_2']=$finalfilename;
					DB::Update('rooms', $values,$checks);
				}else{
					$GLOBALS['error']='An error occured while uploading file';
					die();
				}
		}
		if(@getimagesize($_FILES['room_pic_3']["tmp_name"])==true){
			$name='_r003';
			$fileTmp = $_FILES['room_pic_3']["tmp_name"];
			$fileName = $_FILES['room_pic_3']["name"];
			$splitName = explode(".", $fileName);
			$fileExt = end($splitName);
			$finalfilename  = strtolower(G\get_app_setting('company_abbr').'_'.$_POST['room_id'].$name.'.'.$fileExt);
				if(move_uploaded_file($fileTmp, $target_dir.$finalfilename)){
					$values['room_pic_3']=$finalfilename;
					DB::Update('rooms', $values,$checks);
				}else{
					$GLOBALS['error']='An error occured while uploading file';
					die();
				}
		}
		if(@getimagesize($_FILES['room_pic_4']["tmp_name"])==true){
			$name='_r004';
			$fileTmp = $_FILES['room_pic_4']["tmp_name"];
			$fileName = $_FILES['room_pic_4']["name"];
			$splitName = explode(".", $fileName);
			$fileExt = end($splitName);
			$finalfilename  = strtolower(G\get_app_setting('company_abbr').'_'.$_POST['room_id'].$name.'.'.$fileExt);
				if(move_uploaded_file($fileTmp, $target_dir.$finalfilename)){
					$values['room_pic_4']=$finalfilename;
					DB::Update('rooms', $values,$checks);
				}else{
					$GLOBALS['error']='An error occured while uploading file';
					die();
				}
		}
		if(@getimagesize($_FILES['room_pic_5']["tmp_name"])==true){
			$name='_r005';
			$fileTmp = $_FILES['room_pic_5']["tmp_name"];
			$fileName = $_FILES['room_pic_5']["name"];
			$splitName = explode(".", $fileName);
			$fileExt = end($splitName);
			$finalfilename  = strtolower(G\get_app_setting('company_abbr').'_'.$_POST['room_id'].$name.'.'.$fileExt);
				if(move_uploaded_file($fileTmp, $target_dir.$finalfilename)){
					$values['room_pic_5']=$finalfilename;
					DB::Update('rooms', $values,$checks);
				}else{
					$GLOBALS['error']='An error occured while uploading file';
					die();
				}
		}
		if(@getimagesize($_FILES['room_pic_6']["tmp_name"])==true){
			$name='_r006';
			$fileTmp = $_FILES['room_pic_6']["tmp_name"];
			$fileName = $_FILES['room_pic_6']["name"];
			$splitName = explode(".", $fileName);
			$fileExt = end($splitName);
			$finalfilename  = strtolower(G\get_app_setting('company_abbr').'_'.$_POST['room_id'].$name.'.'.$fileExt);
				if(move_uploaded_file($fileTmp, $target_dir.$finalfilename)){
					$values['room_pic_6']=$finalfilename;
					DB::Update('rooms', $values,$checks);
				}else{
					$GLOBALS['error']='An error occured while uploading file';
					die();
				}
		}
		$GLOBALS['success']='Upload successful';
	}
	public static function delete_property($request){
		G\DB::Delete(self::$table, array('pid'=>$request));
	}
	public static function delete_room($request){
		G\DB::Delete(self::$table0, array('room_id'=>$request));
	}
}
