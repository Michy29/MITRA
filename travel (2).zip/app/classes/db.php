<?php
namespace HMIS;
use G, Exception;
class DB {
	public static function Create($table, $values) {
		G\DB::Create($table, $values);
		
	}
	public static function ReadSingle($table,$request){
		return G\DB::Read($table,$request,1);
	}
	public static function Update($table, $values,$checks) {
		G\DB::Update($table, $values,$checks);
		
	}
	public static function ReadMulti($table,$wheras='all'){
		
		return G\DB::Read($table,$wheras);
	}
	public static function vanillaDB(){
		return new G\VDB();
	}
	
}
