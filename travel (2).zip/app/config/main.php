<?php
$settings = [
	'theme'				=> 'default',
	'db_driver'	 		=> 'mysql',
	'db_host'			=> 'localhost', 
	'db_port'			=> '', 
	'db_name'			=> 'travel', 
	'db_user'			=> 'root', 
	'db_pass'			=> '', 
	'db_table_prefix'	=> 'mis_',
	'db_driver' 		=> 'mysql',
	'db_pdo_attrs'		=> [],
	'debug_level' 		=> 1,
	'error_reporting'	=> true,
	'default_timezone'  => 'Africa/Nairobi',
	'environment'		=> 'developer',
];
