 <form  method="post" enctype="multipart/form-data" >
<?php $data=HMIS\Gallery::get_image($_POST["id"])?>
	<fieldset>
		<input type="hidden" class="form-control" name="image_id" value="<?=$_POST["id"]?>">
		
		<div class="form-group col-md-12">
			<label class="control-label">Caption:</label>
			<input type="text" class="form-control" required name="image_caption" value="<?=$data['image_caption']?>">
		</div>
		
		<div class="form-group col-md-12">
			<span>
				<img width="100%" id="blah" src="<?=ROOT_URL?>content/gallery/<?=$data['image_name']?>"/>
			</span>
		</div>                        
	</fieldset>
  <div class="form-group form-actions">
                        <div class="col-xs-12 text-right">
                           <button type="submit" name="btn_gallery" class="btn btn-sm btn-primary">Update</button>
                            <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </form>
                  

                   
                    