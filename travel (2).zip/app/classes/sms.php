<?php
namespace HMIS;
use G;
class SMS{
	public static function SMS() {
		$sms = new G\SMS();
		return($sms);
	}
	public static function sendSMS($r, $msg) {
		$r ="+254".substr($r , -9);
		try 
			{ 
			  self::SMS()->sendMessage($r, $msg);
			}
			catch ( SMSException $e )
			{
			  $GLOBALS['error']= "Encountered an error while sending: ".$e->getMessage();
			}
	}
}