


<!-- Page content -->
<div id="page-content">
    <!-- Blank Header -->
    <div class="content-header">
        <div class="header-section">
            <h1>
                <i class="gi gi-brush"></i>Not Found
            </h1>
        </div>
    </div>
    <div class="block">
		<div id="error-container" class="themed-background-dark-<?=G\get_app_setting('sub_theme')?>">
			<div class="error-options">
				<h3><i class="fa fa-chevron-circle-left text-muted"></i> <a href="<?=APP_URL?>">Go Back</a></h3>
			</div>
			<div class="row">
				<div class="col-sm-8 col-sm-offset-2 text-center">
					<h1 class="animation-pulse"><i class="fa fa-exclamation-circle text-warning"></i> 404</h1>
					<h2 class="h3">Oops, we are sorry but the page you are looking for was not found..<br>But do not worry, we will have a look into it..</h2>
				</div>

			</div>
		</div>
    </div>
    <!-- END Example Block -->
</div>
<!-- END Page Content -->