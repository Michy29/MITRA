   <?=HMIS\Properties::property_c_u()?>
   <div id="page-content">
    <div class="content-header">
        <div class="header-section">
            <h1>
                <i class="fa fa-bed"></i>Rooms<br>
            </h1>
        </div>
    </div>
    <div class="block">
        <div class="row">
        
        <div class="col-sm-12">
            <div class="block">
                <div class="block-title">
                   	<div class="block-options pull-right">
                        	<a href="#pullup" data-toggle="modal" onClick="page_loader('<?=G\path()['call_parts'][0]?>','add_room','RM<?=G\DB::Encoder('rooms')?>')" class="btn btn-sm btn-primary">Add Room</a>
                    </div>
                    
                    <h2>List of Rooms</h2>
                </div>
                	
						<table id="hmis_table" class="table table-vcenter table-condensed table-bordered">
							<thead>
								<tr>
									<th>No.</th>
									<th>Property Name</th>
									<th>Room Name</th>
									<th>Room Type</th>
									<th>Price/Night</th>
									<th>No. of Rooms</th>
									<th>Maximum Occupancy</th>
									<th class="text-center">Actions</th>
								</tr>
							</thead>
							<tbody>
								<?php $i= 1; 
								foreach(HMIS\Properties::get_rooms() as $row){
									$data=HMIS\Profiles::get_profile($_SESSION['UID']);
									if($data['user_type']=='Admin' || $data['uid']==$row['owner']){
									echo 
										'<tr> 
											<td>'.$i++.'</td>
											<td>'.$row['property_name'].'</td>
											<td>'.$row['room_name'].'</td>
											<td>'.$row['room_type'].'</td>
											<td>KES. '.number_format($row['price_per_night'],2).'</td>
											<td>'.HMIS\n2w($row['number_of_rooms']).' Rooms</td>
											<td>'.HMIS\n2w($row['maximum_guests']).' Guests</td>
											<td width="10%">
												'.HMIS\btn($row['room_id'],'properties','E','edit_room',' ').'
												'.HMIS\btn($row['room_id'],'properties','E','facilities',' ','list','Manage Room Facilities','success').'
												'.HMIS\btn($row['room_id'],'properties','E','uploader',' ','image','Upload Room Images','warning').'
												'.HMIS\btn($row['room_id'],'rooms','D','',' ').'
											</td>
										</tr>';
								}}?>
							</tbody>
						</table>
            </div>
        </div>
			</form>
    </div>
    </div>
    
    <div id="pullup" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title"> Room Management</h4>
            </div>
            <!-- END Modal Header -->

            <!-- Modal Body -->
            <div class="modal-body"><div id="response"></div></div>
            <!-- END Modal Body -->
        </div>
    </div>
</div>
    
</div>





