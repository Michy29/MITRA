<?php 
if(isset($_POST['info'])){
	HMIS\setup::update_info();
}
$data=HMIS\Setup::read_info();
?>
   <div id="page-content">
    <div class="content-header">
        <div class="header-section">
            <h1>
                <i class="fa fa-shopping-basket"></i>About Us<br>
            </h1>
        </div>
    </div>
    <div class="block">
        <div class="row">
        
        <div class="col-sm-12">
            <div class="block">
                <div class="block-title">
                    <h2>About <?=G\get_app_setting('company_name')?></h2>
                </div>
               
                	
						<form  class="form-bordered" method="post">
							<fieldset>
								<div class="form-group col-md-12">
									<label class="control-label">About US:</label>
									<textarea   class="ckeditor" name="about_us"><?=@$data['about_us']?></textarea>
								</div>
								<div class="form-group col-md-12">
									<label class="control-label">Why Us</label>
									<textarea   class="ckeditor" class="form-control" name="whyus"><?=@$data['whyus']?></textarea>
								</div>
								<div class="form-group col-md-12">
									<label class="control-label">Core Values</label>
									<textarea   class="ckeditor" class="form-control" name="core_values"><?=@$data['core_values']?></textarea>
								</div>
						   </fieldset>
							<div  class="form-group form-actions">
							   <fieldset>
									<button style="float: right" name="info" type="submit" class="btn btn-sm btn-info">Submit</button>
							   </fieldset> 
							</div>
						</form>
           		
            </div>
        </div>
			</form>
    </div>
    </div>
</div>





