<?php
namespace HMIS;
use G, Exception;

class Payment {
	private static $string = 'payid, transaction_no, payment_mode, book_id, due, paid, balance, paydate, status';
	private static $table = 'payments';
	public static function payment_c_u() {
		if(isset($_POST['btn_pay'])){
		$request=array('payid'=>$_POST['payid']);
		if(DB::ReadSingle(self::$table,$request,1)==null){
			self::make_payment();
		}else{
			self::update_payment();
		}
		}
	}
	public static function make_payment() {
		$inserts = self::$string;
		try{
		$fields=explode(', ', $inserts);
		foreach($fields as $data){
			(isset($_POST[$data]))?$values[$data] = $_POST[$data]:null;
		}
		$values['balance'] = $_POST['due']-$_POST['paid'];
		$values['paydate'] = date('Y-m-d');
		$values['status'] = 'Paid';
		$value_['r_status']  = 'BOOKED';
		DB::Update('reservations', $value_,array('book_id'=>$_POST['book_id']));
		DB::Create(self::$table, $values);
		$GLOBALS['success']='Payment successful';
			
		} catch(Exception $e) {
			$GLOBALS['error']='Payment not successful'.$e->getMessage();
		}
	}
	public static function get_payment($request,$r2=null) {
		if($r2==null){
		$data  = DB::ReadSingle(self::$table,array('payid'=>$request),1);
		return($data);
		}else{
			$data  = DB::ReadSingle(self::$table,array('book_id'=>$request),1);
		return($data);
		}
	}
	public static function get_payments() {
		$DB=DB::vanillaDB();
		$DB->query('
		SELECT * FROM '.G\get_app_setting('db_table_prefix').self::$table.' 
		INNER JOIN '.G\get_app_setting('db_table_prefix').'reservations 
		ON '.G\get_app_setting('db_table_prefix').self::$table.'.book_id='.G\get_app_setting('db_table_prefix').'reservations.book_id 
		INNER JOIN '.G\get_app_setting('db_table_prefix').'profiles 
		ON '.G\get_app_setting('db_table_prefix').'profiles.uid='.G\get_app_setting('db_table_prefix').'reservations.uid ');
		return $DB->resultset();
	}
	public static function update_payment() {
		$updates =self::$string;
		try{
		$fields=explode(', ', $updates);
		foreach($fields as $data){
				$values[$data]  = $_POST[$data];
		}
		$checks=array('uid'=>$_POST['uid']);
		DB::Update(self::$table, $values,$checks);
		$GLOBALS['success']='Record updated successfully';
			
		} catch(Exception $e) {
			$GLOBALS['error']='An error occured while updating';
		}
	}
	public static function manage_rights() {
		$updates ='';
		try{
		$fields=explode(', ', $updates);
		foreach($fields as $data){
				$values[$data]  = $_POST[$data];
		}
		$checks=array('uid'=>$_POST['uid']);
		DB::Update('rights', $values,$checks);
		$GLOBALS['success']='User rights updated successfully';
			
		} catch(Exception $e) {
			$GLOBALS['error']='An error occured while updating rights';
		}
	}
	public static function delete_payment($request){
		$data= self::get_payment($request);
		G\DB::Delete(self::$table, array('uid'=>$request));
		G\DB::Delete('users', array('email'=>$data['email']));
	}
}
