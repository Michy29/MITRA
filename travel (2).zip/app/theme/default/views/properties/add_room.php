 <form  method="post" >
	<fieldset>
			<input type="hidden" class="form-control" name="room_id" value="<?=$_POST["id"]?>">
		<div class="form-group col-md-12">
			<label class="control-label">Associate Property:</label>
			<select class="form-control" name="pid">
				<option class="hidden">Please select...</option> 
				<?php foreach(HMIS\Properties::get_properties($_SESSION['UID']) as $row){?>						
					<option  value="<?=$row['pid']?>"><?=$row['property_name']?></option>
				<?php }?>
			</select>
		</div>
		<div class="form-group col-md-6">
			<label class="control-label">Room Type:</label>
			<select class="form-control" name="room_type">
				<option class="hidden">Please select...</option> 
				<option>Single Room</option>
				<option>Double Room</option>
				<option>Twin </option>
				<option>Triple </option>
				<option>Quadruple </option>
				<option>Family </option>
				<option>Suite </option>
				<option>Studio </option>
				<option>Apartment </option>
				<option>Dormitory </option>
			</select>
		</div>
		<div class="form-group col-md-6">
			<label class="control-label">Room Name:</label>
			<select class="form-control" name="room_name" >
				<option class="hidden">Please select...</option> 
				<?=include('room_names.php')?>
			</select>
				
		</div>
		<div class="form-group col-md-12">
			<label class="control-label">Smoking Policy:</label>
			<select class="form-control" name="smoking_policy" >
				<option class="hidden">Please select...</option> 
				<option >Non-Smoking</option> 
				<option >Smoking</option> 
				<option >I have both smoking and non-smoking options for this room</option>
			</select>
		</div>
		
		<div class="form-group col-md-6">
			<label class="control-label">Bed Types:</label>
			<select class="form-control" name="bed_types">
                <option >Twin bed(s)&nbsp;&nbsp;/&nbsp;&nbsp;90-130 cm wide</option>
                <option >Full bed(s)  &nbsp;&nbsp;/&nbsp;&nbsp;131-150 cm wide</option>
                <option >Queen bed(s)  &nbsp;&nbsp;/&nbsp;&nbsp;151-180 cm wide</option>
                <option >King bed(s)  &nbsp;&nbsp;/&nbsp;&nbsp;181-210 cm wide</option>
                <option >Bunk bed   &nbsp;&nbsp;/&nbsp;&nbsp;Variable Size</option>
                <option >Sofa bed   &nbsp;&nbsp;/&nbsp;&nbsp;Variable Size</option>
                <option >Futon bed(s)  &nbsp;&nbsp;/&nbsp;&nbsp;Variable Size</option>
            </select>
		</div>
		<div class="form-group col-md-3">
			<label class="control-label">Number of Beds:</label>
			<input type="text" class="form-control" name="number_of_beds" value="<?=@$_POST['number_of_beds']?>">
		</div>
		<div class="form-group col-md-3">
			<label class="control-label">Max. Guests:</label>
			<input type="text" class="form-control" name="maximum_guests" value="<?=@$_POST['maximum_guests']?>">
		</div>
		<div class="form-group col-md-6">
			<label class="control-label">Price per Night:</label>
			<input type="text" class="form-control" name="price_per_night" value="<?=@$_POST['price_per_night']?>">
		</div>
		<div class="form-group col-md-6">
			<label class="control-label">Number of rooms (of this type):</label>
			<input type="text" class="form-control" name="number_of_rooms" value="<?=@$_POST['number_of_rooms']?>">
		</div>
		<div class="form-group col-md-12">
			<label class="control-label">Description:</label>
			<textarea class="form-control" name="description" rows="4"><?=@$_POST['description']?></textarea> 
		</div>
		                   

		
	</fieldset>
  <div class="form-group form-actions">
                        <div class="col-xs-12 text-right">
                           <button type="submit" name="btn_room" class="btn btn-sm btn-primary">Submit</button>
                            <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </form>
                   
                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                              