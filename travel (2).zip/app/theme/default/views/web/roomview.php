<?php $data=HMIS\Web::room($_REQUEST['id'])?>
<script type="text/javascript">$(document).ready(function(){$('#parallax-pagetitle').parallax("50%", -0.55);});</script>

<section class="parallax-effect">
  <div id="parallax-pagetitle" style="background-image: url(./images/parallax/1900x911.gif);">
    <div class="color-overlay"> 
      <!-- Page title -->
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <h2><i class="fa fa-bank"></i> <?=$data['property_name']?></h2>
            <h3>&nbsp;&nbsp;<i class="fa fa-map-marker"></i> <?=$data['city']?></h3>
             <h4>&nbsp;&nbsp;&nbsp;<i class="fa fa-bed"></i> <?=$data['room_name']?></h4>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<div class="container mt50">
  <div class="row"> 
    <!-- Slider -->
    <section class="standard-slider room-slider">
      <div class="col-sm-12 col-md-8">
        <div id="owl-standard" class="owl-carousel">
          <div class="item"> <a href="content/rooms/<?=$data['room_pic_1']?>" data-rel="prettyPhoto[gallery1]"><img width="750" height="481" src="content/rooms/<?=$data['room_pic_1']?>" alt="Image 2" class="img-responsive"></a> </div>
          <div class="item"> <a href="content/rooms/<?=$data['room_pic_2']?>" data-rel="prettyPhoto[gallery1]"><img width="750" height="481" src="content/rooms/<?=$data['room_pic_2']?>" alt="Image 2" class="img-responsive"></a> </div>
          <div class="item"> <a href="content/rooms/<?=$data['room_pic_3']?>" data-rel="prettyPhoto[gallery1]"><img width="750" height="481" src="content/rooms/<?=$data['room_pic_3']?>" alt="Image 2" class="img-responsive"></a> </div>
          <div class="item"> <a href="content/rooms/<?=$data['room_pic_4']?>" data-rel="prettyPhoto[gallery1]"><img width="750" height="481" src="content/rooms/<?=$data['room_pic_4']?>" alt="Image 2" class="img-responsive"></a> </div>
          <div class="item"> <a href="content/rooms/<?=$data['room_pic_5']?>" data-rel="prettyPhoto[gallery1]"><img width="750" height="481" src="content/rooms/<?=$data['room_pic_5']?>" alt="Image 2" class="img-responsive"></a> </div>
          <div class="item"> <a href="content/rooms/<?=$data['room_pic_2']?>" data-rel="prettyPhoto[gallery1]"><img width="750" height="481" src="content/rooms/<?=$data['room_pic_6']?>" alt="Image 2" class="img-responsive"></a> </div>
        </div>
      </div>
    </section>
    
    <!-- Reservation form -->
    <section id="reservation-form" class="mt50 clearfix">
      <div class="col-sm-12 col-md-4">
        <form class="reservation-vertical clearfix" role="form" method="post" action="<?=ROOT_URL?>?route=booking"  >
          <h2 class="lined-heading"><span>Reservation</span></h2>
          <div class="price">
           KSH. <?=$data['price_per_night']?> -<span> a night</span></div>
          <div class="form-group">
            <label for="email" accesskey="E">E-mail</label>
            <input name="email" type="text"  value="<?=@G\get_app_setting('email')?>" readonly class="form-control" placeholder="Please enter your E-mail"/>
          </div>
          <div class="form-group">
            <input name="room_id" type="hidden"  value="<?=$data['room_id']?>"  class="form-control"/>
          </div>
          <div class="form-group">
            <label for="checkin">Check-in</label>
            <div class="popover-icon" data-container="body" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="Check-In is from 11:00"> <i class="fa fa-info-circle fa-lg"> </i> </div>
            <i class="fa fa-calendar infield"></i>
            <input name="checkin" type="text" id="checkin" value="" class="form-control" placeholder="Check-in"/>
			</div>
          <div class="form-group">
            <label for="checkout">Check-out</label>
            <div class="popover-icon" data-container="body" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="Check-out is from 12:00"> <i class="fa fa-info-circle fa-lg"> </i> </div>
            <i class="fa fa-calendar infield"></i>
            <input name="checkout" type="text" id="checkout" value="" class="form-control" placeholder="Check-out"/>
          </div>
          <div class="form-group col-md-8">
            <div class="guests-select">
              <label>Guests</label>
              <i class="fa fa-user infield"></i>
              <div class="total form-control" id="test">1</div>
              <div class="guests">
                <div class="form-group adults">
                  <label for="adults">Adults</label>
                  <div class="popover-icon" data-container="body" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="+18 years"> <i class="fa fa-info-circle fa-lg"> </i> </div>
                  <select name="adults" id="adults" class="form-control">
                    <option value="1">1 adult</option>
                    <option value="2">2 adults</option>
                    <option value="3">3 adults</option>
                    <option value="4">4 adults</option>
                    <option value="5">5 adults</option>
                    <option value="6">6 adults</option>
                  </select>
                </div>
                <div class="form-group children">
                  <label for="children">Children</label>
                  <div class="popover-icon" data-container="body" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="0 till 18 years"> <i class="fa fa-info-circle fa-lg"> </i> </div>
                  <select name="children" id="children" class="form-control">
                    <option value="0">0 children</option>
                    <option value="1">1 child</option>
                    <option value="2">2 children</option>
                    <option value="3">3 children</option>
                    <option value="4">4 children</option>
                  </select>
                </div>
                <button type="button" class="btn btn-default button-save btn-block">Save</button>
              </div>
            </div>
          </div>
          <div class="form-group col-md-4">
            <label>Rooms</label>
            <input name="rooms" type="text"  value="1"  class="form-control" placeholder="No. of Rooms"/>
          </div>
          <?php if(isset($_SESSION['UID'])){?>
          <button type="submit" class="btn btn-primary btn-block">Book Now</button>
          <?php }else{?>
          		<a href="<?=ROOT_URL?>login"><button type="button" class="btn btn-primary btn-block">Login to complete your Booking</button></a>
          <?php }?>
        </form>
      </div>
    </section>
    
    <!-- Room Content -->
    <section>
      <div class="container">
        <div class="row">
          <div class="col-sm-7 mt50">
            <h2 class="lined-heading"><span>Room Facilities</span></h2>
            <?=HMIS\Web::facilities($data['room_id'])?>
          </div>
          <div class="col-sm-5 mt50">
            <h2 class="lined-heading"><span>Room Description</span></h2>
            <!-- Tab panes -->
            <div class="tab-content">
              <div class="tab-pane fade in active" id="overview">
                <p><?=$data['description']?></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</div>

<!-- Other Rooms -->
<section class="rooms mt50">
  <div class="container">
    <div class="row">
      <div class="col-sm-12">
        <h2 class="lined-heading"><span>Similar Rooms</span></h2>
      </div>
      <!-- Room -->
      <?php foreach(HMIS\Web::other_rooms($data['room_id'],$data['room_type']) as $row){?>
      <div class="col-sm-4">
        <div class="room-thumb"> <img src="content/rooms/<?=$row['room_pic_1']?>"  class="img-responsive" />
         <div class="top-left"><button class="btn btn-xs btn-info"><?=$row['property_name'].' <i class="fa fa-minus"></i> '.$row['city']?></button></div>
          <div class="mask">
            <div class="main">
              <h5><?=$row['room_name']?></h5>
              <div class="price">KSH. <?=$row['price_per_night']?><span>a night</span></div>
            </div>
            <div class="content">
              <p> <?=substr($row['description'],0,200)?></p>
              <?=HMIS\Web::facilities($row['room_id'],'sub')?>
              <a href="<?=ROOT_URL?>?route=roomview&id=<?=$row['room_id']?>" class="btn btn-primary btn-block">Book Now</a> </div>
          </div>
        </div>
      </div>
      <?php }?>
      
      
    </div>
  </div>
</section>