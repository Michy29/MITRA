 <form  method="post" >
	<fieldset>
			<input type="hidden" class="form-control" name="pid" value="<?=$_POST["id"]?>">
		<div class="form-group col-md-12">
			<label class="control-label">Property Name:</label>
			<input type="text" class="form-control" name="property_name" value="<?=@$_POST['property_name']?>">
		</div>
		<div class="form-group col-md-12">
			<label class="control-label">Contact Name:</label>
			<input type="text" class="form-control" name="contact_name" value="<?=@$_POST['contact_name']?>">
		</div>
		<div class="form-group col-md-6">
			<label class="control-label">Contact Number:</label>
			<input type="text" class="form-control" name="contact_number" value="<?=@$_POST['contact_number']?>">
		</div>
		<div class="form-group col-md-6">
			<label class="control-label">Contact Email:</label>
			<input type="text" class="form-control" name="contact_email" value="<?=@$_POST['contact_email']?>">
		</div>
		<div class="form-group col-md-6">
			<label class="control-label">Street Address:</label>
			<input type="text" class="form-control" name="street_address" value="<?=@$_POST['street_address']?>">
		</div>
		<div class="form-group col-md-6">
			<label class="control-label">Address Line 2:</label>
			<input type="text" class="form-control" name="address_line2" value="<?=@$_POST['address_line2']?>">
		</div>
		<div class="form-group col-md-4">
			<label class="control-label">Country:</label>
			<select class="form-control" name="country" >
				<option value="" disabled selected>Select Country</option>
				<?=HMIS\countries()?>
			</select>
		</div>
		<div class="form-group col-md-4">
			<label class="control-label">City:</label>
			<input type="text" class="form-control" name="city" value="<?=@$_POST['city']?>">
		</div>
		<div class="form-group col-md-4">
			<label class="control-label">Zipcode:</label>
			<input type="text" class="form-control" name="zipcode" value="<?=@$_POST['zipcode']?>">
		</div>
		
			<input type="hidden" class="form-control" name="owner" value="<?=$_SESSION['UID']?>">
		
	</fieldset>
  <div class="form-group form-actions">
                        <div class="col-xs-12 text-right">
                           <button type="submit" name="btn_property" class="btn btn-sm btn-primary">Submit</button>
                            <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </form>
                   
                    