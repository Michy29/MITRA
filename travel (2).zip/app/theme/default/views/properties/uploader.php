 <form  method="post" enctype="multipart/form-data" >
  <?php $data=HMIS\Properties::get_room($_POST["id"])?>
 <style>
.btn-file {
    position: relative;
    overflow: hidden;
}
.btn-file input[type=file] {
    position: absolute;
    top: 0;
    right: 0;
    min-width: 100%;
    min-height: 100%;
    font-size: 100px;
    text-align: right;
    filter: alpha(opacity=0);
    opacity: 0;
    outline: none;
    background: white;
    cursor: inherit;
    display: block;
} </style>
	<fieldset>
		<input type="hidden" class="form-control" name="room_id" value="<?=$_POST["id"]?>">
		
		<div class="form-group col-md-4">
			<span class="btn btn-info btn-file btn-block">
				Browse Image 1<input type="file"  name="room_pic_1" id="imageone">
			</span>
			<span>
				<img width="100%" height="150px"  id="previewone" src="<?=ROOT_URL.'content/rooms/'.$data['room_pic_1']?>"/>
			</span>
		</div> 
		<div class="form-group col-md-4">
			<span class="btn btn-info btn-file btn-block">
				Browse Image 2<input type="file"  name="room_pic_2" id="imagetwo">
			</span>
			<span>
				<img width="100%" height="150px" id="previewtwo" src="<?=ROOT_URL.'content/rooms/'.$data['room_pic_2']?>"/>
			</span>
		</div> 
		<div class="form-group col-md-4">
			<span class="btn btn-info btn-file btn-block">
				Browse Image 3<input type="file"  name="room_pic_3" id="imagethree">
			</span>
			<span>
				<img width="100%" height="150px" id="previewthree" src="<?=ROOT_URL.'content/rooms/'.$data['room_pic_3']?>"/>
			</span>
		</div> 
		  <div class="form-group col-md-4">
			<span class="btn btn-info btn-file btn-block">
				Browse Image 4<input type="file"  name="room_pic_4" id="imagefour">
			</span>
			<span>
				<img width="100%" height="150px" id="previewfour" src="<?=ROOT_URL.'content/rooms/'.$data['room_pic_4']?>"/>
			</span>
		</div> 
		<div class="form-group col-md-4">
			<span class="btn btn-info btn-file btn-block">
				Browse Image to Upload<input type="file"  name="room_pic_5" id="imagefive">
			</span>
			<span>
				<img width="100%" height="150px" id="previewfive" src="<?=ROOT_URL.'content/rooms/'.$data['room_pic_5']?>"/>
			</span>
		</div> 
		<div class="form-group col-md-4">
			<span class="btn btn-info btn-file btn-block">
				Browse Image to Upload<input type="file"  name="room_pic_6" id="imagesix">
			</span>
			<span>
				<img width="100%" height="150px" id="previewsix" src="<?=ROOT_URL.'content/rooms/'.$data['room_pic_6']?>"/>
			</span>
		</div> 
		                       
	</fieldset>
  <div class="form-group form-actions">
                        <div class="col-xs-12 text-right">
                           <button type="submit" name="btn_pics" class="btn btn-sm btn-primary">Upload</button>
                            <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </form>
                  
<script>
	function readURLone(input) {
	  if (input.files && input.files[0]) {
		var reader = new FileReader();
		reader.onload = function(e) {
		  $('#previewone').attr('src', e.target.result);
		}
		reader.readAsDataURL(input.files[0]);
	  }
	}
	function readURLtwo(input) {
	  if (input.files && input.files[0]) {
		var reader = new FileReader();
		reader.onload = function(e) {
		  $('#previewtwo').attr('src', e.target.result);
		}
		reader.readAsDataURL(input.files[0]);
	  }
	}
	function readURLthree(input) {
	  if (input.files && input.files[0]) {
		var reader = new FileReader();
		reader.onload = function(e) {
		  $('#previewthree').attr('src', e.target.result);
		}
		reader.readAsDataURL(input.files[0]);
	  }
	}
	function readURLfour(input) {
	  if (input.files && input.files[0]) {
		var reader = new FileReader();
		reader.onload = function(e) {
		  $('#previewfour').attr('src', e.target.result);
		}
		reader.readAsDataURL(input.files[0]);
	  }
	}
	function readURLfive(input) {
	  if (input.files && input.files[0]) {
		var reader = new FileReader();
		reader.onload = function(e) {
		  $('#previewfive').attr('src', e.target.result);
		}
		reader.readAsDataURL(input.files[0]);
	  }
	}
	function readURLsix(input) {
	  if (input.files && input.files[0]) {
		var reader = new FileReader();
		reader.onload = function(e) {
		  $('#previewsix').attr('src', e.target.result);
		}
		reader.readAsDataURL(input.files[0]);
	  }
	}
	

$("#imageone").change(function() {readURLone(this);});
$("#imagetwo").change(function() {readURLtwo(this);});
$("#imagethree").change(function() {readURLthree(this);});
$("#imagefour").change(function() {readURLfour(this);});
$("#imagefive").change(function() {readURLfive(this);});
$("#imagesix").change(function() {readURLsix(this);});
</script>
                   
                    