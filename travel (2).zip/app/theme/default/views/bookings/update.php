 <form  method="post" >
 <?php $data=HMIS\Reservation::get_reservation($_POST["id"])?>
	<fieldset>
	<div class="row">
          </div>
            <div class="col-md-6">
              <div class="form-group">
                <label for="name" accesskey="U"> Client</label>
                <input name="name" type="text" readonly class="form-control" value="<?=$data['first_name']?> <?=$data['middle_name']?> <?=$data['last_name']?>"/>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label for="email" accesskey="E"> E-mail</label>
                <input name="email" type="text" readonly  value="<?=$data['email']?>" class="form-control"/>
              </div>
            </div>
          </div>
			<div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label for="name" accesskey="U"> Hotel</label>
                <input type="text" readonly class="form-control" value="<?=$data['property_name']?>"/>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label for="email" accesskey="E"> Room</label>
                <input readonly type="text"  value="<?=$data['room_name']?>" class="form-control"/>
                <input name="room_id" type="hidden"  value="<?=$data['room_id']?>" class="form-control"/>
                <input name="uid" type="hidden"  value="<?=$data['uid']?>" class="form-control"/>
                <input name="book_id" type="hidden"  value="<?=$data['book_id']?>" class="form-control"/>
              </div>
            </div>
			<div class="col-md-2">
              <div class="form-group">
                <label > No. of Rooms</label>
                <input name="no_of_rooms" type="text" readonly  value="<?=$data['no_of_rooms']?>" class="form-control"/>
              </div>
            </div>
          </div>
          
			<div class="row">
            <div class="col-md-3">
              <div class="form-group">
                <label for> Adults</label>
                <input name="adults" type="text" readonly class="form-control" value="<?=$data['adults']?>"/>
              </div>
            </div>
            <div class="col-md-3">
              <div class="form-group">
                <label > Children</label>
                <input name="children" type="text" readonly  value="<?=$data['children']?>" class="form-control"/>
                <input name="no_of_guests" type="hidden" readonly  value="<?=$data['children']+$data['adults']?>" class="form-control"/>
              </div>
            </div>
			<div class="col-md-3">
              <div class="form-group">
                <label for="name" accesskey="U"> Checkin Date</label>
                <input name="checkin" type="text" readonly class="form-control" value="<?=$data['checkin']?>"/>
                <input name="reserve_date" type="hidden"  class="form-control" value="<?=$data['reserve_date']?>"/>
              </div>
            </div>
            <div class="col-md-3">
              <div class="form-group">
                <label for="email" accesskey="E"> Checkout Date</label>
                <input name="checkout" type="text" readonly  value="<?=$data['checkout']?>" class="form-control"/>
              </div>
            </div>
				
          </div>
          <div class="row">
            <div class="col-md-3">
              <div class="form-group">
                <label > Number of Days</label>
                <input name="number_of_days" type="text" readonly class="form-control" value="<?=$data['number_of_days']?>"/>
              </div>
            </div>
            <div class="col-md-3">
              <div class="form-group">
                <label>Total Amount Payable</label>
                <input name="total_amount" type="text" readonly  value="<?=$data['total_amount']?>" class="form-control"/>
              </div>
            </div>
          </div>
         
           <div class="form-group">
            <label for="comments" accesskey="C">Special Arrangements/Enquiries</label>
            <textarea name="special_arrangements" rows="9"  class="form-control"><?=$data['special_arrangements']?></textarea>
          </div>
</fieldset>
                   
 <div class="form-group form-actions">
                        <div class="col-xs-12 text-right">
                           <button type="submit" name="btn_book" class="btn btn-sm btn-primary">Submit</button>
                            <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </form>
                    