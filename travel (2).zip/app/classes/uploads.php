<?php
namespace HMIS;
use G, Exception;
class Uploads {
	public static function uploader($folder=null, $newfilename=null, $post='file') {
		$target_dir = ROOT_PATH."content/".$folder;
		$file = getimagesize($_FILES[$post]["tmp_name"]);
		$fileTmp = $_FILES[$post]["tmp_name"];
		$fileName = $_FILES[$post]["name"];
		$splitName = explode(".", $fileName);
		$fileExt = end($splitName);
		$finalfilename  = strtolower($newfilename.'.'.$fileExt);
		if($file !== false) {
			if ($_FILES[$post]["size"] > 200000) {
				$GLOBALS['error']='Maximum file size exceeded';
			}else{
				if($fileExt != "jpg" || $fileExt != "png" || $fileExt != "jpeg") {
						$GLOBALS['error']='Sorry, only JPG, JPEG & PNG  files are allowed.';
					}else{
					if(move_uploaded_file($fileTmp, $target_dir.$finalfilename)){
						
					}else{
						$GLOBALS['error']='An error occured while uploading file';
					}
				}
			}
				
		} else {
			$GLOBALS['error']='The file you uploaded is not an image!';
		}
	}
}
