<?php
namespace HMIS;
use G, Exception;

class Profiles {
	private static $string = 'uid, first_name, middle_name, last_name, street_address, address_line2, gender, email, mobileno, country, zipcode, city, regdate';
	private static $table = 'profiles';
	public static function profile_c_u() {
		if(isset($_POST['btn_prof'])){
		$request=array('uid'=>$_POST['uid']);
		if(DB::ReadSingle(self::$table,$request,1)==null){
			self::register_profile();
		}else{
			self::update_profile();
		}
		}
	}
	public static function register_profile() {
		$inserts = self::$string;
		try{
		$fields=explode(', ', $inserts);
		foreach($fields as $data){
			(isset($_POST[$data]))?$values[$data] = $_POST[$data]:null;
		}
		Auth::SignUp();
		DB::Create(self::$table, $values);
		$GLOBALS['success']='Registration successful';
			
		} catch(Exception $e) {
			$GLOBALS['error']='Registration not successful'.$e->getMessage();
		}
	}
	public static function get_profile($request) {
		$data  = DB::ReadSingle(self::$table,array('uid'=>$request),1);
		$data2 = DB::ReadSingle('users',array('email'=>$data['email']),1);
		return(array_merge($data,$data2));
	}
	public static function get_profiles($type=null) {
		$DB=DB::vanillaDB();
		$DB->query('
		SELECT * FROM '.G\get_app_setting('db_table_prefix').self::$table.' 
		INNER JOIN '.G\get_app_setting('db_table_prefix').'users 
		ON '.G\get_app_setting('db_table_prefix').self::$table.'.email='.G\get_app_setting('db_table_prefix').'users.email 
		WHERE '.G\get_app_setting('db_table_prefix').'users.user_type LIKE :user_type');
		$DB->bind(':user_type', "%".$type."%");
		return $DB->resultset();
	}
	public static function update_profile() {
		$updates =self::$string;
		try{
		$fields=explode(', ', $updates);
		foreach($fields as $data){
				$values[$data]  = $_POST[$data];
		}
		$checks=array('uid'=>$_POST['uid']);
		DB::Update(self::$table, $values,$checks);
		$GLOBALS['success']='Record updated successfully';
			
		} catch(Exception $e) {
			$GLOBALS['error']='An error occured while updating';
		}
	}
	public static function manage_rights() {
		$updates ='';
		try{
		$fields=explode(', ', $updates);
		foreach($fields as $data){
				$values[$data]  = $_POST[$data];
		}
		$checks=array('uid'=>$_POST['uid']);
		DB::Update('rights', $values,$checks);
		$GLOBALS['success']='User rights updated successfully';
			
		} catch(Exception $e) {
			$GLOBALS['error']='An error occured while updating rights';
		}
	}
	public static function delete_profile($request){
		$data= self::get_profile($request);
		G\DB::Delete(self::$table, array('uid'=>$request));
		G\DB::Delete('users', array('email'=>$data['email']));
	}
}
