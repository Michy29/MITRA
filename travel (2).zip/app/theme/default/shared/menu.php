<?php
define('APP_URL', ROOT_URL);
$primary_nav = array(
    array(
        'name'  => 'Dashboard',
        'url'   => APP_URL.'dashboard',
        'icon'  => 'fa fa-home'
    ),
	array(
        'name'  => 'Website',
        'url'   => APP_URL,
        'icon'  => 'fa fa-globe'
    ),
	array(
        'name'  => 'Profiles',
        'url'   => 'header',
    ),
	array(
        'name'  => 'Members',
        'url'   => APP_URL.'profiles/members',
        'icon'  => 'gi gi-parents',
		'auth'	=> $_SESSION['R']['staff_menu']
    ),
    array(
        'name'  => 'Property Owners',
        'url'   => APP_URL.'profiles/agents',
        'icon'  => 'fa fa-users',
		'auth'	=> $_SESSION['R']['farmers_menu']
    ),
	
	array(
        'name'  => 'Property Manager',
        'url'   => 'header',
    ),
	array(
        'name'  => 'Properties',
        'url'   => APP_URL.'properties',
        'icon'  => 'fa fa-bank',
		'auth'	=> $_SESSION['R']['consignments_menu']
    ),
	array(
        'name'  => 'Rooms',
        'url'   => APP_URL.'properties/rooms',
        'icon'  => 'fa fa-bed',
		'auth'	=> $_SESSION['R']['room_types_menu']
    ),
	/*array(
        'name'  => 'Extra Services',
        'url'   => APP_URL,
        'icon'  => 'fa fa-sign-in',
		'auth'	=> $_SESSION['R']['room_types_menu']
    ),*/
	array(
        'name'  => 'Booking Managerr',
        'url'   => 'header',
    ),
	array(
        'name'  => 'Reservations',
        'url'   => APP_URL.'bookings/reservations',
        'icon'  => 'fa fa-exchange',
		'auth'	=> $_SESSION['R']['slider_menu']
    ),
	array(
        'name'  => 'Bookings',
        'url'   => APP_URL.'bookings/bookings',
        'icon'  => 'fa fa-briefcase',
    ),
	array(
        'name'  => 'Payments',
        'url'   => APP_URL.'bookings/paymentS',
        'icon'  => 'fa fa-money',
    ),
	array(
        'name'  => 'Configuration',
        'url'   => 'header',
    ),
	array(
        'name'  => 'System Settings',
        'url'   => APP_URL.'config',
        'icon'  => 'gi gi-settings',
		'auth'	=> $_SESSION['R']['settings_menu']
    ),
);