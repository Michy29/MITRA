   <div id="page-content">
    <div class="content-header">
        <div class="header-section">
            <h1>
                <i class="gi gi-parents"></i>Payments<br>
            </h1>
        </div>
    </div>
    <div class="block">
        <div class="row">
        
        <div class="col-sm-12">
            <div class="block">
                <div class="block-title">
                    <h2>List of Reservations</h2>
                </div>
						<table id="hmis_table" class="table table-vcenter table-condensed table-bordered">
							<thead>
								<tr>
									<th>No.</th>
									<th>Full Name</th>
									<th>Transaction No.</th>
									<th>Payment Mode</th>
									<th>Amount Paid</th>
									<th>Date Paid</th>
									<th>Description</th>
								</tr>
							</thead>
							<tbody>
								<?php $i= 1;HMIS\Payment::payment_c_u(); 
								HMIS\Reservation::reserve_c_u();
								foreach(HMIS\Payment::get_payments() as $row){
									echo 
										'<tr> 
											<td>'.$i++.'</td>
											<td>'.$row['first_name'].' '.$row['middle_name'].' '.$row['last_name'].'</td>
											<td>'.$row['transaction_no'].'</td>
											<td>'.$row['payment_mode'].'</td>
											<td>'.$row['paid'].'</td>
											<td>'.$row['paydate'].'</td>
											
											<td>Payment made for booking Id '.$row['book_id'].' for '.$row['no_of_guests'].' guests for  a '.$row['number_of_days'].' day stay</td>
											
										</tr>';
								}?>
							</tbody>
						</table>
            </div>
        </div>
			</form>
    </div>
    </div>

   <div id="pullup" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title"> Booking Management</h4>
            </div>
            <!-- END Modal Header -->

            <!-- Modal Body -->
            <div class="modal-body">
                    <div id="response">
                    </div>
            </div>
            <!-- END Modal Body -->
        </div>
    </div>
   </div>




</div>