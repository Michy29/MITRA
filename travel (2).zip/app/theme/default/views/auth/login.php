<?php
($_SESSION['UID']!=null)?header('location:'.ROOT_URL.'dashboard'):null;
(isset($_POST['btn_login']))?HMIS\Auth::Login():null;
?>
      <div class="main-bothside">
         <form  method="post">
          		
            
            <div class="form-group">
               <div class="form-m-w3ls">
                  <p>Email</p>
                  <input type="email" name="email"  value="<?=$data['email']?>"   required>
               </div>
            </div>
            
            
            <div class="form-group">
               <div class="form-m-w3ls">
                  <p>Password</p>
                  <input type="password" name="password"   required>
               </div>
            </div>
            
            <div class="btnn">
               <input type="submit" name="btn_login" value="Login to Dashboard">
            </div>
			 <hr>
            <span ><strong style="color:aliceblue">Don't have an account?</strong> <a style="color:yellow" href="<?=ROOT_URL?>register">Register Here</a></span><br/><br/>
            <span ><strong style="color:aliceblue">Forgot password?</strong> <a style="color:yellow" href="<?=ROOT_URL?>reset">Reset Here</a></span>
            
         </form>
      </div>
      