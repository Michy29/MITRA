<footer>
  <div class="footer-bottom">
    <div class="container">
      <div class="row">
        <div class="col-xs-6"> &copy; <?=date('Y')?> <?=G\get_app_setting('company_name')?>. All Rights Reserved </div>
      </div>
    </div>
  </div>
</footer>
<!-- Go-top Button -->
<div id="go-top"><i class="fa fa-angle-up fa-2x"></i></div>
<!-- Javascripts --> 
<script type="text/javascript" src="frontend/js/jquery-1.11.0.min.js"></script> 
<script type="text/javascript" src="frontend/js/bootstrap.min.js"></script> 
<script type="text/javascript" src="frontend/js/bootstrap-hover-dropdown.min.js"></script> 
<script type="text/javascript" src="frontend/js/owl.carousel.min.js"></script> 
<script type="text/javascript" src="frontend/js/jquery.parallax-1.1.3.js"></script>
<script type="text/javascript" src="frontend/js/jquery.nicescroll.js"></script>  
<script type="text/javascript" src="frontend/js/jquery.prettyPhoto.js"></script> 
<script type="text/javascript" src="frontend/js/jquery-ui-1.10.4.custom.min.js"></script> 
<script type="text/javascript" src="frontend/js/jquery.jigowatt.js"></script> 
<script type="text/javascript" src="frontend/js/jquery.sticky.js"></script> 
<script type="text/javascript" src="frontend/js/waypoints.min.js"></script> 
<script type="text/javascript" src="frontend/js/jquery.isotope.min.js"></script> 
<script type="text/javascript" src="frontend/rs-plugin/js/jquery.themepunch.plugins.min.js"></script> 
<script type="text/javascript" src="frontend/rs-plugin/js/jquery.themepunch.revolution.min.js"></script> 
<script type="text/javascript" src="frontend/js/custom.js"></script> 
<link rel="stylesheet" href="<?=ROOT_URL?>app/theme/default/assets/js/plugins.js">
</body>
</html>